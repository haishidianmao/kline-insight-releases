// @ts-check
import {
  analyze,
  getCatalog,
  STRATEGIES,
  analyzeMultiTimeframe,
  backtestPatterns,
  backtestStrategy,
  dcaEqualReturn,
  suggestTradePlan,
  recommendStrategies,
  interpretFundingRate,
  interpretLiquidations,
  interpretFearGreed,
  marketComparison,
  buildStrategyPlan,
} from "./lib/index.js";
import { normalizeSymbol, autoDetectExchange } from "./symbol-utils.js";
import { detectPageContext } from "./page-detector.js";
import { drawCandles, indexFromX, defaultViewRange } from "./chart.js";
import { patternDiagramSvg } from "./pattern-diagram.js";
import { saveCanvas, shotFilename } from "./screenshot.js";
import { initI18n, setLang, t, LANG, patternName, strategyName } from "./i18n.js";
import { patternField, strategyField } from "./content-i18n.js";
import { localizePlan } from "./plan-l10n.js";
import { trAnalysis, trFragments } from "./analysis-l10n.js";
import { checkForUpdate } from "./updater.js";
import qrcodegen from "./qrcodegen.js";
import { UPDATE_CONFIG } from "./update-config.js";
import {
  getCachedState,
  getDeviceId,
  getAccountNumber,
  createAccount,
  loginAccount,
  refreshStatus,
  redeemCode,
  redeemGumroad,
  removeDevice,
  openCheckout,
  formatAccount,
  isActive,
} from "./account.js";
import { getQuotaInfo, tryConsume } from "./quota.js";

// 跨浏览器 API：火狐用 browser.*（Promise），Chrome 用 chrome.*（MV3 也返回 Promise）
const api = typeof browser !== "undefined" && browser.runtime ? browser : chrome;

/** 构建标识：修改代码后请到扩展管理页点「重新加载」，页脚会显示最新构建时间 */
const BUILD_STAMP = "v0.5.4 · 构建 2026-08-21 11:58";

const $ = (sel) => document.querySelector(sel);

const els = {
  exchange: $("#exchange"),
  interval: $("#interval"),
  symbol: $("#symbol"),
  limit: $("#limit"),
  pasteRow: $("#paste-row"),
  paste: $("#paste"),
  analyzeBtn: $("#analyze-btn"),
  viewerBtn: $("#viewer-btn"),
  saveBtn: $("#save-symbol"),
  autoDetect: $("#auto-detect"),
  signalFilter: $("#signal-filter"),
  manualRow: $("#manual-row"),
  connText: $("#conn-text"),
  refreshBtn: $("#refresh-btn"),
  conflictBanner: $("#conflict-banner"),
  status: $("#status"),
  content: $("#content"),
  economySymbol: $("#economy-symbol"),
  economyBtn: $("#economy-btn"),
  economyStatus: $("#economy-status"),
  economyResult: $("#economy-result"),
};

/** @type {AnalysisResult|null} */
let lastResult = null;
let lastEconomyResult = null;
let activeTab = "analysis";
let analysisSub = "kline";
let selectedRange = null;
let viewRange = null;
let lastResonance = null;
let lastBacktest = null;
let lastStrategyBacktest = null;
let backtestCandles = null;
let autoRunTimer = null;
let analysisSeq = 0;
let fetchReqSeq = 0;

const KIND_TEXT = {
  get reversal() { return t("kind_reversal"); },
  get continuation() { return t("kind_continuation"); },
  get indecision() { return t("kind_indecision"); },
  get signal() { return t("kind_signal"); },
};

const DIRECTION_TEXT = {
  get bullish() { return t("dir_bullish"); },
  get bearish() { return t("dir_bearish"); },
  get neutral() { return t("dir_neutral"); },
};

const TREND_TEXT = {
  get up() { return t("trend_up"); },
  get down() { return t("trend_down"); },
  get sideways() { return t("trend_sideways"); },
};

function stars(n) {
  const k = Math.max(0, Math.min(5, Math.round(Number(n) || 0)));
  return "★".repeat(k) + "☆".repeat(5 - k);
}

function badge(cls, text) {
  const el = document.createElement("span");
  el.className = `badge ${cls}`;
  el.textContent = text;
  return el;
}

/** 数字自适应小数位显示（价格/成交量通用） */
function fmtNum(v) {
  if (v == null) return "-";
  const n = Number(v);
  if (!Number.isFinite(n)) return "-";
  const abs = Math.abs(n);
  const digits = abs >= 10000 ? 0 : abs >= 100 ? 2 : abs >= 1 ? 4 : 6;
  return n.toLocaleString("zh-CN", { maximumFractionDigits: digits });
}

function setStatus(text, isError = false) {
  els.status.textContent = text;
  els.status.className = `status${isError ? " error" : ""}`;
}

const ECONOMY_API_BASE = "https://getmarketcompass.site";
const ECONOMY_TIMEOUT = 30000;

/** 本地经济模型 API 请求：带超时，失败时抛出带 status 的错误；options 可传 fetch 选项（如 method/headers/body） */
async function fetchLocalApi(url, timeoutMs = ECONOMY_TIMEOUT, options = {}) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const res = await fetch(url, { signal: controller.signal, ...options });
    let data = null;
    try {
      data = await res.json();
    } catch {
      // 非 JSON 响应，按 HTTP 错误处理
    }
    if (!res.ok || !data || data.ok !== true) {
      const err = new Error((data && data.error) || `HTTP ${res.status}`);
      err.status = res.status;
      err.data = data;
      throw err;
    }
    return data;
  } finally {
    clearTimeout(timer);
  }
}

/** 数字 → 涨跌幅文本（小数按比例、大数按百分比兼容） */
function fmtReturn(v) {
  const n = Number(v);
  if (!Number.isFinite(n)) return "-";
  const pct = Math.abs(n) <= 1 ? n * 100 : n;
  return `${pct >= 0 ? "+" : ""}${pct.toFixed(2)}%`;
}

/** 综合分/子分数：0~1 或 0~100 都转成进度百分比 */
function fmtScore(v) {
  const n = Number(v);
  if (!Number.isFinite(n)) return { text: "-", pct: 0, sign: 0 };
  // score 标度通常 -1~1（或 -100~100），统一转成百分比显示
  const pctRaw = Math.abs(n) <= 1 ? n * 100 : n;
  const pct = Math.max(-100, Math.min(100, pctRaw));
  // 0.5% 以内视为中性，避免微分数值误导颜色
  const sign = pct > 0.5 ? 1 : pct < -0.5 ? -1 : 0;
  const rounded = Math.round(pct);
  return { text: `${rounded > 0 ? "+" : ""}${rounded}%`, pct: Math.abs(pct), sign };
}

/** 服务端中文值 → 当前界面语言（经济模型输出本地化） */
function econStance(zh) {
  const map = { "进攻": t("economy_stance_attack"), "防守": t("economy_stance_defend"), "试探": t("economy_stance_try"), "观望": t("economy_stance_watch") };
  return map[zh] || zh;
}
function econConf(zh) {
  const map = { "低": t("economy_conf_low"), "中": t("economy_conf_mid"), "中高": t("economy_conf_midhigh"), "高": t("economy_conf_high") };
  return map[zh] || zh;
}
function econMarket(zh) {
  const map = { "交易中": t("economy_market_open"), "已收盘": t("economy_market_closed"), "未开盘": t("economy_market_pending") };
  return map[zh] || zh;
}
function econRegime(id) {
  const map = { bull_trend: "economy_regime_bull", bear_trend: "economy_regime_bear", sideways: "economy_regime_sideways", recovery: "economy_regime_recovery", panic: "economy_regime_panic", liquidity_crisis: "economy_regime_liquidity", bubble: "economy_regime_bubble" };
  return map[id] ? t(map[id]) : id;
}
function econCycle(biasLabel) {
  const map = { "长周期上行": "economy_cycle_up", "长周期下行": "economy_cycle_down", "长周期中性": "economy_cycle_neutral", "数据不足": "economy_cycle_insufficient" };
  return map[biasLabel] ? t(map[biasLabel]) : biasLabel;
}
/** 服务端形态（id+zh）→ 本地化形态名（优先插件形态目录，fallback 服务端中文名） */
function econPatternName(p) {
  if (!p) return "";
  if (p.id) {
    const pat = getCatalog().find((x) => x.id === p.id);
    if (pat) return patternName(pat);
  }
  // id 体系不同（服务端 marubozu_bearish vs 插件 s- 前缀），按中文名匹配
  if (p.zh) {
    const byZh = getCatalog().find((x) => x.nameZh === p.zh);
    if (byZh) return patternName(byZh);
  }
  return p.zh || p.nameZh || p.id || "-";
}
/** 服务端策略（id+name）→ 本地化策略名（优先插件策略目录，fallback 服务端中文名） */
function econStrategyName(s) {
  if (!s) return "";
  if (s.id) {
    const st = STRATEGIES.find((x) => x.id === s.id);
    if (st) return strategyName(st);
    // id 不一致时按中文名匹配
    const byZh = STRATEGIES.find((x) => x.nameZh === s.name);
    if (byZh) return strategyName(byZh);
  }
  return s.name || s.nameZh || s.id || "-";
}

/** 方向徽章：文本直接用服务端返回值（服务端已按当前语言翻译），配色按多语言方向关键词 */
function economyDirectionMeta(direction) {
  const d = String(direction || "").toLowerCase();
  const text = String(direction || t("economy_dir_watch"));
  const LONG = ["多", "long", "bullish", "buy", "看涨", "看多", "强気", "上昇", "상승", "매수", "강세"];
  const SHORT = ["空", "short", "bearish", "sell", "看跌", "看空", "弱気", "下落", "하락", "매도", "약세"];
  if (LONG.some((k) => d.includes(k))) return { cls: "long", label: text, color: "#2ecc71" };
  if (SHORT.some((k) => d.includes(k))) return { cls: "short", label: text, color: "#e74c3c" };
  return { cls: "watch", label: text, color: "#9aa3b2" };
}

function showEconomyStatus(text, isError = false) {
  els.economyStatus.textContent = text;
  els.economyStatus.className = `economy-status${isError ? " error" : ""}`;
}

function showEconomyUnavailable(err) {
  els.economyResult.style.display = "none";
  els.economyResult.innerHTML = "";
  const detail = err && err.message && err.name !== "AbortError" ? `（${err.message}）` : "";
  showEconomyStatus(t("economy_status_unavailable") + detail, true);
}

function economyMetric(label, value, cls = "") {
  const wrap = document.createElement("div");
  wrap.className = "economy-metric";
  const l = document.createElement("div");
  l.className = "label";
  l.textContent = label;
  const v = document.createElement("div");
  v.className = `value${cls ? ` ${cls}` : ""}`;
  v.textContent = value;
  wrap.appendChild(l);
  wrap.appendChild(v);
  return wrap;
}

/** 渲染 /api/signal 返回结果 */
function renderEconomyResult(r) {
  lastEconomyResult = r;
  const out = els.economyResult;
  out.innerHTML = "";
  out.style.display = "";
  const dir = economyDirectionMeta(r.direction);
  const score = fmtScore(r.score);

  // 定投利润行（点击方向预测后由 refreshEconomyDca 拉K线计算填充：1月/6月/1年/3年/5年）
  const dcaCard2 = document.createElement("div");
  dcaCard2.className = "dca-card";
  dcaCard2.id = "economy-dca-card";
  const dcaHead2 = document.createElement("div");
  dcaHead2.className = "dca-row";
  const dcaLabel2 = document.createElement("span");
  dcaLabel2.textContent = `${t("analysis_dca_title")}（${t("dca_note_monthly")}）`;
  dcaHead2.appendChild(dcaLabel2);
  dcaCard2.appendChild(dcaHead2);
  const dcaPeriods2 = document.createElement("div");
  dcaPeriods2.className = "dca-periods";
  const periods = [
    ["dca-m1", "dca_period_m1"],
    ["dca-m6", "dca_period_m6"],
    ["dca-y1", "dca_period_y1"],
    ["dca-y3", "dca_period_y3"],
    ["dca-y5", "dca_period_y5"],
  ];
  for (const [pid, pkey] of periods) {
    const cell = document.createElement("span");
    cell.className = "dca-period";
    const em = document.createElement("em");
    em.textContent = t(pkey);
    const b = document.createElement("b");
    b.id = `dca-${pid}`;
    b.textContent = t("dca_calculating");
    cell.append(em, b);
    dcaPeriods2.appendChild(cell);
  }
  dcaCard2.appendChild(dcaPeriods2);
  out.appendChild(dcaCard2);

  const card = document.createElement("div");
  card.className = "economy-card";

  const headline = document.createElement("div");
  headline.className = "economy-headline";
  const dirEl = document.createElement("span");
  dirEl.className = `economy-direction ${dir.cls}`;
  dirEl.textContent = dir.label;
  headline.appendChild(dirEl);
  const scaleEl = document.createElement("span");
  scaleEl.className = "economy-scale";
  scaleEl.textContent = t("economy_scale_daily");
  headline.appendChild(scaleEl);

  const scoreWrap = document.createElement("div");
  scoreWrap.className = "economy-score";
  const scoreLabel = document.createElement("div");
  scoreLabel.className = "economy-score-label";
  scoreLabel.innerHTML = `<span>${t("economy_score")}</span><span>${score.text}</span>`;
  const scoreBar = document.createElement("div");
  scoreBar.className = "economy-score-bar";
  const fill = document.createElement("i");
  fill.style.width = `${score.pct}%`;
  // 进度条按方向配色：正=红（涨）、负=绿（跌）、中性=灰
  fill.style.background =
    score.sign > 0
      ? "linear-gradient(90deg,#2ecc71,#81ecec)"
      : score.sign < 0
        ? "linear-gradient(90deg,#e74c3c,#ff8a80)"
        : "linear-gradient(90deg,#9aa3b2,#c0c8d0)";
  scoreBar.appendChild(fill);
  scoreWrap.appendChild(scoreLabel);
  scoreWrap.appendChild(scoreBar);
  headline.appendChild(scoreWrap);
  card.appendChild(headline);

  const grid = document.createElement("div");
  grid.className = "economy-grid";
  grid.appendChild(economyMetric(t("economy_price"), r.price != null ? fmtNum(r.price) : "-"));
  const retCls = (v) => (Number(v) > 0 ? "positive" : Number(v) < 0 ? "negative" : "");
  grid.appendChild(economyMetric(t("economy_ret_1d"), fmtReturn(r.returns && r.returns.d1), retCls(r.returns && r.returns.d1)));
  grid.appendChild(economyMetric(t("economy_ret_5d"), fmtReturn(r.returns && r.returns.d5), retCls(r.returns && r.returns.d5)));
  grid.appendChild(economyMetric(t("economy_ret_20d"), fmtReturn(r.returns && r.returns.d20), retCls(r.returns && r.returns.d20)));
  card.appendChild(grid);

  const scores = document.createElement("div");
  scores.className = "economy-scores";
  scores.appendChild(economyMetric(t("economy_news_score"), r.newsScore != null ? fmtScore(r.newsScore).text : "-"));
  scores.appendChild(economyMetric(t("economy_behavior_score"), r.behaviorScore != null ? fmtScore(r.behaviorScore).text : "-"));
  scores.appendChild(economyMetric(t("economy_hist_score"), r.histScore != null ? fmtScore(r.histScore).text : "-"));
  card.appendChild(scores);

  // 止损止盈（结构化展示；服务端未返回百分比时用价格反算）
  if (r.stopLoss != null && r.takeProfit != null) {
    const sltp = document.createElement("div");
    sltp.className = "economy-sltp";
    const slPct =
      r.stopPct != null
        ? (r.stopPct * 100).toFixed(1)
        : r.price > 0
          ? ((r.stopLoss / r.price - 1) * 100).toFixed(1)
          : null;
    const tpPct =
      r.takePct != null
        ? (r.takePct * 100).toFixed(1)
        : r.price > 0
          ? ((r.takeProfit / r.price - 1) * 100).toFixed(1)
          : null;
    const sl = economyMetric(
      t("economy_stop_loss"),
      `${fmtNum(r.stopLoss)}${slPct != null ? ` (${slPct}%)` : ""}`,
      "negative",
    );
    const tp = economyMetric(
      t("economy_take_profit"),
      `${fmtNum(r.takeProfit)}${tpPct != null ? ` (+${tpPct}%)` : ""}`,
      "positive",
    );
    sltp.append(sl, tp);
    card.appendChild(sltp);
  }

  // 最优历史策略
  if (r.bestStrategy && r.bestStrategy.name) {
    const bs = document.createElement("div");
    bs.className = "economy-best";
    const bsLabel = document.createElement("div");
    bsLabel.className = "label";
    bsLabel.textContent = t("economy_best_strategy");
    const bsName = document.createElement("div");
    bsName.className = "name";
    bsName.textContent = econStrategyName(r.bestStrategy);
    const bsMeta = document.createElement("div");
    bsMeta.className = "meta";
    const bsWin = r.bestStrategy.winRate != null ? `${(r.bestStrategy.winRate * 100).toFixed(0)}%` : "-";
    const bsRet = r.bestStrategy.avgReturn != null ? `${(r.bestStrategy.avgReturn * 100).toFixed(2)}%` : "-";
    bsMeta.textContent = `${t("economy_win_rate")} ${bsWin} · ${t("economy_avg_return")} ${bsRet}`;
    bs.append(bsLabel, bsName, bsMeta);
    card.appendChild(bs);
  }

  // K线形态胜率：当前形态 + 历史胜率表（前 5 条）
  if (r.patterns && (r.patterns.current || (r.patterns.table && r.patterns.table.length))) {
    const pt = document.createElement("div");
    pt.className = "economy-patterns";
    const ptLabel = document.createElement("div");
    ptLabel.className = "label";
    ptLabel.textContent = t("economy_pattern_win");
    pt.appendChild(ptLabel);
    if (r.patterns.current) {
      const cur = document.createElement("div");
      cur.className = "current";
      // current 可能是对象数组（含多个形态）或字符串
      const curText = Array.isArray(r.patterns.current)
        ? r.patterns.current.map((p) => econPatternName(p)).join("、")
        : String(r.patterns.current);
      cur.textContent = `${t("economy_current")}：${curText}`;
      pt.appendChild(cur);
    }
    const rows = (r.patterns.table || []).slice(0, 5);
    for (const row of rows) {
      const rw = document.createElement("div");
      rw.className = "pattern-row";
      const nm = document.createElement("span");
      nm.textContent = econPatternName(row);
      const st = document.createElement("span");
      const wr = row.dirWin5 != null ? `${(row.dirWin5 * 100).toFixed(0)}%` : row.upRate5 != null ? `${(row.upRate5 * 100).toFixed(0)}%` : "-";
      const n = row.n != null ? row.n : "-";
      st.textContent = `${t("economy_win_rate")} ${wr}（n=${n}）`;
      rw.append(nm, st);
      pt.appendChild(rw);
    }
    card.appendChild(pt);
  }

  // 历史校准可信度（服务端 calibration 字段：该标的 20 日方向命中率 vs 基准——"预测配可信度"）
  if (r.calibration && r.calibration.hitRate != null) {
    const cal = document.createElement("div");
    cal.className = "economy-calibration";
    const hr = (r.calibration.hitRate * 100).toFixed(1);
    const br = (r.calibration.baseRate * 100).toFixed(1);
    const avgNote = r.calibration.exact ? "" : ` · ${t("economy_calibration_avg")}`;
    cal.textContent = `${t("economy_calibration")}：${r.calibration.horizon}D ${t("economy_win_rate")} ${hr}%（${t("economy_base")} ${br}%）${avgNote}`;
    card.appendChild(cal);
  }

  // 资金费率（加密标的）：数学确定的最可靠数据，占位行由 refreshEconomyFunding 异步填充
  if (r.symbol && /-USD$/i.test(r.symbol)) {
    const fr = document.createElement("div");
    fr.className = "economy-funding";
    fr.id = "economy-funding-row";
    fr.textContent = `${t("economy_funding_rate")}：…`;
    card.appendChild(fr);
  }

  // 最终决策（立场 + 建议仓位 + 概率）
  if (r.decision && (r.decision.stance || r.decision.positionPct != null)) {
    const dc = document.createElement("div");
    dc.className = "economy-decision";
    const dcLabel = document.createElement("div");
    dcLabel.className = "label";
    dcLabel.textContent = t("economy_decision");
    const dcMain = document.createElement("div");
    dcMain.className = "main";
    const stance = econStance(r.decision.stance) || "-";
    const pos =
      r.decision.positionPct != null
        ? `${t("economy_position")} ${r.decision.positionPct}%`
        : "";
    const prob =
      r.decision.pUp != null
        ? `${t("economy_up_prob")} ${(r.decision.pUp * 100).toFixed(0)}%`
        : "";
    dcMain.textContent = [stance, pos, prob].filter(Boolean).join(" · ");
    dc.append(dcLabel, dcMain);
    card.appendChild(dc);
  }

  // 市场状态 + 长周期（本地化展示，服务端 regime/cycle 结构化数据）
  const stateParts = [];
  if (r.regime && r.regime.id) stateParts.push(`${t("economy_market_state")}：${econRegime(r.regime.id)}`);
  if (r.cycle && r.cycle.biasLabel) stateParts.push(`${t("economy_cycle")}：${econCycle(r.cycle.biasLabel)}`);
  if (stateParts.length) {
    const stRow = document.createElement("div");
    stRow.className = "economy-state";
    stRow.textContent = stateParts.join(" · ");
    card.appendChild(stRow);
  }

  // 情景模拟（1/5/20 日基准/乐观/悲观）
  if (r.scenarios && r.scenarios.length) {
    const sc = document.createElement("div");
    sc.className = "economy-scenarios";
    const scLabel = document.createElement("div");
    scLabel.className = "label";
    scLabel.textContent = t("economy_scenarios");
    sc.appendChild(scLabel);
    for (const s of r.scenarios.slice(0, 3)) {
      const row = document.createElement("div");
      row.className = "scenario-row";
      const hd = document.createElement("span");
      hd.className = "horizon";
      hd.textContent = `${s.horizon}D`;
      const vals = document.createElement("span");
      vals.className = "vals";
      const pct = (v) => `${v >= 0 ? "+" : ""}${(v * 100).toFixed(1)}%`;
      const up = s.pUp != null ? ` · ${t("economy_up_prob")} ${(s.pUp * 100).toFixed(0)}%` : "";
      vals.textContent = `${t("economy_base")} ${pct(s.base)} · ${t("economy_bull")} ${pct(s.bull)} · ${t("economy_bear")} ${pct(s.bear)}${up}`;
      row.append(hd, vals);
      sc.appendChild(row);
    }
    card.appendChild(sc);
  }

  // 失效条件 + 为什么会错
  const inval = r.invalidation;
  const why = r.whyMightBeWrong;
  if ((inval && inval.length) || why) {
    const warn = document.createElement("div");
    warn.className = "economy-warn";
    if (inval && inval.length) {
      const invLabel = document.createElement("div");
      invLabel.className = "label";
      invLabel.textContent = t("economy_invalidation");
      warn.appendChild(invLabel);
      for (const line of inval) {
        const item = document.createElement("div");
        item.className = "warn-item";
        item.textContent = line;
        warn.appendChild(item);
      }
    }
    if (why) {
      const whyLabel = document.createElement("div");
      whyLabel.className = "label";
      whyLabel.textContent = t("economy_why_wrong");
      warn.appendChild(whyLabel);
      const whyText = document.createElement("div");
      whyText.className = "warn-item";
      whyText.textContent = Array.isArray(why) ? why.join("；") : String(why);
      warn.appendChild(whyText);
    }
    card.appendChild(warn);
  }

  // 大师/机构行为（精简前 5 条）
  const masters = r.masters || [];
  const institutions = r.institutions || [];
  if (masters.length || institutions.length) {
    const ms = document.createElement("div");
    ms.className = "economy-masters";
    const msLabel = document.createElement("div");
    msLabel.className = "label";
    msLabel.textContent = t("economy_masters");
    ms.appendChild(msLabel);
    const items = [
      ...masters.map((m) => (m && m.name ? `${m.name}：${m.summary || m.quote || ""}` : "")),
      ...institutions.map((i) => (i && i.name ? `${i.name}：${i.summary || i.action || ""}` : "")),
    ].filter(Boolean);
    for (const line of items.slice(0, 5)) {
      const item = document.createElement("div");
      item.className = "master-item";
      item.textContent = line;
      ms.appendChild(item);
    }
    card.appendChild(ms);
  }

  if (r.answer) {
    const answer = document.createElement("div");
    answer.className = "economy-answer";
    const label = document.createElement("span");
    label.className = "label";
    label.textContent = t("economy_answer");
    answer.appendChild(label);
    answer.appendChild(document.createTextNode(r.answer));
    card.appendChild(answer);
  }

  const disclaimer = document.createElement("div");
  disclaimer.className = "economy-disclaimer";
  disclaimer.textContent = r.disclaimer || t("economy_disclaimer_default");
  card.appendChild(disclaimer);

  const meta = document.createElement("div");
  meta.className = "economy-meta";
  // 精简元信息：只保留标的符号，去掉“数据源缓存/截至日期”等冗余描述（用户要求隐藏）
  const metaParts = [];
  if (r.symbol) metaParts.push(r.symbol);
  meta.textContent = metaParts.join(" · ");
  if (metaParts.length) card.appendChild(meta);

  out.appendChild(card);
  showEconomyStatus("");
}

/** 点击「方向预测」 */
async function runEconomySignal() {
  const symbol = economyApiSymbol();
  if (!symbol) {
    showEconomyStatus(t("status_symbol_required"), true);
    return;
  }
  // 限次：方向预测是付费核心内容——免费版每日 N 次，会员不限
  const q = await tryConsume(!!(accountState && accountState.expiresAt && isActive(accountState.expiresAt)));
  if (!q.allowed) {
    showEconomyStatus(t("account_need_upgrade"), true);
    await refreshAccountUI();
    openAccountModal();
    return;
  }
  await refreshAccountUI();
  const btn = els.economyBtn;
  btn.disabled = true;
  btn.textContent = t("economy_btn_loading");
  lastEconomyResult = null;
  els.economyResult.style.display = "none";
  showEconomyStatus(t("economy_status_loading"));
  try {
    // 服务端每日限次：方向预测请求必须携带 deviceId（服务端按设备记账，客户端计数可被绕过）
    const deviceId = await getDeviceId();
    // A股（6 位纯数字代码）方向预测：插件端直连腾讯/东财/新浪抓日线 POST 给服务器——
    // 服务器海外访问国内源不通、Yahoo 429 限流且 StockAnalysis 不覆盖 A股，插件直连是唯一通路
    let data;
    if (/^\d{6}$/.test(symbol)) {
      const res = await api.runtime.sendMessage({
        type: "FETCH_KLINES",
        exchange: "stock",
        symbol,
        interval: "1d",
        limit: 400,
        reqId: ++fetchReqSeq,
      });
      if (!res || !res.ok) throw new Error((res && res.error) || t("status_fetch_failed"));
      // 截断到最近 400 根：东财 lmt 参数不严格生效可能返回上千根，全量 POST 会超服务器 body 上限
      const candles = (res.candles || []).slice(-400);
      if (!candles.length) throw new Error(t("status_fetch_failed"));
      const klines = candles.map((c) => ({
        timestamp: c.timestamp,
        open: c.open,
        high: c.high,
        low: c.low,
        close: c.close,
      }));
      data = await fetchLocalApi(
        `${ECONOMY_API_BASE}/api/signal`,
        ECONOMY_TIMEOUT,
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ symbol, refresh: 0, lang: LANG, klines, deviceId }),
        },
      );
    } else {
      data = await fetchLocalApi(
        `${ECONOMY_API_BASE}/api/signal?symbol=${encodeURIComponent(symbol)}&refresh=0&lang=${LANG}&deviceId=${encodeURIComponent(deviceId)}`,
      );
    }
    renderEconomyResult(data);
    // 定投利润：直接用当前标的的K线算（无条件，点方向预测就出）
    refreshEconomyDca();
    // 资金费率（加密标的）：数学确定的最可靠数据
    refreshEconomyFunding(data);
  } catch (err) {
    // 服务未启动 / 超时 / 网关错误：给出统一启动提示；其余错误展示服务端信息
    if (err.name === "AbortError" || !err.status || err.status === 502 || err.status === 404) {
      showEconomyUnavailable(err);
    } else {
      els.economyResult.style.display = "none";
      showEconomyStatus(t("economy_error", { msg: err.message || "" }), true);
    }
  } finally {
    btn.disabled = false;
    btn.textContent = t("economy_btn");
  }
}

/** 经济模型标的：永远跟随顶部标的输入框（手动修改就走顶部标的的正常路径） */
function updateEconomySymbolUI() {
  const textEl = document.getElementById("economy-symbol-text");
  if (!textEl) return;
  textEl.textContent = els.symbol.value.trim() || "-";
}

/** 顶部数据源的标的变化时，同步到经济模型标的显示 */
function syncEconomySymbol() {
  updateEconomySymbolUI();
}

/** 按当前语言重新拉取经济模型结果（语言切换时刷新，不消耗次数） */
async function refreshEconomyResult() {
  const symbol = economyApiSymbol();
  if (!symbol || !lastEconomyResult) return;
  try {
    // 语言切换刷新也要带 deviceId（服务端强制计数，与方向预测同额度）
    const deviceId = await getDeviceId();
    let data;
    if (/^\d{6}$/.test(symbol)) {
      // A股：与 runEconomySignal 一致，插件端抓日线 POST（服务端海外访问国内源不通，GET 必失败）
      const res = await api.runtime.sendMessage({
        type: "FETCH_KLINES",
        exchange: "stock",
        symbol,
        interval: "1d",
        limit: 400,
        reqId: ++fetchReqSeq,
      });
      if (!res || !res.ok) throw new Error((res && res.error) || t("status_fetch_failed"));
      const candles = (res.candles || []).slice(-400);
      if (!candles.length) throw new Error(t("status_fetch_failed"));
      const klines = candles.map((c) => ({
        timestamp: c.timestamp,
        open: c.open,
        high: c.high,
        low: c.low,
        close: c.close,
      }));
      data = await fetchLocalApi(`${ECONOMY_API_BASE}/api/signal`, ECONOMY_TIMEOUT, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ symbol, refresh: 0, lang: LANG, klines, deviceId }),
      });
    } else {
      data = await fetchLocalApi(
        `${ECONOMY_API_BASE}/api/signal?symbol=${encodeURIComponent(symbol)}&refresh=0&lang=${LANG}&deviceId=${encodeURIComponent(deviceId)}`,
      );
    }
    lastEconomyResult = data;
    renderEconomyResult(data);
    refreshEconomyDca();
  } catch {
    /* 刷新失败保留旧结果 */
  }
}

/** 资金费率 + 跨所套利（加密标的）：数学确定的最可靠数据 */
async function refreshEconomyFunding(r) {
  const el = document.getElementById("economy-funding-row");
  if (!el) return;
  const symbol = r && r.symbol;
  try {
    const [fa, arb] = await Promise.all([
      fetchLocalApi(`${ECONOMY_API_BASE}/api/funding-arb?symbols=${encodeURIComponent(symbol)}&threshold=0.05`, ECONOMY_TIMEOUT),
      fetchLocalApi(`${ECONOMY_API_BASE}/api/arbitrage?symbols=${encodeURIComponent(symbol)}&threshold=0.003`, ECONOMY_TIMEOUT),
    ]);
    const parts = [];
    // 资金费率年化（永续 vs 现货）
    const opps = fa && fa.opportunities ? fa.opportunities : [];
    const o = opps.find((x) => (x.symbol || "").toUpperCase() === String(symbol).toUpperCase()) || opps[0];
    if (o && o.annualizedPct != null) {
      const v = o.annualizedPct;
      const dir = v >= 0 ? t("economy_funding_long") : t("economy_funding_short");
      parts.push(`${t("economy_funding_rate")} ${v >= 0 ? "+" : ""}${v.toFixed(2)}%（${dir}）`);
      el.className = "economy-funding " + (v >= 0 ? "positive" : "negative");
    }
    // 跨所套利（有价差机会）或 各所价差（无机会时展示价差区间）
    const aopps = arb && arb.opportunities ? arb.opportunities : [];
    if (aopps.length) {
      const a = aopps[0];
      parts.push(`${t("economy_arb")} ${a.buyExchange}→${a.sellExchange} +${a.netPct}%`);
    } else if (arb && arb.prices) {
      const px = arb.prices[symbol];
      if (px) {
        const vals = Object.values(px).filter((x) => typeof x === "number");
        if (vals.length >= 2) {
          const spread = (((Math.max(...vals) - Math.min(...vals)) / Math.min(...vals)) * 100).toFixed(2);
          parts.push(`${t("economy_arb_spread")} ${spread}%`);
        }
      }
    }
    el.textContent = parts.length ? parts.join(" · ") : `${t("economy_funding_rate")}：-`;
  } catch (e) {
    el.textContent = `${t("economy_funding_rate")}：-`;
  }
}

/** 定投利润：拉当前标的日线，算 1月/6月/1年/3年/5年 按月定投等额总回报（数据不足显示 -） */
async function refreshEconomyDca() {
  try {
    // 数据源按标的自动判断（兼容经济面板格式：BTC-USD → 币安 BTCUSDT）
    const raw = els.symbol.value.trim();
    const ex = autoDetectExchange(raw) || els.exchange.value;
    const fetchRaw = ex === "binance" ? raw.replace(/-USD$/i, "USDT").replace(/[-\/]/g, "") : raw;
    const symbol = normalizeSymbol(ex, fetchRaw);
    if (!symbol) throw new Error("no symbol");
    const res = await api.runtime.sendMessage({
      type: "FETCH_KLINES",
      exchange: ex,
      symbol,
      interval: "1d",
      limit: 1300,
      reqId: ++fetchReqSeq,
    });
    const candles = res && res.ok ? res.candles : null;
    if (!candles || candles.length < 21) throw new Error("no candles");
    // 每月定投（约 21 个交易日投入一次）；窗口：1月21根 / 6月126根 / 1年252根 / 3年756根 / 5年1260根
    const windows = [
      ["dca-m1", 21],
      ["dca-m6", 126],
      ["dca-y1", 252],
      ["dca-y3", 756],
      ["dca-y5", 1260],
    ];
    for (const [pid, win] of windows) {
      const el = document.getElementById(`dca-${pid}`);
      if (!el) continue;
      if (candles.length < win) {
        el.textContent = "-";
        el.className = "";
        continue;
      }
      const dcaVal = dcaEqualReturn(candles.slice(-win), { period: 21 });
      if (dcaVal == null) {
        el.textContent = "-";
        el.className = "";
        continue;
      }
      el.textContent = `${dcaVal >= 0 ? "+" : ""}${(dcaVal * 100).toFixed(1)}%`;
      el.className = dcaVal >= 0 ? "bullish" : "bearish";
    }
  } catch {
    // 拉不到K线（退市/冷门/网络失败）时全部显示 -，让用户知道定投行存在
    for (const pid of ["dca-m1", "dca-m6", "dca-y1", "dca-y3", "dca-y5"]) {
      const el = document.getElementById(`dca-${pid}`);
      if (el) {
        el.textContent = "-";
        el.className = "";
      }
    }
  }
}

/** 经济模型信号接口的标的：加密货币统一成 BTC-USD 这类基础币-USD 写法；股票剥市场前缀（港股补 .HK 后缀） */
function economyApiSymbol() {
  // 标的一律取顶部 K线当前标的（手动改标的就是改顶部输入框）
  const raw = els.symbol.value.trim();
  if (!raw) return "";
  const exchange = els.exchange.value;
  if (["binance", "bybit", "okx"].includes(exchange)) {
    const normalized = normalizeSymbol(exchange, raw);
    const m = normalized.match(/^(.*?)(USDT|USDC|FDUSD|USD|BTC|ETH|EUR|TRY)$/);
    // OKX 归一化带横线（BTC-USDT），去掉尾横线避免 BTC--USD
    return m && m[1] ? `${m[1].replace(/-+$/, "")}-USD` : normalized;
  }
  // 股票/指数/期货：先规范化（stock 分支会加市场前缀），再剥离前缀；
  // 保留 ^（如 ^SOX），经济模型内置了 ^sox → sox 的指数映射
  const symbol = normalizeSymbol(exchange, raw);
  if (!symbol) return "";
  const cleaned = symbol.replace(/^(us|hk|jp|kr|tw|sh|sz|cn|nasdaq|nyse)\s*:/i, "");
  // 港股补 .HK 后缀（服务端只认 0700.HK）
  if (/^hk\s*:/i.test(symbol)) {
    return `${String(Number(cleaned)).padStart(4, "0")}.HK`;
  }
  return cleaned;
}

/** 错误信息本地化：后台抛出的中文错误模板翻译为当前语言 */
function errText(err) {
  const msg = String(err && err.message ? err.message : err);
  const hit = trAnalysis(msg);
  if (hit !== msg) return hit; // 完整句命中
  return trFragments(msg); // 组合/动态错误降级：固定中文片段替换，动态细节原样保留
}

// 接收后台的取数进度广播：显示“正在用哪个数据源”
api.runtime.onMessage.addListener((msg) => {
  if (msg && msg.type === "FETCH_PROGRESS" && msg.reqId && msg.reqId === fetchReqSeq) {
    if (msg.ok) {
      setStatus(t("status_source", { label: msg.label }));
    } else if (msg.label) {
      setStatus(t("status_fetch_progress", { label: msg.label }));
    }
  }
});

function showLoading() {
  els.analyzeBtn.textContent = t("btn_analyzing");
  els.analyzeBtn.disabled = true;
}

function hideLoading() {
  els.analyzeBtn.textContent = t("btn_analyze");
  els.analyzeBtn.disabled = false;
}

/** 切换数据源模式 */
function onExchangeChange() {
  const isPaste = els.exchange.value === "paste";
  const isStock = els.exchange.value === "stock";
  const isFutures = els.exchange.value === "futures";
  els.pasteRow.style.display = isPaste ? "flex" : "none";
  $("#binance-hint").style.display = els.exchange.value === "binance" ? "block" : "none";
  $("#stock-hint").style.display = isStock ? "block" : "none";
  $("#futures-hint").style.display = isFutures ? "block" : "none";
  // A股/国内期货没有 4h（腾讯行情与新浪期货分钟线均不支持），当前选 4h 时切到日线
  const intervalSel = els.interval;
  const fourH = [...intervalSel.options].find((o) => o.value === "4h");
  if (fourH) fourH.disabled = isStock || isFutures;
  if ((isStock || isFutures) && intervalSel.value === "4h") intervalSel.value = "1d";
  els.symbol.disabled = isPaste;
  els.interval.disabled = isPaste;
  els.limit.disabled = isPaste;
  if (isPaste) {
    els.symbol.value = "";
  } else {
    els.symbol.value = normalizeSymbol(els.exchange.value, els.symbol.value);
  }
  updateConnBar();
}

const EXCHANGE_LABEL = {
  get binance() { return t("ex_binance"); },
  okx: "OKX",
  bybit: "Bybit",
  get stock() { return t("ex_stock"); },
  get futures() { return t("ex_futures"); },
  get paste() { return t("ex_paste"); },
};

function exchangeLabel(exchange) {
  return EXCHANGE_LABEL[exchange] || String(exchange || "");
}

/** 顶部状态栏：显示当前数据源与标的 */
function updateConnBar() {
  const ex = els.exchange.value;
  const sym = els.symbol.value.trim();
  const iv = els.interval.value;
  if (ex === "paste") {
    els.connText.textContent = `📋 ${t("ex_paste")}`;
  } else if (sym) {
    els.connText.textContent = `🟢 ${EXCHANGE_LABEL[ex] || ex} | ${sym} (${iv})`;
  } else {
    els.connText.textContent = t("conn_not_connected");
  }
}

/** 自动识别开关：自动模式下折叠手动输入区 */
function onAutoDetectChange() {
  const auto = els.autoDetect.checked;
  els.manualRow.style.display = auto ? "none" : "flex";
  if (auto && els.exchange.value === "paste") {
    // 自动模式不适用手动粘贴，退回 OKX
    els.exchange.value = "okx";
    onExchangeChange();
  } else if (!auto) {
    onExchangeChange();
  }
}

/** 防抖重识别：页面切换交易对/周期后 300ms 内自动分析 */
function debounceRun(delay = 300) {
  clearTimeout(autoRunTimer);
  autoRunTimer = setTimeout(() => runAnalysis(), delay);
}

/** 手动粘贴数据解析 */
function parsePastedCsv(text) {
  const lines = text
    .trim()
    .split(/\r?\n/)
    .map((l) => l.trim())
    .filter(Boolean);
  const candles = [];
  for (const line of lines) {
    const parts = line.split(/[,\t]/).map((s) => s.trim());
    if (parts.length < 4) throw new Error(t("paste_need_4cols"));
    const ts = Number(parts[0]);
    const open = Number(parts[1]);
    const high = Number(parts[2]);
    const low = Number(parts[3]);
    const close = Number(parts[4]);
    const volume = parts.length >= 6 && parts[5] !== "" ? Number(parts[5]) : undefined;
    if ([open, high, low, close].some((v) => Number.isNaN(v) || v <= 0)) {
      throw new Error(t("paste_bad_row", { n: candles.length + 1 }));
    }
    candles.push({ timestamp: ts, open, high, low, close, volume });
  }
  if (candles.length < 2) throw new Error(t("paste_min2"));
  return candles;
}

let accountState = null;

async function refreshAccountUI() {
  const bar = $("#account-bar");
  if (!bar) return;
  bar.style.display = "flex";
  const statusEl = $("#account-status");
  const q = await getQuotaInfo();
  // 显示账号号（后 4 位，完整号在账户弹窗）——安装后自动生成，一台设备一个账号
  const accShort = accountState && accountState.account ? ` · ${t("account_no")} ${accountState.account.slice(-4)}` : "";
  if (accountState && accountState.expiresAt && isActive(accountState.expiresAt)) {
    statusEl.textContent =
      t("account_status_member", {
        date: new Date(accountState.expiresAt).toLocaleDateString(),
      }) + accShort;
  } else {
    statusEl.textContent = t("account_status_free", { n: q.remaining, limit: q.limit }) + accShort;
  }
}

async function syncAccount() {
  if (!UPDATE_CONFIG.licenseApiUrl) return;
  try {
    // 首装：自动创建匿名账号（安装即有账号，无邮箱、无登录）
    let account = await getAccountNumber();
    if (!account) {
      try {
        const created = await createAccount();
        account = created.account;
        accountState = {
          account,
          deviceId: created.devices && created.devices[0] ? created.devices[0] : await getDeviceId(),
          expiresAt: created.expiresAt || null,
          devices: created.devices || [],
        };
        await refreshAccountUI();
      } catch {
        // 网络失败等异常：退回手动「创建账号 / 登录已有账号」弹窗
        accountState = null;
        await refreshAccountUI();
        openAccountModal();
        return;
      }
    }
    const state = await refreshStatus();
    accountState = state;
    await refreshAccountUI();
  } catch {
    // 离线等失败场景使用本地缓存
    const cached = await getCachedState();
    accountState = cached && cached.expiresAt ? cached : null;
    await refreshAccountUI();
  }
}

async function openAccountModal() {
  const modal = $("#account-modal");
  const msg = $("#account-msg");
  msg.textContent = "";
  if (!UPDATE_CONFIG.licenseApiUrl) {
    msg.textContent = t("account_no_api");
    modal.style.display = "flex";
    return;
  }
  $(".account-modal-head h2").textContent = t("account_modal_title");
  localizeAccountModal();
  const info = $("#account-info");
  const choose = $("#account-choose");
  const loginForm = $("#account-login-form");
  const account = await getAccountNumber();
  if (account) {
    // 已有账号：显示账号信息 + 支付块
    choose.style.display = "none";
    loginForm.style.display = "none";
    info.style.display = "";
    $("#account-number").textContent = formatAccount(account);
    await syncAccount();
  } else {
    // 首装：显示「创建账号 / 登录已有账号」
    info.style.display = "none";
    loginForm.style.display = "none";
    choose.style.display = "";
  }
  const state = accountState || {};
  $("#account-expiry").textContent =
    state.expiresAt && isActive(state.expiresAt)
      ? new Date(state.expiresAt).toLocaleString()
      : t("account_no_expiry");
  $("#account-devices").textContent = `${(state.devices || []).length || 0}/${UPDATE_CONFIG.maxDevices || 2}`;
  modal.style.display = "flex";
}

function closeAccountModal() {
  $("#account-modal").style.display = "none";
}

/** 会员弹窗内静态文案随语言刷新（Gumroad 订阅块 + USDT 订阅块标题） */
function localizeAccountModal() {
  const set = (id, key, ph) => {
    const el = $(id);
    if (!el) return;
    if (ph) el.placeholder = t(key);
    else el.textContent = t(key);
  };
  set("#gumroad-title", "gumroad_title");
  set("#gumroad-buy-btn", "gumroad_buy");
  set("#gumroad-plan-month", "gumroad_plan_month");
  set("#gumroad-plan-year", "gumroad_plan_year");
  set("#gumroad-toggle-redeem", "gumroad_toggle_redeem");
  set("#gumroad-key-input", "gumroad_key_placeholder", true);
  set("#gumroad-redeem-btn", "gumroad_redeem");
  set("#gumroad-tip", "gumroad_tip");
  set("#pay-title", "pay_title");
}

async function onCreateAccount() {
  const msg = $("#account-msg");
  try {
    await createAccount();
    msg.textContent = t("account_create_ok");
    await openAccountModal();
    await syncAccount();
  } catch (err) {
    msg.textContent = t("account_error", { msg: err.message });
  }
}

async function onLoginAccount() {
  const msg = $("#account-msg");
  const acc = $("#account-login-input").value.trim();
  if (!acc || !/^\d{16}$/.test(acc.replace(/\D/g, ""))) {
    msg.textContent = t("account_login_placeholder"); // 格式不符：提示输入 16 位账号
    return;
  }
  try {
    // verifyDevice（可选）：换新设备登录时需填任一已绑定设备标识（审计 H7：防踢人占位）
    const verifyInput = $("#account-verify-input");
    const verify = verifyInput ? verifyInput.value.trim() : "";
    await loginAccount(acc, verify);
    msg.textContent = t("account_login_ok");
    $("#account-login-input").value = "";
    if (verifyInput) verifyInput.value = "";
    await openAccountModal();
    await syncAccount();
  } catch (err) {
    msg.textContent = t("account_error", { msg: err.message });
  }
}

async function onCopyAccount() {
  const account = await getAccountNumber();
  if (!account) return;
  const msg = $("#account-msg");
  try {
    await navigator.clipboard.writeText(account);
    msg.textContent = t("account_copied");
  } catch {
    // 剪贴板不可用时选中文本提示手动复制
    const num = $("#account-number");
    if (num) {
      const sel = window.getSelection();
      const range = document.createRange();
      range.selectNodeContents(num);
      sel.removeAllRanges();
      sel.addRange(range);
      msg.textContent = t("account_copied");
    }
  }
}

async function onUnbind() {
  const msg = $("#account-msg");
  try {
    await removeDevice();
    msg.textContent = t("account_ok_remove");
    accountState = null;
    await refreshAccountUI();
    await openAccountModal();
  } catch (err) {
    msg.textContent = t("account_error", { msg: err.message });
  }
}

/** 打开 Paddle 订阅收银台（月付/年付），支付成功后 webhook 自动给当前账号续期 */
async function onPaddleCheckout(plan) {
  const msg = $("#account-msg");
  try {
    await openCheckout(plan);
    if (msg) msg.textContent = t("paddle_open_hint");
  } catch (err) {
    if (msg) msg.textContent = t("account_error", { msg: (err && err.message) || "无法打开支付页" });
  }
}

/** Gumroad license key 兑换：服务器验证后给当前账号续期 */
async function onGumroadRedeem() {
  const input = $("#gumroad-key-input");
  const msg = $("#account-msg");
  const key = ((input && input.value) || "").trim();
  if (!key) {
    if (msg) msg.textContent = t("gumroad_key_empty");
    return;
  }
  const btn = $("#gumroad-redeem-btn");
  if (btn) btn.disabled = true;
  try {
    const res = await redeemGumroad(key);
    if (msg) {
      msg.textContent = res.plan === "year"
        ? t("gumroad_redeem_ok_year")
        : t("gumroad_redeem_ok_month");
    }
    if (input) input.value = "";
    await refreshAccountUI();
  } catch (err) {
    if (msg) msg.textContent = t("account_error", { msg: (err && err.message) || "兑换失败" });
  } finally {
    if (btn) btn.disabled = false;
  }
}

async function runAnalysis(manual = false) {
  if (els.analyzeBtn.disabled) return; // 防止重复触发
  const seq = ++analysisSeq;
  showLoading();
  try {
    let candles;
    let source = "";
    if (els.exchange.value === "paste") {
      candles = parsePastedCsv(els.paste.value);
      source = t("ex_paste");
    } else {
      const symbol = normalizeSymbol(els.exchange.value, els.symbol.value);
      if (!symbol) throw new Error(t("fill_symbol"));
      const interval = els.interval.value;
      const limit = Number(els.limit.value);
      const res = await api.runtime.sendMessage({
        type: "FETCH_KLINES",
        exchange: els.exchange.value,
        symbol,
        interval,
        limit,
        reqId: ++fetchReqSeq,
      });
      if (!res || !res.ok) throw new Error((res && res.error) || t("status_fetch_failed"));
      candles = res.candles;
      source = `${EXCHANGE_LABEL[els.exchange.value] || els.exchange.value} ${symbol} ${interval}${res.source ? `（${res.source}）` : ""}`;
    }
    if (seq !== analysisSeq) return; // 期间已发起演示/新识别，丢弃本次结果
    lastResult = analyze(candles);
    selectedRange = null;
    viewRange = null;
    updateConnBar();
    setStatus(
      t("status_analyzed_side", {
        source,
        n: lastResult.count,
        d: lastResult.detections.length,
        c: lastResult.chartPatterns.length,
        i: lastResult.indicatorSignals.length,
      }),
    );
    renderTab(activeTab);
  } catch (err) {
    setStatus(String(err && err.message ? err.message : err), true);
  } finally {
    hideLoading();
  }
}

/** 应用页面自动检测结果：填充表单并自动识别 */
function applyPageContext(ctx) {
  if (els.exchange.value === "paste") return;
  const exchange = ["okx", "bybit", "stock", "futures"].includes(ctx.exchange) ? ctx.exchange : "binance";
  const symbol = normalizeSymbol(exchange, ctx.raw);
  if (!symbol) return;
  els.exchange.value = exchange;
  els.symbol.value = symbol;
  // 记住“刚才在看什么”，K线查看器优先按这个打开，避免误取最近访问的其它页面
  lastViewerContext = { exchange, symbol };
  api.storage.local.set({ lastViewerContext });
  onExchangeChange();
  syncEconomySymbol();
  setStatus(t("status_detected_page", { ex: EXCHANGE_LABEL[exchange] || exchange, sym: symbol }));
  debounceRun(300);
}

let appliedContextKey = "";
let lastViewerContext = null;

/** 同一上下文只应用一次，避免重复触发 */
function applyContextIfNew(ctx) {
  const key = ctx ? `${ctx.exchange}:${ctx.raw}` : "";
  if (!key || key === appliedContextKey) return;
  appliedContextKey = key;
  applyPageContext(ctx);
}

/** 直接读取当前标签页，识别交易所与交易对（不依赖内容脚本） */
async function detectActiveTab() {
  try {
    const tabs = await api.tabs.query({ active: true, currentWindow: true });
    const tab = tabs && tabs[0];
    if (!tab || !tab.url) return null;
    return detectPageContext(tab.url, tab.title || "");
  } catch {
    return null;
  }
}

/**
 * 同步页面上下文：优先按当前标签页检测并应用；
 * 标签页检测不到时，回退到内容脚本最近写入的 pageContext（例如浏览器不允许查询标签页的场景）。
 * silent=true 时不在无结果时提示。
 */
function syncContext(silent = false) {
  if (!els.autoDetect.checked) return;
  detectActiveTab().then((ctx) => {
    if (ctx) {
      applyContextIfNew(ctx);
      return;
    }
    api.storage.local.get("pageContext").then((data) => {
      const pc = data.pageContext;
      // pageContext 由内容脚本在页面内写入，按页面隔离，不会串到其它窗口的标的
      if (pc && pc.key) {
        applyContextIfNew(pc);
      } else if (!silent && !els.status.textContent) {
        setStatus(
          t("status_no_page_perm"),
        );
      }
    }).catch(() => {});
  });
}

function makeCard({ title, titleExtra, badges, summary, detailBlocks, levels, diagram, onClick }) {
  const card = document.createElement("div");
  card.className = "card";

  const header = document.createElement("div");
  header.className = "card-header";
  const titleEl = document.createElement("span");
  titleEl.className = "card-title";
  titleEl.textContent = title;
  header.appendChild(titleEl);
  if (titleExtra) {
    const extra = document.createElement("span");
    extra.className = "candle-index";
    extra.textContent = titleExtra;
    header.appendChild(extra);
  }
  for (const b of badges) header.appendChild(b);
  card.appendChild(header);

  if (diagram) {
    const d = document.createElement("div");
    d.className = "pattern-diagram";
    d.innerHTML = diagram;
    card.appendChild(d);
  }

  const summaryEl = document.createElement("div");
  summaryEl.className = "card-summary";
  summaryEl.textContent = summary;
  card.appendChild(summaryEl);

  if (levels) {
    const lv = document.createElement("div");
    lv.className = "levels";
    lv.textContent = t("ref_levels", { v: Object.entries(levels)
      .map(([k, v]) => `${k}=${typeof v === "number" ? v.toFixed(4) : v}`)
      .join("  ") });
    card.appendChild(lv);
  }

  if (detailBlocks && detailBlocks.length) {
    const detail = document.createElement("div");
    detail.className = "card-detail";
    for (const block of detailBlocks) {
      const b = document.createElement("div");
      b.className = "detail-block";
      const h = document.createElement("h4");
      h.textContent = block.title;
      const p = document.createElement("p");
      p.textContent = block.text;
      b.appendChild(h);
      b.appendChild(p);
      detail.appendChild(b);
    }
    card.appendChild(detail);
    header.addEventListener("click", () => card.classList.toggle("open"));
  }

  if (onClick) header.addEventListener("click", onClick);
  return card;
}

let diagramPop = null;
function ensureDiagramPop() {
  if (diagramPop) return diagramPop;
  diagramPop = document.createElement("div");
  diagramPop.className = "diagram-pop";
  document.body.appendChild(diagramPop);
  return diagramPop;
}

function positionDiagramPop(pop, e) {
  const pad = 12;
  let x = e.clientX + pad;
  let y = e.clientY + pad;
  const rect = pop.getBoundingClientRect();
  if (x + rect.width > window.innerWidth - 4) x = Math.max(4, e.clientX - rect.width - pad);
  if (y + rect.height > window.innerHeight - 4) y = Math.max(4, e.clientY - rect.height - pad);
  pop.style.left = `${x}px`;
  pop.style.top = `${y}px`;
}

/** 形态卡片悬停时显示示例图解 */
function bindDiagramHover(el, pattern) {
  if (!el || !pattern) return;
  el.addEventListener("mouseenter", (e) => {
    const pop = ensureDiagramPop();
    pop.innerHTML = `<div class="diagram-name">${patternName(pattern)}</div>${patternDiagramSvg(pattern)}`;
    pop.style.display = "block";
    positionDiagramPop(pop, e);
  });
  el.addEventListener("mousemove", (e) => positionDiagramPop(ensureDiagramPop(), e));
  el.addEventListener("mouseleave", () => {
    if (diagramPop) diagramPop.style.display = "none";
  });
}

function renderKlineTab() {
  const r = lastResult;
  const content = els.content;
  content.innerHTML = "";
  if (!r) {
    content.innerHTML =
      `<div class="empty">${t("empty_need_run")}</div>`;
    return;
  }

  const scope = document.querySelector('input[name="klineScope"]:checked');
  const latestOnly = !scope || scope.value === "latest";
  const ranks = { high: 3, medium: 2, low: 1 };
  const minRank = ranks[els.signalFilter.value] || 1;
  const FILTER_LABEL = { high: () => t("filter_high"), medium: () => t("filter_medium"), all: () => t("filter_all") };
  const filterLabel = (FILTER_LABEL[els.signalFilter.value] || FILTER_LABEL.all)();
  // 「全部（含历史）」展示全部历史形态，不再受信号强度过滤限制；
  // 「只看最新K线」仍按信号强度过滤最新一根K线上的形态。
  const scoped = latestOnly
    ? r.detections.filter(
        (d) => d.index === r.count - 1 && d.context && ranks[d.context.priority] >= minRank,
      )
    : r.detections.filter((d) => d.context);

  const bar = document.createElement("div");
  bar.className = "summary-bar";
  bar.innerHTML = `
    <div class="summary-chip">${t("chip_kline")} <b>${r.count}</b></div>
    <div class="summary-chip">${latestOnly ? t("chip_patterns_suffix", { label: filterLabel }) : t("chip_all_patterns")} <b>${scoped.length}</b></div>
    <div class="summary-chip">${t("chip_bull")} <b>${scoped.filter((d) => d.direction === "bullish").length}</b></div>
    <div class="summary-chip">${t("chip_bear")} <b>${scoped.filter((d) => d.direction === "bearish").length}</b></div>
    <div class="summary-chip">${t("chip_high")} <b>${scoped.filter((d) => d.context && d.context.priority === "high").length}</b></div>
  `;
  content.appendChild(bar);

  // 定投利润：用分析K线算「定投等额」vs「一次性买入持有」（利润对比，与形态无关）
  if (r.candles && r.candles.length >= 40) {
    const dcaVal = dcaEqualReturn(r.candles, { period: 20 });
    const firstClose = Number(r.candles[0].close);
    const lastClose = Number(r.candles[r.candles.length - 1].close);
    const buyHold = firstClose > 0 ? (lastClose - firstClose) / firstClose : null;
    const fmtPct = (v) => (v == null ? "-" : `${v >= 0 ? "+" : ""}${(v * 100).toFixed(1)}%`);
    const dcaCard = document.createElement("div");
    dcaCard.className = "dca-card";
    const dcaRow = document.createElement("div");
    dcaRow.className = "dca-row";
    const dcaLabel = document.createElement("span");
    dcaLabel.textContent = t("analysis_dca_title");
    const dcaValEl = document.createElement("b");
    dcaValEl.textContent = fmtPct(dcaVal);
    dcaValEl.className = dcaVal != null && dcaVal >= 0 ? "bullish" : "bearish";
    const buyRow = document.createElement("div");
    buyRow.className = "dca-row";
    const buyLabel = document.createElement("span");
    buyLabel.textContent = t("analysis_buyhold");
    const buyValEl = document.createElement("b");
    buyValEl.textContent = fmtPct(buyHold);
    buyValEl.className = buyHold != null && buyHold >= 0 ? "bullish" : "bearish";
    const dcaNote = document.createElement("div");
    dcaNote.className = "dca-note";
    dcaNote.textContent = t("analysis_dca_note", { n: r.candles.length });
    dcaRow.append(dcaLabel, dcaValEl);
    buyRow.append(buyLabel, buyValEl);
    dcaCard.append(dcaRow, buyRow, dcaNote);
    content.appendChild(dcaCard);
  }

  if (!scoped.length) {
    content.appendChild(
      emptyDiv(
        latestOnly
          ? t("empty_latest_none", { label: filterLabel })
          : t("empty_no_patterns"),
      ),
    );
    return;
  }

  const sorted = scoped.slice().sort((a, b) => b.index - a.index);
  const MAX_SHOW = 100;
  const shown = sorted.slice(0, MAX_SHOW);
  if (!latestOnly && sorted.length > MAX_SHOW) {
    const note = document.createElement("div");
    note.className = "empty";
    note.textContent = t("note_many_hits", { n: sorted.length, m: MAX_SHOW });
    content.appendChild(note);
  }
  for (const d of shown) {
    const priorityLabel =
      d.context && d.context.priority === "high"
        ? t("prio_high")
        : d.context && d.context.priority === "medium"
          ? t("prio_mid")
          : t("prio_low");
    const badges = [
      badge(d.direction, DIRECTION_TEXT[d.direction]),
      badge("neutral", KIND_TEXT[d.kind]),
      badge(`trend-${d.trend}`, TREND_TEXT[d.trend]),
      d.context ? badge(`priority-${d.context.priority}`, `${priorityLabel} ${t("pts", { n: d.context.score })}`) : null,
    ];
    const validBadges = badges.filter(Boolean);
    const starsEl = document.createElement("span");
    starsEl.className = "stars";
    starsEl.textContent = stars(d.reliability);
    validBadges.push(starsEl);
    const card = makeCard({
      title: patternName(d),
      titleExtra: t("kline_range", { idx: d.index + 1, from: d.candleRange[0] + 1, to: d.candleRange[1] + 1 }),
      badges: validBadges,
      summary: patternField(d, "summary"),
      detailBlocks: [
        { title: t("detail_meaning"), text: patternField(d, "description") },
        { title: t("detail_rules"), text: patternField(d, "rules") },
        { title: t("detail_notes"), text: patternField(d, "notes") },
        ...(d.context && d.context.reasons.length
          ? [{ title: t("sig_score", { n: d.context.score }), text: d.context.reasons.map((r) => trAnalysis(r)).join("；") }]
          : []),
      ],
      onClick: () => {
        selectedRange = d.candleRange;
        // 定位到形态所在区间并放大（留一点左右余量）
        const [cs, ce] = d.candleRange;
        const n = lastResult.count;
        const span = Math.max(10, ce - cs + 8);
        let s = Math.max(0, Math.round((cs + ce) / 2 - span / 2));
        s = Math.min(s, Math.max(0, n - span));
        viewRange = [s, Math.min(n - 1, s + span - 1)];
        redrawChart();
        setStatus(t("status_located", { name: patternName(d), from: d.candleRange[0] + 1, to: d.candleRange[1] + 1 }));
      },
    });
    bindDiagramHover(card, d);
    content.appendChild(card);
  }
}

function renderMarketTab() {
  const content = els.content;
  content.innerHTML = "";
  const r = lastResult;
  if (!r) {
    content.innerHTML = `<div class="empty">${t("empty_run_first")}</div>`;
    return;
  }
  const mc = r.marketContext;
  if (!mc) {
    content.innerHTML = `<div class="empty">${t("empty_market_nodata")}</div>`;
    return;
  }
  const fmt = (v) => (v == null ? "-" : typeof v === "number" ? v.toFixed(4) : String(v));

  const btnRow = document.createElement("div");
  btnRow.style.marginBottom = "10px";
  const btn = document.createElement("button");
  btn.className = "primary";
  btn.id = "mtf-btn";
  const tfLabel = els.exchange.value === "futures" ? t("mtf_tf_futures") : t("mtf_tf");
  btn.textContent = t("mtf_btn", { tf: tfLabel });
  btn.addEventListener("click", runMultiTimeframe);
  btnRow.appendChild(btn);
  content.appendChild(btnRow);

  const volSummary = [
    `VWAP：${fmt(mc.vwap)}`,
    `OBV：${mc.obv != null ? mc.obv.toFixed(0) : "-"}`,
    mc.volumeDivergence ? trAnalysis(mc.volumeDivergence.message) : trAnalysis("近期没有量价背离"),
  ].join(" ｜ ");
  content.appendChild(
    makeCard({
      title: t("market_vol"),
      badges: [],
      summary: volSummary,
    }),
  );
  // 当前适配策略（数据不足时自动跳过）
  const strategyRecs = recommendStrategies(r.candles, r, 3);
  if (strategyRecs.length) {
    content.appendChild(
      makeCard({
        title: t("market_strategy"),
        badges: [badge("priority-high", strategyName(strategyRecs[0].strategy))],
        summary: strategyRecs
          .map((x) => `${strategyName(x.strategy)} · ${x.score}`)
          .join("；"),
        detailBlocks: strategyRecs.slice(0, 3).map((x) => {
          const plan = localizePlan(buildStrategyPlan(x.strategy, r.candles, r, {}), x.strategy);
          const planText = plan
            ? [
                plan.action,
                ...(plan.direction === "wait"
                  ? plan.steps.slice(0, 2)
                  : [
                      plan.trigger.text,
                      `${t("entry_ref")}：${plan.entry.type} ${plan.entry.price.toFixed(4)}`,
                      plan.stopLoss ? plan.stopLoss.text : "",
                      plan.takeProfit ? plan.takeProfit.text : "",
                      plan.addOn ? `${t("add_rule")}：${plan.addOn.text}` : "",
                      `${t("exit_rule")}：${plan.exit}`,
                      ...plan.steps.slice(0, 3),
                    ]),
                ...plan.warnings,
                t("plan_warn"),
              ]
                .filter(Boolean)
                .join("；")
            : "";
          return {
            title: `${strategyName(x.strategy)} · ${x.score}`,
            text: `${x.reasons.map((r) => trAnalysis(r)).join("；")}。${strategyField(x.strategy, "summary")}。${t("rules_label")}：${strategyField(x.strategy, "rules")}${planText ? `。${t("plan_title_suffix")}：${planText}` : ""}`,
          };
        }),
      }),
    );
  }

  const supports = mc.keyLevels.supports;
  const resistances = mc.keyLevels.resistances;
  content.appendChild(
    makeCard({
      title: t("market_supports"),
      badges: [],
      summary: supports.length
        ? supports.map((l) => `${l.price.toFixed(4)}${t("touch_suffix", { n: l.touches })}`).join("，")
        : t("status_none"),
      detailBlocks: [
        { title: t("detail_note"), text: t("supports_note") },
      ],
    }),
  );
  content.appendChild(
    makeCard({
      title: t("market_resists"),
      badges: [],
      summary: resistances.length
        ? resistances.map((l) => `${l.price.toFixed(4)}${t("touch_suffix", { n: l.touches })}`).join("，")
        : t("status_none"),
      detailBlocks: [
        { title: t("detail_note"), text: t("resists_note") },
      ],
    }),
  );

  const pocParts = [`${t("poc_label")}${fmt(mc.keyLevels.poc)}`];
  if (mc.keyLevels.hvn.length) pocParts.push(`${t("hvn_label")}${mc.keyLevels.hvn.map(fmt).join("，")}`);
  if (mc.keyLevels.lvn.length) pocParts.push(`${t("lvn_label")}${mc.keyLevels.lvn.map(fmt).join("，")}`);
  content.appendChild(
    makeCard({
      title: t("market_vprofile"),
      badges: [],
      summary: pocParts.join(" ｜ "),
      detailBlocks: [
        { title: t("detail_note"), text: t("vprofile_note") },
      ],
    }),
  );

  if (mc.fibonacci) {
    content.appendChild(
      makeCard({
        title: `Fibonacci (${mc.fibonacci.trend === "up" ? t("fib_up_wave") : t("fib_down_wave")})`,
        badges: [],
        summary: mc.fibonacci.levels
          .map((l) => `${l.ratio}=${l.price.toFixed(4)}`)
          .join("，"),
        detailBlocks: [
          { title: t("detail_note"), text: t("fib_note") },
        ],
      }),
    );
  }

  if (lastResonance) {
    const head = document.createElement("h3");
    head.textContent = t("mtf_head");
    head.style.cssText = "margin:14px 0 8px;color:var(--accent);font-size:13px";
    content.appendChild(head);
    const tfRow = document.createElement("div");
    tfRow.className = "summary-bar";
    for (const tf of lastResonance.timeframes) {
      const chip = document.createElement("div");
      chip.className = "summary-chip";
      chip.innerHTML = `${tf.interval} <b>${TREND_TEXT[tf.trend]}</b>`;
      tfRow.appendChild(chip);
    }
    content.appendChild(tfRow);
    if (!lastResonance.signals.length) {
      content.appendChild(emptyDiv(t("mtf_empty")));
    } else {
      for (const s of lastResonance.signals) {
        content.appendChild(
          makeCard({
            title: `${trAnalysis(s.nameZh)}（${s.interval}）`,
            badges: [
              badge(s.direction, DIRECTION_TEXT[s.direction]),
              badge(s.aligned ? "bullish" : "bearish", s.aligned ? t("mtf_aligned") : t("mtf_conflict")),
            ],
            summary: trAnalysis(s.summary, LANG, s.nameEn || s.nameZh),
            detailBlocks: [
              { title: t("mtf_large_trend"), text: s.largerTrends.join("，") },
              {
                title: t("detail_note"),
                text: s.aligned
                  ? t("mtf_note")
                  : t("mtf_note_conflict"),
              },
            ],
          }),
        );
      }
    }
  }
}

/** 拉取单个周期的K线 */
async function fetchKlines(exchange, symbol, interval, limit) {
  const res = await api.runtime.sendMessage({
    type: "FETCH_KLINES",
    exchange,
    symbol,
    interval,
    limit,
    reqId: ++fetchReqSeq,
  });
  if (!res || !res.ok) throw new Error((res && res.error) || t("status_fetch_failed"));
  return res.candles;
}

/** 多周期共振分析：并行拉取 15m/1h/4h/日线 */
async function runMultiTimeframe() {
  if (els.exchange.value === "paste") {
    setStatus(t("mtf_need_network"), true);
    return;
  }
  const exchange = els.exchange.value;
  const symbol = normalizeSymbol(exchange, els.symbol.value);
  if (!symbol) {
    setStatus(t("fill_symbol"), true);
    return;
  }
  const btn = document.getElementById("mtf-btn");
  if (btn) {
    btn.textContent = t("btn_analyzing");
    btn.disabled = true;
  }
  const isFutures = exchange === "futures";
  const intervals = isFutures ? ["15m", "1h", "1d"] : ["15m", "1h", "4h", "1d"];
  setStatus(t("status_fetching_sym", { sym: symbol, iv: intervals.join(" / ") }));
  try {
    const sets = await Promise.all(
      intervals.map(async (interval) => ({
        interval,
        candles: await fetchKlines(exchange, symbol, interval, 200),
      })),
    );
    lastResonance = analyzeMultiTimeframe(sets);
    setStatus(t("mtf_done", { n: sets.length, m: lastResonance.signals.length }));
    renderMarketTab();
  } catch (err) {
    setStatus(errText(err), true);
  } finally {
    if (btn) {
      btn.textContent = t("mtf_btn", { tf: isFutures ? t("mtf_tf_futures") : t("mtf_tf") });
      btn.disabled = false;
    }
  }
}

function renderBacktestTab() {
  const content = els.content;
  // 保存当前表单值（回测结果重建时保留用户参数，不重置为默认）
  const BT_FORM_IDS = ["bt-bars", "bt-strategy", "bt-strategy-dir", "bt-strategy-hold", "bt-strategy-leverage", "bt-strategy-amount", "bt-strategy-range", "bt-threshold", "bt-direction", "bt-leverage", "bt-amount", "bt-range", "bt-tp", "bt-sl", "bt-hold"];
  const btFormVals = {};
  for (const id of BT_FORM_IDS) {
    const el = document.getElementById(id);
    if (el) btFormVals[id] = el.value;
  }
  content.innerHTML = "";

  const strategyForm = document.createElement("div");
  strategyForm.className = "control-panel bt-form";
  strategyForm.style.borderBottom = "1px solid var(--line)";
  strategyForm.innerHTML = `
    <div class="row">
      <label class="field">
        <span>${t("bt_strategy")}</span>
        <select id="bt-strategy">
          ${STRATEGIES.map((s) => `<option value="${s.id}">${strategyName(s)}</option>`).join("")}
        </select>
      </label>
      <label class="field">
        <span>${t("bt_direction")}</span>
        <select id="bt-strategy-dir">
          <option value="both" selected>${t("dir_both")}</option>
          <option value="long">${t("dir_long")}</option>
          <option value="short">${t("dir_short")}</option>
        </select>
      </label>
      <label class="field">
        <span>${t("bt_hold")}</span>
        <input id="bt-strategy-hold" type="number" value="20" min="1" max="200" />
      </label>
      <label class="field">
        <span>${t("bt_leverage")}</span>
        <select id="bt-strategy-leverage">
          <option value="1" selected>1x</option>
          <option value="2">2x</option>
          <option value="3">3x</option>
          <option value="5">5x</option>
          <option value="10">10x</option>
          <option value="20">20x</option>
        </select>
      </label>
      <label class="field">
        <span>${t("bt_amount")}</span>
        <input id="bt-strategy-amount" type="number" value="10000" min="0" step="100" />
      </label>
      <label class="field">
        <span>${t("bt_range")}</span>
        <select id="bt-strategy-range">
          <option value="all" selected>${t("range_all")}</option>
          <option value="1M">${t("range_1m")}</option>
          <option value="3M">${t("range_3m")}</option>
          <option value="6M">${t("range_6m")}</option>
          <option value="1Y">${t("range_1y")}</option>
        </select>
      </label>
      <button id="bt-strategy-run" class="primary">${t("btn_run_strategy")}</button>
    </div>
    <div class="panel-tip">
      ${t("bt_tip_strategy")}
    </div>
  `;
  content.appendChild(strategyForm);
  strategyForm.querySelector("#bt-strategy-run").addEventListener("click", runStrategyBacktest);
  if (lastStrategyBacktest) {
    content.appendChild(renderStrategyBacktestResult(lastStrategyBacktest));
  }

  const form = document.createElement("div");
  form.className = "control-panel bt-form";
  form.style.borderBottom = "1px solid var(--line)";
  form.innerHTML = `
    <div class="row">
      <label class="field">
        <span>${t("bt_bars")}</span>
        <select id="bt-bars">
          <option value="500">500</option>
          <option value="1000" selected>1000</option>
          <option value="1500">1500 (OKX)</option>
        </select>
      </label>
      <label class="field">
        <span>${t("bt_threshold")}</span>
        <input id="bt-threshold" type="number" value="2" step="0.5" min="0.5" max="10" />
      </label>
      <label class="field">
        <span>${t("bt_dir_filter")}</span>
        <select id="bt-direction">
          <option value="both" selected>${t("dir_both")}</option>
          <option value="bullish">${t("dir_long")}</option>
          <option value="bearish">${t("dir_short")}</option>
        </select>
      </label>
      <label class="field">
        <span>${t("bt_leverage")}</span>
        <select id="bt-leverage">
          <option value="1" selected>1x</option>
          <option value="2">2x</option>
          <option value="3">3x</option>
          <option value="5">5x</option>
          <option value="10">10x</option>
          <option value="20">20x</option>
        </select>
      </label>
      <label class="field">
        <span>${t("bt_amount")}</span>
        <input id="bt-amount" type="number" value="10000" min="0" step="100" />
      </label>
      <label class="field">
        <span>${t("bt_range")}</span>
        <select id="bt-range">
          <option value="all" selected>${t("range_all")}</option>
          <option value="1M">${t("range_1m")}</option>
          <option value="3M">${t("range_3m")}</option>
          <option value="6M">${t("range_6m")}</option>
          <option value="1Y">${t("range_1y")}</option>
        </select>
      </label>
    </div>
    <div class="row">
      <label class="field">
        <span>${t("bt_tp")}</span>
        <input id="bt-tp" type="number" value="2" step="0.5" min="0" max="50" placeholder="2" />
      </label>
      <label class="field">
        <span>${t("bt_sl")}</span>
        <input id="bt-sl" type="number" value="1" step="0.5" min="0" max="50" placeholder="1" />
      </label>
      <label class="field">
        <span>${t("bt_hold2")}</span>
        <input id="bt-hold" type="number" value="5" min="0" step="1" />
      </label>
    </div>
    <div class="row">
      <button id="bt-run" class="primary">${t("bt_run")}</button>
    </div>
  `;
  content.appendChild(form);
  form.querySelector("#bt-run").addEventListener("click", runBacktest);

  // 回填用户之前填的表单值
  for (const [id, val] of Object.entries(btFormVals)) {
    const el = document.getElementById(id);
    if (el) el.value = val;
  }

  if (!lastBacktest) {
    content.appendChild(
      emptyDiv(
        t("empty_bt_hint"),
      ),
    );
    return;
  }

  // 最新信号交易计划
  if (backtestCandles) {
    const r = analyze(backtestCandles);
    const latest = r.detections
      .filter((d) => d.index === backtestCandles.length - 1 && d.direction !== "neutral")
      .sort((a, b) => (b.context && b.context.score || 0) - (a.context && a.context.score || 0));
    if (latest.length) {
      const best = latest[0];
      const plan = suggestTradePlan(best, backtestCandles);
      content.appendChild(
        makeCard({
          title: t("bt_latest_plan", { name: patternName(best) }),
          badges: [badge(best.direction, DIRECTION_TEXT[best.direction])],
          summary: t("plan_line", {
            e: plan.entry.toFixed(4),
            s: plan.stopLoss.toFixed(4),
            t: plan.takeProfit.toFixed(4),
            r: plan.rr.toFixed(2),
          }),
          detailBlocks: [
            { title: t("stop_basis"), text: trAnalysis(plan.note) },
            {
              title: t("detail_note"),
              text: t("tradeplan_static_note"),
            },
          ],
        }),
      );
    }
  }

  // 胜率统计表
  const head = document.createElement("h3");
  const simText =
    lastBacktest.tpPct != null || lastBacktest.slPct != null
      ? t("bt_sim_text", {
          tp: lastBacktest.tpPct != null ? lastBacktest.tpPct * 100 + "%" : "-",
          sl: lastBacktest.slPct != null ? lastBacktest.slPct * 100 + "%" : "-",
          hold: lastBacktest.holdBars || t("status_none"),
        })
      : "";
  const dirText =
    lastBacktest.direction === "bullish"
      ? t("dir_long")
      : lastBacktest.direction === "bearish"
        ? t("dir_short")
        : t("dir_both");
  const rangeText = lastBacktest.range === "all" || !lastBacktest.range ? t("range_all") : lastBacktest.range;
  head.textContent =
    t("bt_head", {
      threshold: (lastBacktest.thresholdPct * 100).toFixed(0),
      dir: dirText,
      lev: lastBacktest.leverage || 1,
      range: rangeText,
      amount: lastBacktest.amount || 0,
      min: lastBacktest.minSamples,
      sim: simText,
    });
  head.style.cssText = "margin:14px 0 4px;color:var(--accent);font-size:13px";
  content.appendChild(head);

  if (!lastBacktest.items.length) {
    content.appendChild(emptyDiv(t("samples_insufficient")));
  } else {
    const table = document.createElement("table");
    table.className = "bt-table";
    const thead = document.createElement("thead");
    const simCol = !!lastBacktest.hasSim;
    thead.innerHTML =
      `<tr><th>${t("th_pattern")}</th><th>${t("th_dir")}</th><th>${t("th_samples")}</th><th>${t("th_win3")}</th><th>${t("th_win5")}</th><th>${t("th_win10")}</th><th>${t("th_ret5")}</th><th>${t("th_mfe")}</th>${simCol ? `<th>${t("th_sim_win")}</th><th>${t("th_avg_r")}</th>` : ""}<th>${t("th_comment")}</th></tr>`;
    table.appendChild(thead);
    const tbody = document.createElement("tbody");
    for (const item of lastBacktest.items) {
      const h = (bars) => {
        const row = item.horizons.find((x) => x.bars === bars);
        return row ? `${(row.winRate * 100).toFixed(0)}%` : "-";
      };
      const h5 = item.horizons.find((x) => x.bars === 5);
      const ret5 = h5 ? h5.avgReturn : 0;
      const amount = lastBacktest.amount || 0;
      const money5 = ret5 * amount;
      const sim = item.sim;
      const comment =
        h5 && h5.winRate >= 0.6
          ? t("comment_reliable")
          : h5 && h5.winRate >= 0.5
            ? t("comment_avg")
            : t("comment_weak");
      const tr = document.createElement("tr");
      tr.innerHTML = `
        <td class="name">${item.nameZh}</td>
        <td class="${item.direction}">${DIRECTION_TEXT[item.direction]}</td>
        <td>${item.samples}</td>
        <td>${h(3)}</td>
        <td>${h(5)}</td>
        <td>${h(10)}</td>
        <td>${(ret5 * 100).toFixed(2)}%${amount ? `（${money5 >= 0 ? "+" : ""}${money5.toFixed(0)}）` : ""}</td>
        <td>${(item.mfeAvg * 100).toFixed(1)}% / ${(item.maeAvg * 100).toFixed(1)}%</td>
        ${simCol ? `<td>${sim ? (sim.winRate * 100).toFixed(0) + "%" : "-"}</td><td>${sim && sim.avgR != null ? sim.avgR.toFixed(2) + "R" : "-"}</td>` : ""}
        <td>${comment}</td>
      `;
      tbody.appendChild(tr);
    }
    table.appendChild(tbody);
    content.appendChild(table);
  }

  const note = document.createElement("div");
  note.className = "bt-note";
  // 定投等额总回报（同期无脑定投基准），放在模板提示之前
  if (lastBacktest.dca != null) {
    const dcaLine = document.createElement("div");
    dcaLine.textContent =
      t("bt_dca_line", {
        ret: `${lastBacktest.dca >= 0 ? "+" : ""}${(lastBacktest.dca * 100).toFixed(1)}%`,
      });
    dcaLine.style.color = lastBacktest.dca >= 0 ? "var(--up)" : "var(--down)";
    note.appendChild(dcaLine);
  }
  const tplLine = document.createElement("div");
  tplLine.textContent =
    t("bt_note_pattern", {
      lev: lastBacktest.leverage || 1,
      amount: lastBacktest.amount || 0,
      liq: lastBacktest.leverage > 1 ? trAnalysis(`满仓杠杆下价格反向波动约 ${(100 / lastBacktest.leverage).toFixed(1)}% 即爆仓。`) : "",
    });
  note.appendChild(tplLine);
  content.appendChild(note);
}

/** 开始回测 */
const BACKTEST_RANGES = {
  "1M": 30 * 24 * 3600 * 1000,
  "3M": 90 * 24 * 3600 * 1000,
  "6M": 180 * 24 * 3600 * 1000,
  "1Y": 365 * 24 * 3600 * 1000,
};

/** 按时间范围截取K线（以最后一根K线的时间为基准） */
function sliceCandlesByRange(candles, range) {
  const ms = BACKTEST_RANGES[range];
  if (!ms || !Array.isArray(candles) || !candles.length) return candles;
  const ref = candles[candles.length - 1].timestamp || Date.now();
  return candles.filter((c) => !c.timestamp || c.timestamp >= ref - ms);
}

async function runBacktest() {
  const bars = Number(document.getElementById("bt-bars").value);
  const thresholdPct = Number(document.getElementById("bt-threshold").value) / 100;
  const tpInput = document.getElementById("bt-tp");
  const slInput = document.getElementById("bt-sl");
  const holdInput = document.getElementById("bt-hold");
  const tpPct = tpInput && tpInput.value !== "" ? Number(tpInput.value) / 100 : null;
  const slPct = slInput && slInput.value !== "" ? Number(slInput.value) / 100 : null;
  const holdBars = holdInput && Number(holdInput.value) > 0 ? Number(holdInput.value) : null;
  const hasSim = tpPct != null || slPct != null || holdBars != null;
  const direction = document.getElementById("bt-direction").value;
  const leverage = Number(document.getElementById("bt-leverage").value) || 1;
  const amount = Math.max(0, Number(document.getElementById("bt-amount").value) || 0);
  const range = document.getElementById("bt-range").value;
  const btn = document.getElementById("bt-run");
  if (btn) {
    btn.textContent = t("btn_backtesting");
    btn.disabled = true;
  }
  try {
    let candles;
    if (els.exchange.value === "paste") {
      candles = parsePastedCsv(els.paste.value);
    } else {
      const exchange = els.exchange.value;
      const symbol = normalizeSymbol(exchange, els.symbol.value);
      if (!symbol) throw new Error(t("fill_symbol"));
      setStatus(t("status_fetching_sym", { sym: symbol, iv: `${bars} bars` }));
      const res = await api.runtime.sendMessage({
        type: "FETCH_HISTORY",
        exchange,
        symbol,
        interval: els.interval.value,
        bars,
        reqId: ++fetchReqSeq,
      });
      if (!res || !res.ok) throw new Error((res && res.error) || t("status_fetch_history_failed"));
      candles = res.candles;
    }
    candles = sliceCandlesByRange(candles, range);
    backtestCandles = candles;
    const items = backtestPatterns(candles, {
      forwardBars: [3, 5, 10],
      thresholdPct,
      minSamples: 3,
      takeProfitPct: tpPct,
      stopLossPct: slPct,
      maxHoldBars: holdBars,
      direction,
      leverage,
    });
    lastBacktest = { items, thresholdPct, minSamples: 3, tpPct, slPct, holdBars, hasSim, direction, leverage, amount, range, dca: dcaEqualReturn(candles, { period: 20 }) };
    setStatus(
      t("status_bt_done", {
        n: candles.length,
        dir: direction === "both" ? t("dir_both") : direction === "bullish" ? t("dir_long") : t("dir_short"),
        lev: leverage,
        range: range === "all" ? t("range_all") : range,
        m: items.length,
      }),
    );
    renderBacktestTab();
  } catch (err) {
    setStatus(errText(err), true);
    // 错误同时渲染到结果区（醒目），避免只在小字状态栏里被忽略
    const errBox = document.createElement("div");
    errBox.className = "bt-error";
    errBox.textContent = errText(err);
    els.content.appendChild(errBox);
  } finally {
    if (btn) {
      btn.textContent = t("bt_run");
      btn.disabled = false;
    }
  }
}

/** 策略规则回测：按策略自身触发/止损/止盈/持仓规则跑历史K线 */
async function runStrategyBacktest() {
  const bars = Number(document.getElementById("bt-bars").value) || 500;
  const strategyId = document.getElementById("bt-strategy").value;
  const strategy = STRATEGIES.find((s) => s.id === strategyId);
  const direction = document.getElementById("bt-strategy-dir").value;
  const maxHoldBars = Math.max(1, Number(document.getElementById("bt-strategy-hold").value) || 20);
  const leverage = Number(document.getElementById("bt-strategy-leverage").value) || 1;
  const amount = Math.max(0, Number(document.getElementById("bt-strategy-amount").value) || 0);
  const range = document.getElementById("bt-strategy-range").value;
  const btn = document.getElementById("bt-strategy-run");
  if (btn) {
    btn.textContent = t("btn_backtesting");
    btn.disabled = true;
  }
  try {
    let candles;
    if (els.exchange.value === "paste") {
      candles = parsePastedCsv(els.paste.value);
    } else {
      const exchange = els.exchange.value;
      const symbol = normalizeSymbol(exchange, els.symbol.value);
      if (!symbol) throw new Error(t("fill_symbol"));
      setStatus(t("status_fetching_sym", { sym: symbol, iv: `${bars} bars` }));
      const res = await api.runtime.sendMessage({
        type: "FETCH_HISTORY",
        exchange,
        symbol,
        interval: els.interval.value,
        bars,
        reqId: ++fetchReqSeq,
      });
      if (!res || !res.ok) throw new Error((res && res.error) || t("status_fetch_history_failed"));
      candles = res.candles;
    }
    candles = sliceCandlesByRange(candles, range);
    const bt = backtestStrategy(strategy, candles, { direction, maxHoldBars, leverage, amount });
    if (!bt) throw new Error(t("bt_need_60"));
    // 定投等额总回报：同期无脑定投的基准对照（bt 非 null 才挂载）
    bt.dca = dcaEqualReturn(candles, { period: 20 });
    lastStrategyBacktest = bt;
    if (bt.notApplicable) {
      setStatus(t("bt_not_applicable", { name: strategyName(strategy), reason: bt.reason }));
    } else {
      setStatus(
        t("status_strategy_bt_done", {
          n: bt.stats.trades,
          wr: (bt.stats.winRate * 100).toFixed(0),
          pnl: bt.stats.totalPnlMoney.toFixed(2),
          ret: bt.stats.avgReturnPct.toFixed(2),
          lev: leverage,
        }),
      );
    }
    renderBacktestTab();
  } catch (err) {
    setStatus(errText(err), true);
    // 错误同时渲染到结果区（醒目），避免只在小字状态栏里被忽略
    const errBox = document.createElement("div");
    errBox.className = "bt-error";
    errBox.textContent = errText(err);
    els.content.appendChild(errBox);
  } finally {
    if (btn) {
      btn.textContent = t("btn_run_strategy");
      btn.disabled = false;
    }
  }
}

/** 渲染策略回测结果 */
function renderStrategyBacktestResult(bt) {
  const wrap = document.createElement("div");
  if (!bt) return wrap;
  if (bt.notApplicable) {
    wrap.appendChild(
      emptyDiv(t("bt_not_applicable", { name: strategyName(bt.strategy), reason: bt.reason })),
    );
    return wrap;
  }
  const st = bt.stats;
  const bar = document.createElement("div");
  const pnlCls = st.totalPnlMoney >= 0 ? "bullish" : "bearish";
  const ddCls = st.maxDrawdownMoney > 0 ? "bearish" : "neutral";
  bar.className = "summary-bar";
  bar.innerHTML = `
    <div class="summary-chip">${t("chip_trades")} <b>${st.trades}</b></div>
    <div class="summary-chip">${t("chip_winrate")} <b>${(st.winRate * 100).toFixed(0)}%</b></div>
    <div class="summary-chip">${t("chip_avgR")} <b>${st.avgR.toFixed(2)}</b></div>
    <div class="summary-chip">${t("chip_avgRet")} <b>${st.avgReturnPct.toFixed(2)}%</b></div>
    <div class="summary-chip ${bt.dca != null && bt.dca >= 0 ? "bullish" : "bearish"}">${t("chip_dca")} <b>${bt.dca != null ? `${bt.dca >= 0 ? "+" : ""}${(bt.dca * 100).toFixed(1)}%` : "-"}</b></div>
    <div class="summary-chip ${pnlCls}">${t("chip_totalPnl")} <b>${st.totalPnlMoney >= 0 ? "+" : ""}${st.totalPnlMoney.toFixed(2)}</b></div>
    <div class="summary-chip ${ddCls}">${t("chip_maxDD")} <b>${st.maxDrawdownMoney > 0 ? "-" : ""}${st.maxDrawdownMoney.toFixed(2)}</b></div>
    <div class="summary-chip">${t("chip_totalR")} <b>${st.totalR.toFixed(2)}</b></div>
    <div class="summary-chip">${t("chip_pf")} <b>${st.profitFactor === Infinity ? "∞" : st.profitFactor.toFixed(2)}</b></div>
    <div class="summary-chip">${t("chip_maxDDR")} <b>${st.maxDrawdownR.toFixed(2)}</b></div>
    <div class="summary-chip">${t("chip_avgHold")} <b>${st.avgHoldBars.toFixed(1)}</b></div>
  `;
  wrap.appendChild(bar);
  if (!st.trades) {
    wrap.appendChild(
      emptyDiv(t("bt_no_trades")),
    );
    return wrap;
  }
  const head = document.createElement("h3");
  head.style.cssText = "margin:14px 0 4px;color:var(--accent);font-size:13px";
  head.textContent =
    t("bt_trades_head", {
      name: strategyName(bt.strategy),
      trigger: bt.params.triggerLevel,
      stop: bt.params.stopMult,
      rr: bt.params.rr,
      hold: bt.params.maxHoldBars,
      lev: bt.params.leverage || 1,
      amount: bt.params.amount || 0,
    });
  wrap.appendChild(head);
  const table = document.createElement("table");
  table.className = "bt-table";
  const thead = document.createElement("thead");
  thead.innerHTML =
    `<tr><th>${t("th_side_dir")}</th><th>${t("th_side_entry")}</th><th>${t("th_side_exit")}</th><th>${t("th_side_ret")}</th><th>${t("th_side_money")}</th><th>${t("th_side_r")}</th><th>${t("th_side_reason")}</th><th>${t("th_side_hold")}</th></tr>`;
  table.appendChild(thead);
  const tbody = document.createElement("tbody");
  for (const trade of bt.trades.slice(-20)) {
    const cls = trade.pnlR >= 0 ? "bullish" : "bearish";
    // 注意：循环变量不能叫 t，否则覆盖 i18n 翻译函数 t()
    const reasonLabel = {
      stop: t("reason_stop"),
      target: t("reason_target"),
      time: t("reason_time"),
      open: t("reason_open"),
    }[trade.reason] || trade.reason;
    const lev = bt.params.leverage || 1;
    const pct = trade.pnlPct * lev * 100;
    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td class="${cls}">${trade.dir === "long" ? t("trade_dir_long") : t("trade_dir_short")}</td>
      <td>${trade.entry.toFixed(4)}</td>
      <td>${trade.exit.toFixed(4)}</td>
      <td class="${cls}">${pct.toFixed(2)}%</td>
      <td class="${cls}">${trade.pnlMoney >= 0 ? "+" : ""}${trade.pnlMoney.toFixed(2)}</td>
      <td class="${cls}">${trade.pnlR.toFixed(2)}R</td>
      <td>${reasonLabel}</td>
      <td>${trade.bars}</td>
    `;
    tbody.appendChild(tr);
  }
  table.appendChild(tbody);
  wrap.appendChild(table);
  const note = document.createElement("div");
  note.className = "bt-note";
  note.textContent =
    t("bt_note_strategy", {
      amount: bt.params.amount || 0,
      lev: bt.params.leverage || 1,
      liq: bt.params.leverage > 1
        ? trAnalysis(`满仓杠杆下价格反向波动约 ${(100 / bt.params.leverage).toFixed(1)}% 即爆仓。`)
        : "",
    });
  wrap.appendChild(note);
  return wrap;
}

async function sendMessageSafe(msg) {
  const res = await api.runtime.sendMessage(msg);
  if (!res || !res.ok) throw new Error((res && res.error) || t("request_failed"));
  return res;
}

/** A股代码 → 腾讯 secid */
function toTencentSecid(code) {
  const c = String(code || "").trim();
  return /^[69]/.test(c) ? `sh${c}` : `sz${c}`;
}

function fmtDate(v) {
  if (!v) return "-";
  const d = new Date(v);
  if (Number.isNaN(d.getTime())) return String(v).slice(0, 10);
  return d.toISOString().slice(0, 10);
}

function renderSentimentTab() {
  const content = els.content;
  content.innerHTML = "";

  const cryptoHead = document.createElement("h3");
  cryptoHead.textContent = t("crypto_head");
  cryptoHead.style.cssText = "margin:2px 0 8px;color:var(--accent);font-size:13px";
  content.appendChild(cryptoHead);

  const cryptoRow = document.createElement("div");
  cryptoRow.className = "summary-bar";
  const mkBtn = (id, label, fn) => {
    const b = document.createElement("button");
    b.className = "ghost";
    b.id = id;
    b.textContent = label;
    b.addEventListener("click", fn);
    return b;
  };
  cryptoRow.appendChild(mkBtn("funding-btn", t("btn_funding"), loadFundingRate));
  cryptoRow.appendChild(mkBtn("liq-btn", t("btn_liq"), loadLiquidations));
  cryptoRow.appendChild(mkBtn("fng-btn", t("btn_fng"), loadFearGreed));
  content.appendChild(cryptoRow);
  if (["stock", "futures"].includes(els.exchange.value)) {
    const tip = document.createElement("div");
    tip.className = "panel-tip";
    tip.textContent = t("tip_crypto_only");
    content.appendChild(tip);
  }

  const cryptoOut = document.createElement("div");
  cryptoOut.id = "crypto-sentiment";
  content.appendChild(cryptoOut);

  const stockHead = document.createElement("h3");
  stockHead.textContent = t("head_stock");
  stockHead.style.cssText = "margin:16px 0 8px;color:var(--accent);font-size:13px";
  content.appendChild(stockHead);

  const stockForm = document.createElement("div");
  stockForm.className = "row";
  stockForm.innerHTML = `
    <label class="field"><span>${t("label_stock_code")}</span><input id="stock-code" type="text" value="600519" placeholder="${t("ph_stock_code")}" /></label>
    <button id="earnings-btn" class="ghost">${t("btn_earnings")}</button>
    <button id="compare-btn" class="ghost">${t("btn_compare")}</button>
  `;
  content.appendChild(stockForm);
  document.getElementById("earnings-btn").addEventListener("click", loadEarnings);
  document.getElementById("compare-btn").addEventListener("click", loadCompare);

  const stockOut = document.createElement("div");
  stockOut.id = "stock-sentiment";
  content.appendChild(stockOut);
}

async function loadFundingRate() {
  const out = document.getElementById("crypto-sentiment");
  if (out) out.innerHTML = "";  // 防重复点击累积卡片
  const exchange = els.exchange.value === "paste" ? "okx" : els.exchange.value;
  const symbol = normalizeSymbol(exchange, els.symbol.value || "BTC-USDT");
  if (exchange === "stock" || exchange === "futures") {
    setStatus(t("status_funding_crypto_only"), true);
    return;
  }
  setStatus(t("status_loading", { sym: symbol, what: t("btn_funding") }));
  try {
    const { data } = await sendMessageSafe({ type: "FETCH_FUNDING_RATE", exchange, symbol });
    const interp = interpretFundingRate(data.fundingRate);
    const riskLabel =
      interp.risk === "long-crowded"
        ? t("risk_long_crowded")
        : interp.risk === "short-crowded"
          ? t("risk_short_crowded")
          : interp.risk === "balanced"
            ? t("risk_balanced")
            : t("risk_leaning");
    out.appendChild(
      makeCard({
        title: t("title_funding", { sym: data.instId }),
        badges: [badge("neutral", riskLabel)],
        summary: trAnalysis(interp.summary),
        detailBlocks: [
          { title: t("next_settlement"), text: fmtDate(data.nextFundingTime) },
          {
            title: t("detail_note"),
            text: t("funding_note"),
          },
        ],
      }),
    );
    setStatus(t("status_loaded", { what: t("btn_funding") }));
  } catch (err) {
    setStatus(errText(err), true);
  }
}

async function loadLiquidations() {
  const out = document.getElementById("crypto-sentiment");
  if (out) out.innerHTML = "";  // 防重复点击累积卡片
  const exchange = els.exchange.value === "paste" ? "okx" : els.exchange.value;
  const symbol = normalizeSymbol(exchange, els.symbol.value || "BTC-USDT");
  if (exchange === "stock" || exchange === "futures") {
    setStatus(t("status_liq_crypto_only"), true);
    return;
  }
  setStatus(t("status_loading", { sym: symbol, what: t("btn_liq") }));
  try {
    const { data } = await sendMessageSafe({ type: "FETCH_LIQUIDATIONS", exchange, symbol });
    const interp = interpretLiquidations(data.longLoss, data.shortLoss);
    out.appendChild(
      makeCard({
        title: t("title_liq", { sym: data.instId }),
        badges: [],
        summary: trAnalysis(interp.summary),
        detailBlocks: [
          {
            title: t("liq_detail_title"),
            text: t("liq_detail", { n: data.count, long: data.longLoss.toFixed(0), short: data.shortLoss.toFixed(0) }),
          },
          {
            title: t("detail_note"),
            text: t("liq_note"),
          },
        ],
      }),
    );
    setStatus(t("status_loaded", { what: t("btn_liq") }));
  } catch (err) {
    setStatus(errText(err), true);
  }
}

async function loadFearGreed() {
  const out = document.getElementById("crypto-sentiment");
  if (out) out.innerHTML = "";  // 防重复点击累积卡片
  setStatus(t("status_loading", { sym: "", what: t("btn_fng") }));
  try {
    const { data } = await sendMessageSafe({ type: "FETCH_FEAR_GREED" });
    const interp = interpretFearGreed(data.current);
    const trend =
      data.history && data.history.length > 1
        ? t("fng_trend", { vals: data.history.map((h) => h.value).join(" → "), avg: data.avg7 != null ? data.avg7.toFixed(0) : "-" })
        : "";
    out.appendChild(
      makeCard({
        title: t("title_fng", { v: data.current, label: trAnalysis(interp.label) }),
        badges: [],
        summary: trAnalysis(interp.summary),
        detailBlocks: [
          { title: t("fng_trend_title"), text: trend || t("no_history") },
          { title: t("detail_note"), text: t("fng_note") },
        ],
      }),
    );
    setStatus(t("status_loaded", { what: t("btn_fng") }));
  } catch (err) {
    setStatus(errText(err), true);
  }
}

async function loadEarnings() {
  const out = document.getElementById("stock-sentiment");
  if (out) out.innerHTML = "";  // 防重复点击累积卡片
  const code = document.getElementById("stock-code").value.trim();
  if (!code) {
    setStatus(t("status_input_stock_code"), true);
    return;
  }
  if (!/^\d{6}$/.test(code)) {
    setStatus(t("earnings_support"), true);
    return;
  }
  setStatus(t("earnings_loading", { code }));
  try {
    const { data } = await sendMessageSafe({ type: "FETCH_EARNINGS", code });
    out.appendChild(
      makeCard({
        title: t("earnings_title", { name: Array.isArray(data) && data[0] ? data[0].name : code }),
        badges: [],
        summary: Array.isArray(data)
          ? data
              .slice(0, 4)
              .map((r) => t("earnings_item", { report: fmtDate(r.reportDate), notice: fmtDate(r.noticeDate) }))
              .join("；")
          : t("no_history"),
        detailBlocks: [
          {
            title: t("detail_note"),
            text: t("earnings_note"),
          },
        ],
      }),
    );
    setStatus(t("earnings_loaded"));
  } catch (err) {
    setStatus(errText(err), true);
  }
}

async function loadCompare() {
  const out = document.getElementById("stock-sentiment");
  if (out) out.innerHTML = "";  // 防重复点击累积卡片
  const code = document.getElementById("stock-code").value.trim();
  if (!code) {
    setStatus(t("status_input_stock_code"), true);
    return;
  }
  if (!/^\d{6}$/.test(code)) {
    setStatus(t("compare_support"), true);
    return;
  }
  setStatus(t("compare_loading", { code }));
  try {
    const [stockRes, indexRes] = await Promise.all([
      sendMessageSafe({ type: "FETCH_STOCK_KLINES", secid: toTencentSecid(code), lmt: 120 }),
      sendMessageSafe({ type: "FETCH_STOCK_KLINES", secid: "sh000001", lmt: 120 }),
    ]);
    const cmp = marketComparison(stockRes.data, indexRes.data);
    const corrText =
      cmp.correlation == null
        ? t("corr_insufficient")
        : cmp.correlation >= 0.7
          ? t("corr_high", { v: cmp.correlation.toFixed(2) })
          : cmp.correlation >= 0.3
            ? t("corr_mid", { v: cmp.correlation.toFixed(2) })
            : t("corr_low", { v: cmp.correlation.toFixed(2) });
    out.appendChild(
      makeCard({
        title: t("compare_title", { code }),
        badges: [],
        summary: t("compare_summary", {
          corr: corrText,
          s: (cmp.stock20 * 100).toFixed(1),
          i: (cmp.index20 * 100).toFixed(1),
          r: (cmp.relativeStrength * 100).toFixed(1),
        }),
        detailBlocks: [
          {
            title: t("detail_note"),
            text: t("compare_note"),
          },
        ],
      }),
    );
    setStatus(t("compare_loaded"));
  } catch (err) {
    setStatus(errText(err), true);
  }
}

function renderChartTab() {
  const content = els.content;
  content.innerHTML = "";
  const r = lastResult;
  if (!r) {
    content.innerHTML = `<div class="empty">${t("empty_run_first")}</div>`;
    return;
  }
  if (!r.chartPatterns.length) {
    content.appendChild(emptyDiv(t("empty_no_chart")));
    return;
  }
  for (const p of r.chartPatterns) {
    const badges = [
      badge(p.direction, DIRECTION_TEXT[p.direction]),
      badge(`status-${p.status}`, p.status === "confirmed" ? t("chart_status_confirmed") : t("chart_status_forming")),
    ];
    const card = makeCard({
      title: patternName(p),
      titleExtra: t("cover_range", { from: p.candleRange[0] + 1, to: p.candleRange[1] + 1 }),
      badges,
      summary: trAnalysis(p.summary),
      levels: p.levels,
      detailBlocks: [
        ...(LANG === "zh" || trAnalysis(p.description) !== p.description
          ? [{ title: t("detail_meaning"), text: trAnalysis(p.description) }]
          : []),
        ...(LANG === "zh" || trAnalysis(p.rules) !== p.rules
          ? [{ title: t("detail_rules"), text: trAnalysis(p.rules) }]
          : []),
        { title: t("detail_notes"), text: trAnalysis(p.notes) },
      ],
    });
    bindDiagramHover(card, p);
    content.appendChild(card);
  }
}

function renderSignalTab() {
  const content = els.content;
  content.innerHTML = "";
  const r = lastResult;
  if (!r) {
    content.innerHTML = `<div class="empty">${t("empty_run_first")}</div>`;
    return;
  }
  if (!r.indicatorSignals.length) {
    content.appendChild(emptyDiv(t("empty_no_indicator")));
    return;
  }
  for (const s of r.indicatorSignals) {
    const card = makeCard({
      title: trAnalysis(s.nameZh),
      badges: [badge(s.direction, DIRECTION_TEXT[s.direction]), badge("neutral", t("kind_signal"))],
      summary: trAnalysis(s.summary),
      detailBlocks: [
        ...(LANG === "zh" || trAnalysis(s.description) !== s.description
          ? [{ title: t("detail_note"), text: trAnalysis(s.description) }]
          : []),
        { title: t("detail_notes"), text: trAnalysis(s.notes) },
      ],
    });
    bindDiagramHover(card, s);
    content.appendChild(card);
  }
}

function renderCatalogTab() {
  const content = els.content;
  content.innerHTML = "";
  const catalog = getCatalog();
  const groups = [
    ["single", "cat_single"],
    ["double", "cat_double"],
    ["triple", "cat_triple"],
    ["multi", "cat_multi"],
  ];
  for (const [cat, label] of groups) {
    const items = catalog.filter((p) => p.category === cat);
    const h = document.createElement("h3");
    h.textContent = t(label, { n: items.length });
    h.style.margin = "14px 0 6px";
    h.style.color = "var(--accent)";
    content.appendChild(h);
    for (const p of items) {
      content.appendChild(
        makeCard({
          title: patternName(p),
          badges: [
            badge(p.direction, DIRECTION_TEXT[p.direction]),
            badge("neutral", KIND_TEXT[p.kind]),
          ],
          diagram: patternDiagramSvg(p),
          summary: patternField(p, "summary"),
          detailBlocks: [
            { title: t("detail_meaning"), text: patternField(p, "description") },
            { title: t("detail_rules"), text: patternField(p, "rules") },
            { title: t("detail_notes"), text: patternField(p, "notes") },
          ],
        }),
      );
    }
  }
}

function emptyDiv(text) {
  const div = document.createElement("div");
  div.className = "empty";
  div.textContent = text;
  return div;
}

function renderTab(tab) {
  activeTab = tab;
  document.querySelectorAll(".tab").forEach((t) => t.classList.toggle("active", t.dataset.tab === tab));
  $("#analysis-sub").style.display = tab === "analysis" ? "flex" : "none";
  if (tab === "analysis") {
    renderAnalysisTab();
    return;
  }
  // 非分析页签：隐藏分析相关面板
  $("#kline-filter").style.display = "none";
  $("#conflict-banner").style.display = "none";
  $("#chart-panel").style.display = "none";
  if (tab === "backtest") renderBacktestTab();
  else if (tab === "catalog") renderCatalogTab();
}

/** 识别页签：K线形态 / 图表形态 / 指标信号 / 市场环境 / 情绪宏观 子页签 */
function renderAnalysisTab() {
  document.querySelectorAll(".chip").forEach((c) => c.classList.toggle("active", c.dataset.sub === analysisSub));
  $("#analysis-sub").style.display = "flex";
  const sub = analysisSub;
  $("#kline-filter").style.display = sub === "kline" ? "flex" : "none";
  const showChart = sub === "kline" || sub === "market";
  $("#chart-panel").style.display = showChart ? "block" : "none";
  renderConflictBanner();
  if (sub === "kline") renderKlineTab();
  else if (sub === "chart") renderChartTab();
  else if (sub === "signal") renderSignalTab();
  else if (sub === "market") renderMarketTab();
  else renderSentimentTab();
  if (showChart) redrawChart();
}

/** 多空冲突预警：最新K线同时出现看涨与看跌形态时提示 */
function renderConflictBanner() {
  const banner = els.conflictBanner;
  if (!lastResult || activeTab !== "analysis") {
    banner.style.display = "none";
    return;
  }
  const latest = lastResult.detections.filter(
    (d) => d.index === lastResult.count - 1 && d.direction !== "neutral",
  );
  const bull = latest.filter((d) => d.direction === "bullish").length;
  const bear = latest.filter((d) => d.direction === "bearish").length;
  if (bull > 0 && bear > 0) {
    banner.style.display = "block";
    banner.textContent = t("conflict_banner", { bull, bear });
  } else {
    banner.style.display = "none";
  }
}

/** 设置 canvas 尺寸（适配设备像素比）并绘制 */
function redrawChart() {
  const panel = $("#chart-panel");
  const canvas = $("#chart");
  if (!lastResult || panel.style.display === "none") return;
  const dpr = window.devicePixelRatio || 1;
  // chart-panel 左右各 14px 内边距，画布要扣掉，否则会比容器宽、撑出横向滚动
  const w = Math.max(0, panel.clientWidth - 28);
  const h = 360;
  canvas.style.width = `${w}px`;
  canvas.style.height = `${h}px`;
  canvas.width = Math.round(w * dpr);
  canvas.height = Math.round(h * dpr);
  const range = selectedRange || [lastResult.count - 1, lastResult.count - 1];
  const vr = viewRange || defaultViewRange(lastResult.count);
  const mc = lastResult.marketContext;
  const levels = mc
    ? {
        supports: mc.keyLevels.supports.slice(0, 3).map((l) => l.price),
        resistances: mc.keyLevels.resistances.slice(0, 3).map((l) => l.price),
        fibonacci: mc.fibonacci,
        vwap: mc.vwap,
      }
    : null;
  drawCandles(canvas, lastResult.candles, { viewRange: vr, selectedRange: range, levels, labels: { support: t("support_label"), resistance: t("resistance_label") } });
}

/** 缩放：以锚点K线为中心放大/缩小（factor > 1 放大） */
function zoomAt(factor, anchorIdx) {
  const n = lastResult.count;
  const cur = viewRange || defaultViewRange(n);
  const visible = cur[1] - cur[0] + 1;
  const newVisible = Math.max(5, Math.min(n, Math.round(visible / factor)));
  const frac = n > 1 ? (anchorIdx - cur[0]) / visible : 0.5;
  let s = Math.round(anchorIdx - frac * newVisible);
  s = Math.max(0, Math.min(n - newVisible, s));
  viewRange = [s, s + newVisible - 1];
  redrawChart();
}

/** 居中缩放（按钮用） */
function zoomChart(factor) {
  const n = lastResult ? lastResult.count : 0;
  if (!n) return;
  const cur = viewRange || defaultViewRange(n);
  const center = (cur[0] + cur[1]) / 2;
  zoomAt(factor, Math.round(center));
}

function resetView() {
  viewRange = null;
  selectedRange = null;
  redrawChart();
}

// 图表交互：滚轮缩放、拖拽平移、双击复位
const chartCanvas = $("#chart");
let panState = null;
let panMoved = false;

chartCanvas.addEventListener(
  "wheel",
  (e) => {
    e.preventDefault();
    if (!lastResult) return;
    const idx = indexFromX(
      chartCanvas,
      e.offsetX,
      viewRange || defaultViewRange(lastResult.count),
      lastResult.count,
    );
    zoomAt(e.deltaY > 0 ? 1 / 1.25 : 1.25, idx);
  },
  { passive: false },
);

chartCanvas.addEventListener("mousedown", (e) => {
  if (!lastResult) return;
  panMoved = false;
  panState = {
    x: e.clientX,
    vr: viewRange || defaultViewRange(lastResult.count),
  };
  chartCanvas.style.cursor = "grabbing";
});

chartCanvas.addEventListener("mousemove", (e) => {
  if (!panState) return;
  if (Math.abs(e.clientX - panState.x) > 2) panMoved = true;
  const n = lastResult.count;
  const vr = panState.vr;
  const visible = vr[1] - vr[0] + 1;
  // 画布左右留白 16 设备像素，换算成 CSS 宽度
  const plotCssW = Math.max(
    1,
    chartCanvas.clientWidth * (1 - 16 / Math.max(1, chartCanvas.width)),
  );
  const dx = Math.round((e.clientX - panState.x) * (visible / plotCssW));
  let s = Math.max(0, Math.min(n - visible, vr[0] - dx));
  viewRange = [s, s + visible - 1];
  redrawChart();
});

function endPan() {
  panState = null;
  chartCanvas.style.cursor = "";
}
chartCanvas.addEventListener("mouseup", endPan);
chartCanvas.addEventListener("mouseleave", endPan);
chartCanvas.addEventListener("dblclick", resetView);
chartCanvas.addEventListener("click", (e) => {
  if (panMoved) {
    panMoved = false;
    return;
  }
  if (!lastResult) return;
  const n = lastResult.count;
  const idx = indexFromX(
    chartCanvas,
    e.offsetX,
    viewRange || defaultViewRange(n),
    n,
  );
  const c = lastResult.candles[idx];
  if (!c) return;
  selectedRange = [idx, idx];
  redrawChart();
  const hits = lastResult.detections
    .filter((d) => d.candleRange[0] <= idx && idx <= d.candleRange[1])
    .map((d) => patternName(d));
  const time = c.timestamp ? new Date(c.timestamp).toLocaleString() : t("bar_nth", { idx: idx + 1 });
  setStatus(
    t("bar_line", { idx: idx + 1, time, o: fmtNum(c.open), h: fmtNum(c.high), l: fmtNum(c.low), c: fmtNum(c.close) }) +
      (c.volume != null ? t("vol_suffix", { v: fmtNum(c.volume) }) : "") +
      (hits.length
        ? t("hits_prefix", { h: hits.slice(0, 3).join("、") }) + (hits.length > 3 ? t("hits_more") : "")
        : t("no_hits")),
  );
});

$("#zoom-in").addEventListener("click", () => zoomChart(1.3));
$("#zoom-out").addEventListener("click", () => zoomChart(1 / 1.3));
$("#zoom-fit").addEventListener("click", resetView);
$("#side-shot-btn").addEventListener("click", async () => {
  const canvas = $("#chart");
  if (!lastResult || !canvas || !canvas.width || !canvas.height) {
    setStatus(t("viewer_shot_need"), true);
    return;
  }
  const header = `${EXCHANGE_LABEL[els.exchange.value] || els.exchange.value} ${els.symbol.value.trim()} ${els.interval.value} · ${new Date().toLocaleString()}`;
  const ok = await saveCanvas(canvas, {
    headerText: header,
    filename: shotFilename(els.symbol.value.trim(), els.interval.value),
    api,
  });
  setStatus(ok ? t("viewer_shot_done") : t("viewer_shot_need"), !ok);
});

// 事件绑定
els.exchange.addEventListener("change", () => {
  onExchangeChange();
  syncEconomySymbol();
  if (lastResult && !els.autoDetect.checked && els.exchange.value !== "paste") debounceRun();
});
els.symbol.addEventListener("change", () => {
  // 用户手动输入标的时自动判断数据源（数据源下拉已隐藏；程序化赋值不触发此事件，不影响自动识别）
  const sym = els.symbol.value.trim();
  if (sym && !els.autoDetect.checked) {
    const auto = autoDetectExchange(sym);
    if (auto !== els.exchange.value) {
      els.exchange.value = auto;
      onExchangeChange();
    }
  }
  updateConnBar();
  syncEconomySymbol();
  if (lastResult && !els.autoDetect.checked && els.exchange.value !== "paste") debounceRun();
});
els.interval.addEventListener("change", () => {
  updateConnBar();
  if (lastResult && els.exchange.value !== "paste") debounceRun();
});
els.signalFilter.addEventListener("change", () => {
  if (activeTab === "analysis" && analysisSub === "kline") renderAnalysisTab();
});
els.autoDetect.addEventListener("change", onAutoDetectChange);
els.analyzeBtn.addEventListener("click", () => {
  if (activeTab !== "analysis") renderTab("analysis");
  runAnalysis(true);
});
els.economyBtn.addEventListener("click", runEconomySignal);
// 经济模型标的跟随顶部输入框（手动填写入口在顶部连接栏【手动填写】按钮）
els.viewerBtn.addEventListener("click", () => {
  const useCtx = els.autoDetect.checked && lastViewerContext ? lastViewerContext : null;
  const params = new URLSearchParams({
    exchange: useCtx ? useCtx.exchange : els.exchange.value,
    symbol: useCtx ? useCtx.symbol : els.symbol.value.trim(),
    interval: els.interval.value,
    limit: els.limit.value,
  });
  const url = api.runtime.getURL(`kline-viewer.html?${params.toString()}`);
  Promise.resolve(api.tabs.create ? api.tabs.create({ url }) : undefined).catch((err) =>
    setStatus(t("viewer_open_failed", { msg: err && err.message ? err.message : err }), true),
  );
});
els.saveBtn.addEventListener("change", () => {
  if (els.saveBtn.checked) {
    api.storage.local.set({ symbol: els.symbol.value, exchange: els.exchange.value });
    setStatus(t("remember_done"));
  } else {
    api.storage.local.remove(["symbol", "exchange"], () => {});
    setStatus(t("remember_cancel"));
  }
});
// 手动填写标的（连接栏）：任何模式（含自动识别）下都能手动指定标的，
// 手动填写后临时暂停自动识别，避免被网页自动检测覆盖
const manualSymbolBtn = document.getElementById("manual-symbol-btn");
if (manualSymbolBtn) {
  manualSymbolBtn.textContent = t("btn_manual_symbol");
  manualSymbolBtn.title = t("manual_symbol_hint");
  manualSymbolBtn.addEventListener("click", () => {
    const input = prompt(t("manual_symbol_prompt"), els.symbol.value.trim() || "");
    if (input === null) return;
    const v = input.trim();
    if (!v) return;
    els.symbol.value = v;
    // 数据源按标的自动判断（下拉已隐藏）
    const auto = autoDetectExchange(v);
    if (auto !== els.exchange.value) {
      els.exchange.value = auto;
      onExchangeChange();
    }
    if (els.autoDetect.checked) {
      els.autoDetect.checked = false;
      onAutoDetectChange();
      setStatus(t("manual_symbol_paused_auto", { sym: v }));
    } else {
      setStatus(t("status_symbol_set", { sym: v }));
    }
    syncEconomySymbol();
    debounceRun(300);
  });
}
$("#refresh-btn").addEventListener("click", () => {
  if (activeTab !== "analysis") renderTab("analysis");
  syncContext(false);
  setTimeout(() => runAnalysis(), 500);
});
document.querySelectorAll(".tab").forEach((t) =>
  t.addEventListener("click", () => renderTab(t.dataset.tab)),
);
document.querySelectorAll(".chip").forEach((c) =>
  c.addEventListener("click", () => {
    analysisSub = c.dataset.sub;
    renderAnalysisTab();
  }),
);
document.querySelectorAll('input[name="klineScope"]').forEach((r) =>
  r.addEventListener("change", () => {
    if (activeTab === "analysis" && analysisSub === "kline") {
      renderAnalysisTab();
    }
  }),
);

// 国际化：自动按浏览器/系统语言匹配，也可手动切换
const langSelect = $("#ui-lang");
initI18n((lang) => {
  if (langSelect) langSelect.value = lang;
  document.title = t("app_title");
  updateConnBar();
  renderTab(activeTab);
  if (lastEconomyResult) refreshEconomyResult();
  resetPayOrder(); // 清空已生成订单（避免残留旧语言文案）
  // 状态栏文案随语言刷新（避免残留上次语言的中文）
  setStatus(t("status_lang_ready", { lang: langSelect ? langSelect.options[langSelect.selectedIndex]?.text : lang }));
});
if (langSelect) {
  langSelect.addEventListener("change", (e) => {
    setLang(e.target.value, () => {
      document.title = t("app_title");
      updateConnBar();
      renderTab(activeTab);
      if (lastEconomyResult) refreshEconomyResult();
      resetPayOrder(); // 清空已生成订单（避免残留旧语言文案）
      // 状态栏文案随语言刷新
      setStatus(t("status_lang_ready", { lang: e.target.selectedOptions[0]?.text || e.target.value }));
    });
  });
}

// 会员账户：入口、弹窗、创建/登录、复制、解绑
$("#account-open").addEventListener("click", openAccountModal);
$("#account-modal-close").addEventListener("click", closeAccountModal);
$("#account-modal").addEventListener("click", (e) => {
  if (e.target === $("#account-modal")) closeAccountModal();
});
$("#account-create-btn").addEventListener("click", onCreateAccount);
$("#account-login-show").addEventListener("click", () => {
  $("#account-choose").style.display = "none";
  $("#account-login-form").style.display = "";
  $("#account-login-input").focus();
});
$("#account-login-back").addEventListener("click", () => {
  $("#account-login-form").style.display = "none";
  $("#account-choose").style.display = "";
});
$("#account-login-btn").addEventListener("click", onLoginAccount);
$("#account-login-input").addEventListener("keydown", (e) => {
  if (e.key === "Enter") onLoginAccount();
});
$("#account-copy-btn").addEventListener("click", onCopyAccount);
$("#account-unbind").addEventListener("click", onUnbind);
$("#gumroad-buy-btn")?.addEventListener("click", async (e) => {
  e.preventDefault();
  // 订阅方式：跳 Gumroad 付款页，带 16 位账号 + 套餐参数（?device=<账号>&plan=<month|year>）
  // Gumroad 付款后的 Ping 通知会把 url_params 原样带回服务器，服务器据此自动给该账号开通会员
  const url = UPDATE_CONFIG.gumroadBuyUrl || "https://gumroad.com/";
  if (!url || url === "https://gumroad.com/") return;
  const plan = $("#gumroad-plan")?.value || "month";
  let finalUrl = url;
  try {
    const account = await getAccountNumber();
    if (account) finalUrl = `${url}${url.includes("?") ? "&" : "?"}device=${encodeURIComponent(account)}&plan=${plan}`;
  } catch { /* 取不到账号就用纯链接（付款后手动兑换兜底） */ }
  chrome.tabs.create({ url: finalUrl });
});
// 兑换兜底（默认折叠）：未自动开通时点「点此兑换」展开
$("#gumroad-toggle-redeem")?.addEventListener("click", () => {
  const row = $("#gumroad-redeem-row");
  if (row) row.style.display = row.style.display === "none" ? "" : "none";
});
$("#gumroad-redeem-btn")?.addEventListener("click", onGumroadRedeem);
$("#gumroad-key-input")?.addEventListener("keydown", (e) => {
  if (e.key === "Enter") onGumroadRedeem();
});

// ===== 加密支付（USDT/USDC）：订单生成 + 检查到账 + 自动兑换 =====
const payOrderBtn = $("#pay-order-btn");
const payCheckBtn = $("#pay-check-btn");
const payOrderInfo = $("#pay-order-info");
let lastPayOrder = null;

/** 清空已生成的订单（切语言时调用，避免残留旧语言文案） */
function resetPayOrder() {
  lastPayOrder = null;
  if (payOrderInfo) {
    payOrderInfo.innerHTML = "";
    payOrderInfo.style.display = "none";
  }
  if (payCheckBtn) payCheckBtn.style.display = "none";
}
/** 把收款地址渲染成二维码到 canvas（本地纯前端生成，地址不外发第三方二维码服务） */
function renderPayQr(text, canvas) {
  if (!text || !canvas) return false;
  try {
    const qr = qrcodegen.QrCode.encodeText(text, qrcodegen.QrCode.Ecc.MEDIUM);
    const n = qr.size;
    const margin = 4; // 四周留白（QR 规范的 quiet zone）
    const total = n + margin * 2;
    canvas.width = total;
    canvas.height = total;
    const ctx = canvas.getContext("2d");
    ctx.fillStyle = "#fff";
    ctx.fillRect(0, 0, total, total);
    ctx.fillStyle = "#000";
    for (let y = 0; y < n; y++) {
      for (let x = 0; x < n; x++) {
        if (qr.getModule(x, y)) ctx.fillRect(x + margin, y + margin, 1, 1);
      }
    }
    return true;
  } catch {
    return false;
  }
}

const payApi = (path, data) => {
  // 支付请求加超时 + 失败兜底：网络失败/超时返回 {ok:false,error}，绝不 reject（避免按钮静默复位、用户"钱转了没反馈"）
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), ECONOMY_TIMEOUT);
  return fetch(`${UPDATE_CONFIG.licenseApiUrl.replace(/\/+$/, "")}${path}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data),
    signal: controller.signal,
  })
    .then((r) => r.json().catch(() => ({ ok: false, error: `HTTP ${r.status}` })))
    .catch((e) => ({ ok: false, error: e.name === "AbortError" ? "请求超时" : e.message || "网络错误" }))
    .finally(() => clearTimeout(timer));
};

function payNetworkLabel(network) {
  const value = String(network || "");
  if (/^solana$/i.test(value)) return t("pay_network_sol");
  if (/^ethereum$/i.test(value)) return t("pay_network_eth");
  if (/^tron$/i.test(value)) return t("pay_network_tron");
  return value;
}

if (payOrderBtn && payCheckBtn && payOrderInfo) {
  payOrderBtn.addEventListener("click", async () => {
    const plan = $("#pay-plan").value;
    const v = $("#pay-coin").value; // "usdt_bnb" | "usdc_bnb" | ...（币种_网络）
    const [coin, network] = v.split("_");
    payOrderBtn.disabled = true;
    try {
      const o = await payApi("/api/pay/order", { plan, network, coin, lang: LANG });
      if (!o.ok) {
        payOrderInfo.textContent = t("pay_error", { msg: o.error || "" });
        payOrderInfo.style.display = "";
        return;
      }
      lastPayOrder = o;
      payOrderInfo.innerHTML = "";
      payOrderInfo.style.display = "";
      const lines = [
        [t("pay_order_id"), o.orderId],
        [t("pay_amount"), `${o.amount} ${o.coin}`],
        [t("pay_network"), payNetworkLabel(o.network)],
        [t("pay_address"), o.address || t("pay_addr_pending")],
      ];
      for (const [k, v] of lines) {
        const row = document.createElement("div");
        row.className = "pay-line";
        const lb = document.createElement("b");
        lb.textContent = k;
        const sv = document.createElement("span");
        sv.textContent = v;
        row.append(lb, sv);
        payOrderInfo.appendChild(row);
      }
      if (o.tip) {
        const tip = document.createElement("div");
        tip.className = "pay-tip";
        tip.textContent = o.tip;
        payOrderInfo.appendChild(tip);
      }
      // 收款地址二维码：本地生成，手机钱包扫码转账更方便
      if (o.address) {
        const qrWrap = document.createElement("div");
        qrWrap.className = "pay-qr";
        const cv = document.createElement("canvas");
        cv.className = "pay-qr-canvas";
        if (renderPayQr(o.address, cv)) {
          qrWrap.appendChild(cv);
          const hint = document.createElement("div");
          hint.className = "pay-qr-hint";
          hint.textContent = t("pay_scan_hint");
          qrWrap.appendChild(hint);
          payOrderInfo.appendChild(qrWrap);
        }
      }
      payCheckBtn.style.display = "";
    } finally {
      payOrderBtn.disabled = false;
    }
  });

  payCheckBtn.addEventListener("click", async () => {
    if (!lastPayOrder) return;
    payCheckBtn.disabled = true;
    try {
      const r = await payApi("/api/pay/check", { orderId: lastPayOrder.orderId });
      const msg = $("#account-msg");
      if (!r || r.ok === false) {
        // 支付接口失败/超时：明确提示，不误导成"尚未到账"
        msg.textContent = t("pay_error", { msg: (r && r.error) || "" });
      } else if (r.status === "paid") {
        // 到账：自动兑换开通订阅（refreshAccountUI 会重新拉取状态，不直接改内存）
        if (accountState && accountState.account) {
          try {
            await redeemCode(r.code);
            msg.textContent = t("pay_paid_auto");
            await refreshAccountUI();
          } catch (e) {
            msg.textContent = t("pay_code_manual", { code: r.code, msg: e.message });
          }
        } else {
          msg.textContent = t("pay_code_manual", { code: r.code, msg: "" });
        }
        payOrderInfo.style.display = "none";
        payCheckBtn.style.display = "none";
        lastPayOrder = null;
      } else {
        msg.textContent = t("pay_pending");
      }
    } finally {
      payCheckBtn.disabled = false;
    }
  });
}

// 初始化：同步账户状态并显示今日剩余次数
refreshAccountUI();
if (UPDATE_CONFIG.licenseApiUrl) {
  syncAccount();
}

// 侧边栏关闭/打开不会重建页面，重新可见时重新检测当前页面，
// 否则股票页切换后需要刷新网页才会识别（交易所 SPA 有地址变化事件，股票站经常没有）
document.addEventListener("visibilitychange", () => {
  if (document.visibilityState === "visible") syncContext(true);
});

// 兜底：无条件定时重检（不依赖 visibility 事件），配合后台写入的 activePageContext
setInterval(() => syncContext(true), 3000);

if (typeof ResizeObserver !== "undefined") {
  new ResizeObserver(() => redrawChart()).observe($("#chart-panel"));
}

// 恢复上次设置
api.storage.local.get(["symbol", "exchange"]).then((data) => {
  if (data.symbol) {
    els.symbol.value = data.symbol;
    syncEconomySymbol();
  }
  if (data.exchange) {
    els.exchange.value = data.exchange;
    onExchangeChange();
  }
  els.saveBtn.checked = !!(data.symbol && data.exchange);
  onAutoDetectChange();
  updateConnBar();
});

// 监听内容脚本检测到的页面上下文
api.storage.onChanged.addListener((changes, area) => {
  if (area === "local" && changes.pageContext && changes.pageContext.newValue) {
    if (els.autoDetect.checked) applyContextIfNew(changes.pageContext.newValue);
  }
});

// 面板打开时，优先检测当前标签页；检测不到时应用最近一次内容脚本写入的上下文
syncContext();

// 切换标签页或页面跳转时重新检测
api.tabs.onActivated.addListener(() => syncContext(true));
api.tabs.onUpdated.addListener((tabId, info) => {
  if (info.url) syncContext(true);
});
if (api.windows && api.windows.onFocusChanged) {
  api.windows.onFocusChanged.addListener(() => syncContext(true));
}

// 页脚显示构建标识，方便确认扩展是否已重新加载最新代码
const footer = document.querySelector("footer.disclaimer");
if (footer) {
  const build = document.createElement("span");
  build.className = "build-stamp";
  build.textContent = ` · ${BUILD_STAMP}`;
  footer.appendChild(build);
}

// 应用内「检查更新」：配置 update-config.js 的 latestUrl 后启用自动检查 + 手动检查
const updateBar = $("#update-bar");
if (updateBar) {
  updateBar.style.display = "flex";
  const updateInfo = $("#update-info");
  const updateBtn = $("#update-check");
  const currentVersion = (BUILD_STAMP.match(/v([\d.]+)/) || [])[1] || "0.0.0";
  updateInfo.textContent = BUILD_STAMP;
  if (!UPDATE_CONFIG.latestUrl) {
    // 未配置更新源：不显示检查按钮（发布者填好 latestUrl 后自动出现）
    updateBtn.style.display = "none";
  } else {
    /** 检查并展示结果；silent=true 时只有发现新版本才提示（自动检查不打扰） */
    async function checkAndShow(silent) {
      try {
        const latest = await checkForUpdate();
        if (!latest || !latest.version) return;
        if (latest.version === currentVersion) {
          if (!silent) updateInfo.textContent = t("up_to_date", { v: currentVersion });
          return;
        }
        // 新版本：更新栏显示版本+下载链接，状态栏提示
        const link = latest.chromeZip || latest.firefoxZip || latest.chromeCrx || "";
        updateInfo.textContent = t("update_available", { v: latest.version, notes: latest.notes ? ` ${latest.notes}` : "" });
        if (link && /^https?:\/\//i.test(link)) {
          const a = document.createElement("a");
          a.href = link;
          a.target = "_blank";
          a.rel = "noreferrer";
          a.textContent = t("update_download");
          updateInfo.appendChild(a);
        }
        setStatus(t("update_found", { v: latest.version }));
      } catch (err) {
        if (!silent) updateInfo.textContent = t("update_error", { msg: err && err.message ? err.message : err });
      }
    }
    // 手动检查
    updateBtn.addEventListener("click", async () => {
      updateBtn.disabled = true;
      updateInfo.textContent = t("checking_update");
      await checkAndShow(false);
      updateBtn.disabled = false;
    });
    // 自动检查：启动时 + 每 30 分钟
    checkAndShow(true);
    setInterval(() => checkAndShow(true), 30 * 60 * 1000);
  }
}

onAutoDetectChange();
renderTab("analysis");
