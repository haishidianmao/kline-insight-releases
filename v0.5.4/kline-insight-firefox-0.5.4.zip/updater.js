// @ts-check
import { UPDATE_CONFIG } from "./update-config.js";

/** 检查最新版本（返回 null 表示未配置更新地址） */
export async function checkForUpdate() {
  if (!UPDATE_CONFIG.latestUrl) return null;
  const res = await fetch(UPDATE_CONFIG.latestUrl, { cache: "no-store" });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return res.json();
}
