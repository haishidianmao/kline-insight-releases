// @ts-check

/**
 * 从 URL 识别交易所 / 行情市场。
 * 加密货币：币安 / OKX / Bybit；股票：覆盖 A股、美股、港股、日股、韩股、台股的主流行情网站。
 */
const STOCK_HOST_MARKERS = [
  "10jqka",
  "eastmoney",
  "xueqiu",
  "gtimg",
  "stock.qq.com",
  "gu.qq.com",
  "yahoo.com",
  "yahoo.co.jp",
  "tradingview.com",
  "naver.com",
  "daum.net",
  "kabutan.jp",
  "minkabu.jp",
  "aastocks.com",
  "etnet.com.hk",
  "futunn.com",
  "itiger.com",
  "marketwatch.com",
  "nasdaq.com",
  "cnbc.com",
  "stocktwits.com",
  "finviz.com",
  "webull.com",
  "robinhood.com",
  "investing.com",
  "moomoo.com",
  "moomooapp.com",
  "moomoocn.com",
  "cnyes.com",
  "wantgoo.com",
  "goodinfo.tw",
  "histock.tw",
  "fugle.tw",
  "pchome.com.tw",
  "yahoo.com.tw",
];

/** 国内期货行情站的 host 片段 + 路径特征（命中才算期货，避免与同站股票页混淆） */
const FUTURES_PATH_MARKERS = [
  { host: "sina.com.cn", paths: ["/futures", "/qihuo"] },
  { host: "eastmoney.com", paths: ["/qihuo", "/futures"] },
  { host: "10jqka.com.cn", paths: ["/futures"] },
  { host: "hexun.com", paths: ["/futures", "/qihuo"] },
  { host: "cngold.org", paths: ["/futures", "/qihuo"] },
];

/**
 * @param {string} url
 * @returns {"binance"|"okx"|"bybit"|"stock"|"futures"|null}
 */
export function detectExchangeFromUrl(url) {
  try {
    const host = new URL(url).hostname.toLowerCase();
    const path = new URL(url).pathname.toLowerCase();
    if (host.includes("binance")) return "binance";
    if (host.includes("okx")) return "okx";
    if (host.includes("bybit")) return "bybit";
    for (const f of FUTURES_PATH_MARKERS) {
      if (host.includes(f.host) && f.paths.some((p) => path.includes(p))) return "futures";
    }
    for (const marker of STOCK_HOST_MARKERS) {
      if (host.includes(marker)) return "stock";
    }
  } catch {
    // 忽略非法 URL
  }
  return null;
}

/** A股代码：URL/标题里提取 6 位数字（600519 / sh600519 / SZ000001） */
function detectStockCode(text) {
  const m = String(text || "").match(/(?:sh|sz|bj)?\d{6}/i);
  return m ? m[0].toLowerCase() : null;
}

/** 股票站标题/元信息里的代码：(AAPL) / 00700.HK / (600519) / 腾讯控股 00700 */
function detectStockTicker(text) {
  const s = String(text || "");
  const m = s.match(/\(([A-Z0-9][A-Z0-9.\^=\-]{0,11})\)/i);
  if (m) {
    const t = m[1].toUpperCase();
    if (/^[A-Z]{1,10}(\.(US|HK|T|TW|KS))?$/.test(t)) return t;
    if (/^\d{4,6}(\.(HK|T|TW|KS))?$/.test(t)) return t;
  }
  // 富途等标题：腾讯控股 00700 港股行情
  const m2 = s.match(/\b(\d{5,6})(?:\.(HK|T|TW|KS))?\b/);
  if (m2) return m2[0].toUpperCase();
  return null;
}

/** 港股 5 位补零（700 → 00700） */
function padHk(code) {
  const n = Number(code);
  return Number.isFinite(n) ? String(n).padStart(5, "0") : String(code);
}

/** Yahoo 路径里的 %5E 等编码 → 解码为 ^GSPC 这类指数代码 */
function decodeYahooSymbol(raw) {
  try {
    return decodeURIComponent(String(raw || ""));
  } catch {
    return String(raw || "");
  }
}

/** TradingView 交易所前缀 → 市场代码（NASDAQ:AAPL → AAPL.US、TSE:7203 → 7203.T 等） */
function tvExchangeToRaw(exchange, sym) {
  const ex = String(exchange || "").toUpperCase();
  const s = String(sym || "").toUpperCase();
  if (["NASDAQ", "NYSE", "AMEX", "ARCA", "OTC", "BATS"].includes(ex)) return `${s}.US`;
  if (["HKEX", "SEHK"].includes(ex)) return `${padHk(s)}.HK`;
  if (ex === "TSE") return `${s}.T`;
  if (["KRX", "KOSDAQ"].includes(ex)) return `${s}.KS`;
  if (["TWSE", "TPEX"].includes(ex)) return `${s}.TW`;
  if (["SSE", "SZSE"].includes(ex)) return s;
  // TradingView 指数：SP:SPX、TVC:DJI、TVC:HSI 等
  if (["SP", "TVC"].includes(ex)) {
    if (s === "HSI" || s === "HSCEI") return `${s}.HK`;
    return `${s}.US`;
  }
  return null;
}

/** TradingView 期货交易所前缀 / 带 ! 的合约 → Yahoo 期货代码（CME:ES1! → ES=F） */
function tvFuturesToRaw(exchange, sym) {
  const ex = String(exchange || "").toUpperCase();
  const s = String(sym || "").toUpperCase().replace(/!+$/, "");
  if (s.includes("=")) return s;
  const FUTURES_EXCHANGES = new Set([
    "CME",
    "CME_MINI",
    "CBOT",
    "NYMEX",
    "COMEX",
    "ICE",
    "ICE_EU",
    "EUREX",
    "SGX",
    "LIFFE",
    "CBOE",
    "CFE",
  ]);
  const isFuturesSym = /^\d+!$/.test(String(sym || "")) || /\d+!$/i.test(String(sym || ""));
  if (FUTURES_EXCHANGES.has(ex) || isFuturesSym) {
    const base = s.replace(/\d+$/, "");
    if (/^[A-Z0-9.]{1,8}$/.test(base)) return `${base}=F`;
  }
  return null;
}

/**
 * 从 URL 路径/参数提取交易对或股票代码。
 * 股票统一返回带市场后缀的写法：AAPL.US / 00700.HK / 7203.T / 005930.KS / 2330.TW / sh600519，
 * 交给 symbol-utils 做市场推断与规范化。
 * @param {string} url
 * @returns {string|null}
 */
export function detectSymbolFromUrl(url) {
  try {
    const u = new URL(url);
    const host = u.hostname.toLowerCase();
    const path = u.pathname.toLowerCase();
    const query = u.searchParams;

    // ---- 国内期货行情站（新浪期货 / 东方财富期货 / 同花顺期货 / 和讯期货）----
    if (host.includes("sina.com.cn") && path.includes("/futures")) {
      const m =
        path.match(/\/futures\/quotes\/([a-z0-9]+)/) ||
        path.match(/\/futures\/[^/]*\/([a-z0-9]{2,8})/);
      if (m && /^[a-z]{1,4}\d{0,5}$/i.test(m[1])) return m[1].toUpperCase();
      const q = query.get("symbol");
      if (q && /^[a-z]{1,4}\d{0,5}$/i.test(q)) return q.toUpperCase();
      return null;
    }
    if (host.includes("eastmoney.com") && path.includes("/qihuo")) {
      const m = path.match(/\/qihuo\/([a-z0-9]+)\.html/);
      if (m && /^[a-z]{1,4}\d{0,5}$/i.test(m[1])) return m[1].toUpperCase();
      const q = query.get("code");
      if (q && /^[a-z]{1,4}\d{0,5}$/i.test(q)) return q.toUpperCase();
      return null;
    }
    if (host.includes("10jqka.com.cn") && path.includes("/futures")) {
      const m = path.match(/\/futures\/[^/]*\/([a-z0-9]{2,8})/);
      if (m && /^[a-z]{1,4}\d{0,5}$/i.test(m[1])) return m[1].toUpperCase();
      return null;
    }
    if (host.includes("hexun.com") && path.includes("futures")) {
      const m = path.match(/\/futures\/quote\/([a-z0-9]+)/);
      if (m && /^[a-z]{1,4}\d{0,5}$/i.test(m[1])) return m[1].toUpperCase();
      return null;
    }

    // ---- TradingView（覆盖全球市场）----
    if (host.includes("tradingview.com")) {
      let tv = query.get("symbol");
      if (!tv) {
        const m = path.match(/\/symbols\/([a-z0-9_]+)-([a-z0-9.^=!]+)\/?$/i);
        if (m) tv = `${m[1]}:${m[2]}`;
      }
      if (!tv) {
        // 无交易所前缀：/symbols/SPX/ 这类指数页
        const m = path.match(/\/symbols\/([a-z0-9.^=!]+)\/?$/i);
        if (m) tv = m[1];
      }
      if (tv) {
        if (tv.includes(":")) {
          const [ex, sym] = tv.split(":");
          const fut = tvFuturesToRaw(ex, sym);
          if (fut) return fut;
          return tvExchangeToRaw(ex, sym);
        }
        return `${tv.toUpperCase()}.US`;
      }
      return null;
    }

    // ---- Moomoo（美股 / 港股 / A股 / 日股 / 韩股：/stock/AAPL-US、/hans/stock/00700-HK、/stock/600519-SH）----
    if (host.includes("moomoo")) {
      const m = path.match(/\/(?:stock|etf|etfs|fund|funds)\/([a-z0-9.^=_-]+)(?:\/|$)/i);
      if (m) return decodeURIComponent(m[1]).toUpperCase();
      const code = query.get("code") || query.get("symbol");
      if (code) return String(code).toUpperCase();
      return null;
    }

    // ---- Yahoo Finance（美股 / 港股 / 日股 / 韩股 / 全球）----
    if (host.endsWith("yahoo.com") || host.endsWith("yahoo.co.jp") || host.endsWith("yahoo.com.tw")) {
      const m = path.match(/\/quote\/([a-z0-9.%^=_-]+)/);
      if (m) return decodeYahooSymbol(m[1]).toUpperCase();
      // 雅虎 SPA：地址栏可能只到 /quote，代码在 ?p=AAPL
      if (path.includes("/quote")) {
        const p = query.get("p");
        if (p) return decodeYahooSymbol(p).toUpperCase();
      }
      return null;
    }

    // ---- 台股行情站：鉅亨網 / 玩股網 / Goodinfo / HiStock / Fugle / PChome 股市 ----
    if (host.includes("cnyes.com")) {
      const m = path.match(/\/twstock\/(?:[a-z0-9-]+\/)?(\d{4})(?:\/|$)/i) ||
        path.match(/\/twstock\/(\d{4})/i);
      if (m && m[1]) return `${m[1]}.TW`;
      const c = query.get("code");
      if (c && /^\d{4}$/.test(c)) return `${c}.TW`;
      return null;
    }
    if (host.includes("wantgoo.com")) {
      const m = path.match(/\/stock\/(\d{4})(?:\/|$)/);
      if (m) return `${m[1]}.TW`;
      return null;
    }
    if (host.includes("goodinfo.tw")) {
      const c = query.get("STOCK_ID") || query.get("stock_id");
      if (c && /^\d{4}$/.test(c)) return `${c}.TW`;
      return null;
    }
    if (host.includes("histock.tw")) {
      const m = path.match(/\/stock\/(\d{4})(?:\.\w+)?(?:\/|$)/);
      if (m) return `${m[1]}.TW`;
      return null;
    }
    if (host.includes("fugle.tw")) {
      const m = path.match(/\/markets\/tw\/(\d{4})(?:\/|$)/);
      if (m) return `${m[1]}.TW`;
      return null;
    }
    if (host.includes("pchome.com.tw")) {
      const m = path.match(/\/stock\/(\d{4})(?:\/|$)/);
      if (m) return `${m[1]}.TW`;
      return null;
    }

    // ---- Naver（韩股）----
    if (host.includes("naver.com")) {
      const code = query.get("code") || query.get("no");
      if (code && /^\d{6}$/.test(code)) return `${code}.KS`;
      const m = path.match(/\/item\/([a-z0-9._-]+)\/?$/);
      if (m && /^\d{6}$/.test(m[1])) return `${m[1]}.KS`;
      return null;
    }

    // ---- Daum（韩股）----
    if (host.includes("daum.net")) {
      const m = path.match(/\/quotes\/(?:global\/)?a?(\d{6})/i);
      if (m) return `${m[1]}.KS`;
      return null;
    }

    // ---- Kabutan（日股）----
    if (host.includes("kabutan.jp")) {
      const m = path.match(/\/stock\/?(\d{4})/) || (() => {
        const c = query.get("code");
        return c && /^\d{4}$/.test(c) ? [null, c] : null;
      })();
      if (m && m[1]) return `${m[1]}.T`;
      return null;
    }

    // ---- Minkabu（日股）----
    if (host.includes("minkabu.jp")) {
      const m = path.match(/\/stock\/(\d{4})/);
      if (m) return `${m[1]}.T`;
      return null;
    }

    // ---- AAStocks（港股 / 美股）----
    if (host.includes("aastocks.com")) {
      const hk = path.match(/quote-hk\/(\d{4,5})/);
      if (hk) return `${padHk(hk[1])}.HK`;
      const us = path.match(/quote-us\/([a-z0-9.]+)/);
      if (us) return `${us[1].toUpperCase()}.US`;
      return null;
    }

    // ---- etnet（港股）----
    if (host.includes("etnet.com.hk")) {
      const code = query.get("code");
      if (code && /^\d+$/.test(code)) return `${padHk(code)}.HK`;
      return null;
    }

    // ---- 富途（港股 / 美股 / A股 / 台股：/stock/00700-HK、/en/stock/AAPL-US、/quote/hk/00700、?m=us&code=SPX 等）----
    if (host.includes("futunn.com")) {
      const pathM = path.match(/\/(?:stock|etf|etfs|fund|funds)\/([a-z0-9.]+)-([a-z]{2})\/?$/i);
      if (pathM) {
        const code = pathM[1];
        const market = pathM[2].toLowerCase();
        if (market === "hk") return `${padHk(code)}.HK`;
        if (market === "us") return `${code.toUpperCase()}.US`;
        if (market === "tw") return `${code.toUpperCase()}.TW`;
        if (market === "cn") return code.toLowerCase();
      }
      const quoteM = path.match(/\/quote\/(hk|us|cn|tw)\/([a-z0-9.]+)\/?$/i);
      if (quoteM) {
        const market = quoteM[1].toLowerCase();
        const code = quoteM[2];
        if (market === "hk") return `${padHk(code)}.HK`;
        if (market === "us") return `${code.toUpperCase()}.US`;
        if (market === "tw") return `${code.toUpperCase()}.TW`;
        return code.toLowerCase();
      }
      // 旧版查询参数形态：?m=hk&code=00700
      const m = String(query.get("m") || "").toLowerCase();
      const code = query.get("code");
      if (code) {
        if (m === "hk") return `${padHk(code)}.HK`;
        if (m === "us") return `${code.toUpperCase()}.US`;
        if (m === "tw") return `${code.toUpperCase()}.TW`;
        if (m === "cn") return String(code).toLowerCase();
      }
      return null;
    }

    // ---- 东方财富（美股 / 港股页）----
    if (host.includes("eastmoney.com")) {
      const us = path.match(/\/us\/([a-z0-9.]+)\.html/);
      if (us) return `${us[1].toUpperCase()}.US`;
      const hk = path.match(/\/hk\/(\d{4,5})\.html/);
      if (hk) return `${padHk(hk[1])}.HK`;
    }

    // ---- 雪球（美股 / 港股 / A股 S/ 页）----
    if (host.includes("xueqiu.com")) {
      const m = path.match(/\/s\/([a-z0-9.]+)/);
      if (m) {
        const raw = m[1].toLowerCase();
        if (/^(sh|sz|bj)\d{6}/.test(raw)) return raw;
        if (/^\d{5}$/.test(raw)) return `${raw}.HK`;
        if (/^\d{6}$/.test(raw)) return raw;
        return `${raw.toUpperCase()}.US`;
      }
    }

    // ---- 美股行情站 ---- 
    if (host.includes("marketwatch.com")) {
      const m = path.match(/\/investing\/stock\/([a-z0-9.]+)/);
      if (m) return `${m[1].toUpperCase()}.US`;
      return null;
    }
    if (host.includes("nasdaq.com")) {
      const m = path.match(/\/market-activity\/stocks\/([a-z0-9.]+)/);
      if (m) return `${m[1].toUpperCase()}.US`;
      return null;
    }
    if (host.includes("cnbc.com")) {
      const m = path.match(/\/quotes\/([a-z0-9.]+)/);
      if (m) return `${m[1].toUpperCase()}.US`;
      return null;
    }
    if (host.includes("stocktwits.com")) {
      const m = path.match(/\/symbol\/([a-z0-9.]+)/);
      if (m) return `${m[1].toUpperCase()}.US`;
      return null;
    }
    if (host.includes("finviz.com")) {
      const t = query.get("t");
      if (t) return `${t.toUpperCase()}.US`;
      return null;
    }
    if (host.includes("webull.com")) {
      const m = path.match(/\/quote\/(us|hk|cn|tw)\/([a-z0-9.]+)/);
      if (m) {
        if (m[1] === "us") return `${m[2].toUpperCase()}.US`;
        if (m[1] === "hk") return `${padHk(m[2])}.HK`;
        if (m[1] === "tw") return `${m[2].toUpperCase()}.TW`;
        return m[2];
      }
      return null;
    }
    if (host.includes("robinhood.com")) {
      const m = path.match(/\/stocks\/([a-z0-9.]+)/);
      if (m) return `${m[1].toUpperCase()}.US`;
      return null;
    }

    // ---- 股票代码在查询参数里（c=sh600519 / code=600519 / secid=1.600519 等）----
    const qStock = ["c", "code", "stock", "secid"]
      .map((k) => query.get(k))
      .map((v) => v && String(v).match(/(?:sh|sz|bj)?\d{6}/i)?.[0])
      .find(Boolean);
    if (qStock) return qStock.toLowerCase();

    // ---- 原有：A股行情站 + 币安/OKX/Bybit ----
    const stock = detectStockCode(path);
    if (stock) return stock;
    const bybit = path.match(/\/(?:trade|futures)(?:-[a-z]+)?\/(?:spot|futures|linear|inverse|option)\/([a-z0-9_\-]+)/);
    if (bybit) return bybit[1];
    const m = path.match(/\/(?:trade|futures)[^/]*\/([a-z0-9_\-]+)/);
    if (m) return m[1];
    const seg = path.split("/").filter(Boolean).pop();
    if (!seg) return null;
    const parts = seg.split(/[-_]/);
    const last = parts[parts.length - 1];
    const knownQuote = ["usdt", "usdc", "busd", "fdusd", "dai", "btc", "eth", "try", "eur", "cny", "usd"];
    const futuresSuffix = ["swap", "perp", "perpetual"];
    if (parts.length >= 2 && (knownQuote.includes(last) || futuresSuffix.includes(last))) {
      return seg;
    }
    return null;
  } catch {
    return null;
  }
}

/**
 * 综合检测页面上下文（URL 优先，页面标题兜底）
 * @param {string} url
 * @param {string} title
 * @returns {{exchange: "binance"|"okx"|"bybit"|"stock"|"futures", raw: string}|null}
 */
export function detectPageContext(url, title = "") {
  let exchange = detectExchangeFromUrl(url);
  if (!exchange) return null;
  let raw = detectSymbolFromUrl(url);
  if (!raw && exchange === "stock") {
    raw = detectStockCode(title) || detectStockTicker(title);
  }
  if (!raw && (exchange === "futures" || /期货/.test(title))) {
    const m = String(title || "").match(/\b([A-Z]{1,4}\d{1,5})\b/i);
    if (m) raw = m[1].toUpperCase();
  }
  if (exchange === "stock" && raw && /^[A-Z0-9.]{1,8}=F$/i.test(raw)) {
    exchange = "futures";
  }
  if (!raw && title) {
    const m = title.match(/([A-Za-z]{2,10})\s*\/\s*([A-Za-z]{2,10})/);
    if (m) raw = `${m[1]}/${m[2]}`;
  }
  if (!raw) return null;
  return { exchange, raw };
}
