// @ts-check
/**
 * 图表截图：把 canvas 转成 PNG 并下载。
 * 顶部附加一条标题栏，便于复盘时知道标的/周期/时间。
 */

/** 在截图上方加一条标题栏，返回新 canvas；原画布为空时返回 null */
export function composeChartImage(canvas, headerText, titleHeight = 46) {
  const srcW = canvas.width || 0;
  const srcH = canvas.height || 0;
  if (!srcW || !srcH) return null;
  const out = document.createElement("canvas");
  out.width = srcW;
  out.height = srcH + titleHeight;
  const ctx = out.getContext("2d");
  if (!ctx) return null;
  ctx.fillStyle = "#0b0e14";
  ctx.fillRect(0, 0, srcW, titleHeight);
  ctx.fillStyle = "#dfe6f1";
  ctx.font = "14px system-ui, 'PingFang SC', 'Microsoft YaHei', sans-serif";
  ctx.textBaseline = "middle";
  ctx.fillText(headerText || "", 14, titleHeight / 2);
  ctx.drawImage(canvas, 0, titleHeight);
  return out;
}

/** canvas → blob URL（toBlob 不可用时回退 data URL） */
export function canvasToBlobUrl(canvas, type = "image/png", quality) {
  return new Promise((resolve) => {
    try {
      canvas.toBlob(
        (blob) => {
          if (blob) resolve(URL.createObjectURL(blob));
          else resolve(canvas.toDataURL(type, quality));
        },
        type,
        quality,
      );
    } catch {
      resolve(canvas.toDataURL(type, quality));
    }
  });
}

/** 保存截图：优先走 downloads API，失败时回退 <a download> */
export async function saveCanvas(canvas, { headerText, filename, api }) {
  const out = composeChartImage(canvas, headerText);
  if (!out) return false;
  const url = await canvasToBlobUrl(out);
  try {
    if (api && api.downloads && api.downloads.download) {
      await api.downloads.download({ url, filename, saveAs: false });
      return true;
    }
  } catch {
    /* 回退到 <a download> */
  }
  const a = document.createElement("a");
  a.href = url;
  a.download = filename || "kline-chart.png";
  a.click();
  return true;
}

/** 生成截图文件名：kline-{标的}-{周期}-{YYYYMMDD-HHmm}.png */
export function shotFilename(symbol, interval) {
  const d = new Date();
  const pad = (n) => String(n).padStart(2, "0");
  const safe = String(symbol || "chart").replace(/[^\w.-]+/gu, "-");
  const ts = `${d.getFullYear()}${pad(d.getMonth() + 1)}${pad(d.getDate())}-${pad(d.getHours())}${pad(d.getMinutes())}`;
  return `kline-${safe}-${interval || "na"}-${ts}.png`;
}
