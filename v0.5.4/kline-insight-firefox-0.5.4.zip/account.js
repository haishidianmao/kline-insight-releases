// @ts-check
/**
 * Mullvad 式匿名会员账户：
 * - 账户号由服务器生成（16 位数字），无需邮箱/登录
 * - 一个账户最多绑定 maxDevices 台设备
 * - 到期自动降级为免费版（本地每天 N 次）
 * - 充值码在服务器兑换，直接延长有效期
 */
import { UPDATE_CONFIG } from "./update-config.js";
import { LANG } from "./i18n.js";

const KEY_ACCOUNT = "kiAccount";
const KEY_DEVICE = "kiDeviceId";
const KEY_CACHE = "kiAccountCache";
const CACHE_TTL_MS = 7 * 24 * 3600 * 1000;

function api(path, body) {
  const base = String(UPDATE_CONFIG.licenseApiUrl || "").replace(/\/+$/, "");
  if (!base) throw new Error("licenseApiUrl not configured");
  return fetch(`${base}${path}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body || {}),
  }).then(async (res) => {
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data.error || `HTTP ${res.status}`);
    return data;
  });
}

function randomDeviceId() {
  if (typeof crypto !== "undefined" && crypto.randomUUID) return crypto.randomUUID();
  return `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 12)}`;
}

export async function getDeviceId() {
  const data = await chrome.storage.local.get(KEY_DEVICE);
  if (data[KEY_DEVICE]) return data[KEY_DEVICE];
  const id = randomDeviceId();
  await chrome.storage.local.set({ [KEY_DEVICE]: id });
  return id;
}

export async function getAccountNumber() {
  const data = await chrome.storage.local.get(KEY_ACCOUNT);
  return data[KEY_ACCOUNT] || null;
}

export function formatAccount(account) {
  return String(account || "").replace(/(\d{4})(?=\d)/g, "$1 ");
}

export function isActive(expiresAt) {
  return Number(expiresAt || 0) > Date.now();
}

export async function getCachedState() {
  const data = await chrome.storage.local.get([KEY_ACCOUNT, KEY_DEVICE, KEY_CACHE]);
  const cache = data[KEY_CACHE] || null;
  const fresh =
    cache && cache.expiresAt != null && Date.now() - (cache.cachedAt || 0) < CACHE_TTL_MS;
  return {
    account: data[KEY_ACCOUNT] || null,
    deviceId: data[KEY_DEVICE] || null,
    expiresAt: fresh ? cache.expiresAt : null,
    devices: fresh ? cache.devices : null,
    cachedAt: fresh ? cache.cachedAt : null,
  };
}

/** 创建账号：向服务器申请一个新账号并绑定本设备（同设备重复调用返回原账号） */
export async function createAccount() {
  const deviceId = await getDeviceId();
  const res = await api("/account", { action: "create", deviceId });
  await chrome.storage.local.set({ [KEY_ACCOUNT]: res.account });
  return res;
}

/** 登录已有账号：把本设备绑定到已有账号（第二台设备用同一账号即可共享订阅） */
export async function loginAccount(account, verifyDevice) {
  const acc = String(account || "").replace(/\D/g, "");
  const deviceId = await getDeviceId();
  // verifyDevice：用户输入的任一已绑定设备标识（审计 H7：服务器要求设备验证防踢人占位）
  const res = await api("/account", { action: "login", account: acc, deviceId, verifyDevice: verifyDevice || deviceId });
  await chrome.storage.local.set({ [KEY_ACCOUNT]: res.account });
  return res;
}

/** 拉取账户状态（有效截止时间 + 已绑定设备），并本地缓存 */
export async function refreshStatus() {
  const account = await getAccountNumber();
  const deviceId = await getDeviceId();
  if (!account) throw new Error("no-account");
  const res = await api("/status", { account, deviceId });
  if (res.allowed === false) {
    return { account, deviceId, expiresAt: null, devices: res.devices || [], reason: res.reason || "limit" };
  }
  const state = { account, deviceId, expiresAt: res.expiresAt || null, devices: res.devices || [] };
  await chrome.storage.local.set({
    [KEY_CACHE]: { expiresAt: state.expiresAt, devices: state.devices, cachedAt: Date.now() },
  });
  return state;
}

/** 兑换充值码：延长有效期（新账户自动创建并绑定本设备） */
export async function redeemCode(code) {
  const account = await getAccountNumber();
  const deviceId = await getDeviceId();
  const res = await api("/redeem", { account, code: String(code || "").trim(), deviceId });
  await chrome.storage.local.set({
    [KEY_ACCOUNT]: res.account,
    [KEY_CACHE]: { expiresAt: res.expiresAt, devices: res.devices || [], cachedAt: Date.now() },
  });
  return res;
}

/** 兑换 Gumroad license key：服务器调 Gumroad verify API 验证后给当前账号续期 */
export async function redeemGumroad(licenseKey) {
  const account = await getAccountNumber();
  const deviceId = await getDeviceId();
  const res = await api("/gumroad/redeem", { account, licenseKey: String(licenseKey || "").trim(), deviceId });
  await chrome.storage.local.set({
    [KEY_ACCOUNT]: res.account,
    [KEY_CACHE]: { expiresAt: res.expiresAt, devices: res.devices || [], cachedAt: Date.now() },
  });
  return res;
}

/** 解绑本设备（释放设备名额） */
export async function removeDevice() {
  const account = await getAccountNumber();
  const deviceId = await getDeviceId();
  if (!account) return;
  // verifyDevice：本设备即验证（审计 H7：服务器要求设备归属验证）
  await api("/devices/remove", { account, deviceId, target: deviceId, verifyDevice: deviceId });
  await chrome.storage.local.remove(KEY_CACHE);
}

/**
 * 打开 Paddle 订阅收银台（由 licenseApiUrl 同源的 /checkout 页面承载）。
 * 支付页通过 customData 携带 account，支付成功后 Paddle webhook 直接给该账号续期。
 * @param {"month" | "year"} plan
 */
export async function openCheckout(plan) {
  const base = String(UPDATE_CONFIG.licenseApiUrl || "").replace(/\/+$/, "");
  const account = await getAccountNumber();
  if (!base) throw new Error("licenseApiUrl not configured");
  if (!account) throw new Error("no-account");
  const url = `${base}/checkout?plan=${encodeURIComponent(plan)}&account=${encodeURIComponent(account)}&lang=${encodeURIComponent(LANG || "zh")}`;
  if (typeof chrome !== "undefined" && chrome.tabs && chrome.tabs.create) {
    chrome.tabs.create({ url });
  } else if (typeof browser !== "undefined" && browser.tabs && browser.tabs.create) {
    browser.tabs.create({ url });
  } else {
    window.open(url, "_blank");
  }
}
