// @ts-check

/**
 * 解析自选清单文本：每行一个交易对，支持前缀（binance: / okx: / bybit: / stock: / futures:）或裸交易对（默认 OKX）
 * @param {string} text
 * @returns {Array<{exchange: "binance"|"okx"|"bybit"|"stock"|"futures", symbol: string}>}
 */
export function parseWatchlist(text) {
  const out = [];
  const seen = new Set();
  for (const raw of String(text || "").split(/\r?\n/)) {
    const line = raw.trim();
    if (!line) continue;
    let exchange = "okx";
    let symbol = line;
    const m = line.match(/^(binance|okx|bybit|stock|futures)\s*[:：\s]\s*(.+)$/i);
    if (m) {
      exchange = m[1].toLowerCase();
      symbol = m[2].trim();
    }
    if (!symbol) continue;
    const key = `${exchange}:${symbol}`;
    if (seen.has(key)) continue;
    seen.add(key);
    out.push({ exchange, symbol });
  }
  return out;
}

/**
 * 从识别结果中筛选达到预警门槛的信号（按评分排序）
 * @param {Detection[]} detections
 * @param {{minPriority?: "high"|"medium"|"low", maxItems?: number, latestOnly?: boolean, candleCount?: number}} [opts]
 * @returns {Detection[]}
 */
export function filterSignals(
  detections,
  { minPriority = "medium", maxItems = 5, latestOnly = true, candleCount = 0 } = {},
) {
  const ranks = { high: 3, medium: 2, low: 1 };
  const minRank = ranks[minPriority] || 2;
  return detections
    .filter((d) => d.context && ranks[d.context.priority] >= minRank)
    .filter((d) => {
      // latestOnly 模式只看最新一根K线上的新信号，避免把历史几百条全列出来
      if (!latestOnly) return true;
      return d.index === candleCount - 1;
    })
    .sort((a, b) => (b.context.score || 0) - (a.context.score || 0))
    .slice(0, maxItems);
}

/**
 * 信号去重键
 * @param {{exchange: string, symbol: string}} item
 * @param {{id: string}} detection
 * @returns {string}
 */
export function signalKey(item, detection) {
  return `${item.exchange}:${item.symbol}:${detection.id}@${detection.index ?? "?"}`;
}

/**
 * 生成推送文本
 * @param {{exchange: string, symbol: string, signals: Detection[]}} p
 * @returns {string}
 */
export function formatAlertText({ exchange, symbol, signals }) {
  const label = { okx: "OKX", binance: "币安", bybit: "Bybit", stock: "A股", futures: "期货" }[exchange] || exchange;
  const lines = [
    `【K线形态提醒】${label} ${symbol}`,
    ...signals.map(
      (s) =>
        `• ${s.nameZh}（${s.direction === "bullish" ? "看涨" : s.direction === "bearish" ? "看跌" : "中性"}，${s.context.score}分/${s.context.priority}）${s.summary}`,
    ),
    "仅形态识别参考，不构成投资建议。",
  ];
  return lines.join("\n");
}
