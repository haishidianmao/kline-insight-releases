// @ts-check
/**
 * 交易笔记：纯函数操作本地存储结构，便于单元测试。
 * 存储结构：{ [symbolKey]: Array<{ id, ts, text, interval }> }
 */

/** 空存储 */
export function emptyNotes() {
  return {};
}

/** 新增一条笔记，返回新存储对象（不修改原对象）；内容为空时原样返回 */
export function addNote(store, { key, text, interval = "", extra = {} }) {
  const trimmed = String(text || "").trim();
  if (!key || !trimmed) return store;
  const id = `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
  const note = { id, ts: Date.now(), text: trimmed, interval: String(interval || ""), ...extra };
  const list = Array.isArray(store[key]) ? store[key] : [];
  return { ...store, [key]: [note, ...list] };
}

/** 删除一条笔记，返回新存储对象；找不到时原样返回 */
export function removeNote(store, key, id) {
  if (!key || !id) return store;
  const list = Array.isArray(store[key]) ? store[key] : [];
  if (!list.some((n) => n.id === id)) return store;
  return { ...store, [key]: list.filter((n) => n.id !== id) };
}

/** 取某标的最新在前笔记列表 */
export function notesFor(store, key) {
  const list = Array.isArray(store[key]) ? store[key] : [];
  return list.slice().sort((a, b) => (b.ts || 0) - (a.ts || 0));
}
