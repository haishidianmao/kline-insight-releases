// 产品配置：
// - 更新：把 releases 目录托管到静态服务器 / GitHub Releases 后，把 latest.json 地址填到 latestUrl。
// - 会员（Mullvad 式匿名账户）：部署 server/worker.js 到 Cloudflare Workers 后，
//   把 `https://你的worker.workers.dev` 填到 licenseApiUrl。
//   Paddle 订阅收银台由服务端同源 /checkout 提供（plan=month|year），无需配置 paymentUrl。
export const UPDATE_CONFIG = {
  // 生产：Cloudflare（getmarketcompass.site）→ 香港服务器 43.161.248.9
  latestUrl: "https://getmarketcompass.site/releases/latest.json",
  licenseApiUrl: "https://getmarketcompass.site",
  paymentUrl: "",
  // Gumroad 产品页（会员订阅购买入口）：插件「前往购买」按钮打开
  gumroadBuyUrl: "https://zhumaocai.gumroad.com/l/zezobw",
  dailyFreeLimit: 25,
  maxDevices: 2,
};
