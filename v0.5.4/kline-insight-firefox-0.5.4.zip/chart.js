// @ts-check

const UP = "#2ecc71";
const DOWN = "#e74c3c";
const GRID = "#232f47";
const BG = "#0f1420";
const HIGHLIGHT = "rgba(79,140,255,0.22)";
const LATEST = "#f1c40f";
const PAD_L = 8;
const PAD_R = 8;

/** 把可视窗口限制在合法索引范围内 */
function clampRange(range, n) {
  if (n <= 0) return [0, 0];
  if (!range || range.length !== 2) return [0, n - 1];
  let [s, e] = range;
  s = Math.max(0, Math.min(n - 1, Math.round(s)));
  e = Math.max(s, Math.min(n - 1, Math.round(e)));
  return [s, e];
}

/** 默认可视窗口：最近 100 根（避免 200-500 根K线挤成一团） */
export function defaultViewRange(count) {
  const n = Math.max(1, count || 1);
  return [Math.max(0, n - 100), n - 1];
}

/**
 * 由画布上的 CSS 横坐标换算K线索引（用于滚轮缩放/拖拽平移定位）
 * @param {HTMLCanvasElement} canvas
 * @param {number} cssX
 * @param {[number, number]|null} viewRange
 * @param {number} count
 * @returns {number}
 */
export function indexFromX(canvas, cssX, viewRange, count) {
  const dpr = canvas.width / Math.max(1, canvas.clientWidth || 1);
  const x = cssX * dpr;
  const w = canvas.width;
  const plotW = w - PAD_L - PAD_R;
  if (plotW <= 0 || count <= 0) return 0;
  const [s, e] = clampRange(viewRange, count);
  const visible = e - s + 1;
  const idx = s + Math.floor((x - PAD_L) / (plotW / visible));
  return Math.max(s, Math.min(e, idx));
}

/** 按价格区间自适应小数位 */
function fmtPrice(price, minP, maxP) {
  const span = maxP - minP;
  const digits = span < 0.001 ? 8 : span < 1 ? 6 : span < 100 ? 4 : 2;
  return price.toFixed(digits);
}

/**
 * 在 canvas 上绘制K线图（含可视窗口、成交量、选中区间高亮、最新收盘价线、水平线）
 * @param {HTMLCanvasElement} canvas
 * @param {Candle[]} candles
 * @param {{viewRange?: [number, number]|null, selectedRange?: [number, number]|null, levels?: Object|null}} [options]
 */
export function drawCandles(
  canvas,
  candles,
  { viewRange = null, selectedRange = null, levels = null, labels = {} } = {},
) {
  const ctx = canvas.getContext("2d");
  const w = canvas.width;
  const h = canvas.height;
  ctx.clearRect(0, 0, w, h);
  if (!candles || candles.length === 0) return;

  const n = candles.length;
  const [vi0, vi1] = clampRange(viewRange || defaultViewRange(n), n);
  const visible = vi1 - vi0 + 1;
  const padL = PAD_L;
  const padR = PAD_R;
  const volH = Math.max(36, h * 0.16);
  const priceTop = 8;
  const priceBottom = h - volH - 12;
  const plotW = w - padL - padR;
  const priceH = priceBottom - priceTop;

  let minP = Infinity;
  let maxP = -Infinity;
  let maxV = 0;
  for (let i = vi0; i <= vi1; i++) {
    const c = candles[i];
    if (c.low < minP) minP = c.low;
    if (c.high > maxP) maxP = c.high;
    if ((c.volume || 0) > maxV) maxV = c.volume || 0;
  }
  const padP = (maxP - minP) * 0.05 || 1;
  minP -= padP;
  maxP += padP;
  const y = (p) => priceBottom - ((p - minP) / (maxP - minP)) * priceH;
  const x = (i) => padL + (i - vi0 + 0.5) * (plotW / visible);
  const bw = Math.max(1, Math.min((plotW / visible) * 0.7, 36));

  // 背景
  ctx.fillStyle = BG;
  ctx.fillRect(0, 0, w, h);

  // 横向网格 + 价格标签
  ctx.strokeStyle = GRID;
  ctx.lineWidth = 1;
  ctx.font = "10px sans-serif";
  for (let g = 0; g <= 4; g++) {
    const gy = priceTop + (priceH / 4) * g;
    const price = maxP - (maxP - minP) * (g / 4);
    ctx.beginPath();
    ctx.moveTo(padL, gy);
    ctx.lineTo(w - padR, gy);
    ctx.stroke();
    ctx.fillStyle = "rgba(143,157,184,0.75)";
    ctx.fillText(fmtPrice(price, minP, maxP), w - padR - 60, gy - 3);
  }

  // 选中区间高亮（裁剪到可视窗口）
  if (selectedRange && selectedRange.length === 2) {
    const s = Math.max(vi0, selectedRange[0]);
    const e = Math.min(vi1, selectedRange[1]);
    if (s <= e) {
      const x0 = x(s) - bw / 2 - 2;
      const x1 = x(e) + bw / 2 + 2;
      ctx.fillStyle = HIGHLIGHT;
      ctx.fillRect(x0, priceTop, Math.max(2, x1 - x0), priceH);
    }
  }

  // K线
  for (let i = vi0; i <= vi1; i++) {
    const c = candles[i];
    const up = c.close >= c.open;
    ctx.strokeStyle = up ? UP : DOWN;
    ctx.fillStyle = up ? UP : DOWN;
    ctx.lineWidth = 1;
    const cx = x(i);
    ctx.beginPath();
    ctx.moveTo(cx, y(c.high));
    ctx.lineTo(cx, y(c.low));
    ctx.stroke();
    const top = y(Math.max(c.open, c.close));
    const bot = y(Math.min(c.open, c.close));
    const bodyH = Math.max(1, bot - top);
    ctx.fillRect(cx - bw / 2, top, bw, bodyH);
  }

  // 成交量
  if (maxV > 0) {
    for (let i = vi0; i <= vi1; i++) {
      const c = candles[i];
      const v = c.volume || 0;
      const vh = (v / maxV) * (volH - 8);
      const up = c.close >= c.open;
      ctx.fillStyle = up ? "rgba(46,204,113,0.45)" : "rgba(231,76,60,0.45)";
      ctx.fillRect(x(i) - bw / 2, h - volH + (volH - vh), bw, vh);
    }
  }

  // 最新收盘价虚线（仅当可视窗口包含最新K线）
  if (vi1 === n - 1) {
    ctx.strokeStyle = LATEST;
    ctx.setLineDash([4, 3]);
    ctx.beginPath();
    ctx.moveTo(padL, y(candles[n - 1].close));
    ctx.lineTo(w - padR, y(candles[n - 1].close));
    ctx.stroke();
    ctx.setLineDash([]);
  }

  // 关键水平线：支撑/阻力/斐波那契/VWAP
  if (levels) {
    const drawLevel = (price, color, label) => {
      if (price == null) return;
      const py = y(price);
      if (py < priceTop || py > priceBottom) return;
      ctx.strokeStyle = color;
      ctx.lineWidth = 1;
      ctx.setLineDash([3, 3]);
      ctx.beginPath();
      ctx.moveTo(padL, py);
      ctx.lineTo(w - padR, py);
      ctx.stroke();
      ctx.setLineDash([]);
      ctx.fillStyle = color;
      ctx.font = "10px sans-serif";
      ctx.fillText(label, padL + 2, py - 3);
    };
    for (const s of levels.supports || []) drawLevel(s, "rgba(46,204,113,0.85)", labels.support || "支撑");
    for (const r of levels.resistances || []) drawLevel(r, "rgba(231,76,60,0.85)", labels.resistance || "阻力");
    for (const l of (levels.fibonacci && levels.fibonacci.levels) || []) {
      drawLevel(l.price, "rgba(143,157,184,0.6)", String(l.ratio));
    }
    if (levels.vwap != null) drawLevel(levels.vwap, "rgba(241,196,15,0.85)", "VWAP");
  }
}
