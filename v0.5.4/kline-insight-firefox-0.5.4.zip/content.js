// 内容脚本：自动识别当前页面（币安/OKX/Bybit/A股/美股/港股/日股/韩股行情站）的交易所与交易对
// 注意：内容脚本为经典脚本（无 import），逻辑与 page-detector.js 保持一致

const STOCK_HOST_MARKERS = [
  "10jqka",
  "eastmoney",
  "xueqiu",
  "gtimg",
  "stock.qq.com",
  "gu.qq.com",
  "yahoo.com",
  "yahoo.co.jp",
  "tradingview.com",
  "naver.com",
  "daum.net",
  "kabutan.jp",
  "minkabu.jp",
  "aastocks.com",
  "etnet.com.hk",
  "futunn.com",
  "itiger.com",
  "marketwatch.com",
  "nasdaq.com",
  "cnbc.com",
  "stocktwits.com",
  "finviz.com",
  "webull.com",
  "robinhood.com",
  "investing.com",
  "moomoo.com",
  "moomooapp.com",
  "moomoocn.com",
  "cnyes.com",
  "wantgoo.com",
  "goodinfo.tw",
  "histock.tw",
  "fugle.tw",
  "pchome.com.tw",
  "yahoo.com.tw",
];

const FUTURES_PATH_MARKERS = [
  { host: "sina.com.cn", paths: ["/futures", "/qihuo"] },
  { host: "eastmoney.com", paths: ["/qihuo", "/futures"] },
  { host: "10jqka.com.cn", paths: ["/futures"] },
  { host: "hexun.com", paths: ["/futures", "/qihuo"] },
  { host: "cngold.org", paths: ["/futures", "/qihuo"] },
];

function detectExchangeFromUrl(url) {
  try {
    const host = new URL(url).hostname.toLowerCase();
    const path = new URL(url).pathname.toLowerCase();
    if (host.includes("binance")) return "binance";
    if (host.includes("okx")) return "okx";
    if (host.includes("bybit")) return "bybit";
    for (const f of FUTURES_PATH_MARKERS) {
      if (host.includes(f.host) && f.paths.some((p) => path.includes(p))) return "futures";
    }
    for (const marker of STOCK_HOST_MARKERS) {
      if (host.includes(marker)) return "stock";
    }
  } catch (e) {
    // 忽略
  }
  return null;
}

function detectStockCode(text) {
  const m = String(text || "").match(/(?:sh|sz|bj)?\d{6}/i);
  return m ? m[0].toLowerCase() : null;
}

/** 股票站标题/元信息里的代码：(AAPL) / 00700.HK / (600519) / 腾讯控股 00700 */
function detectStockTicker(text) {
  const s = String(text || "");
  const m = s.match(/\(([A-Z0-9][A-Z0-9.\^=\-]{0,11})\)/i);
  if (m) {
    const t = m[1].toUpperCase();
    if (/^[A-Z]{1,10}(\.(US|HK|T|KS))?$/.test(t)) return t;
    if (/^\d{4,6}(\.(HK|T|KS))?$/.test(t)) return t;
  }
  // 富途等标题：腾讯控股 00700 港股行情
  const m2 = s.match(/\b(\d{5,6})(?:\.(HK|T|KS))?\b/);
  if (m2) return m2[0].toUpperCase();
  return null;
}

function padHk(code) {
  const n = Number(code);
  return Number.isFinite(n) ? String(n).padStart(5, "0") : String(code);
}

function decodeYahooSymbol(raw) {
  try {
    return decodeURIComponent(String(raw || ""));
  } catch (e) {
    return String(raw || "");
  }
}

function tvExchangeToRaw(exchange, sym) {
  const ex = String(exchange || "").toUpperCase();
  const s = String(sym || "").toUpperCase();
  if (["NASDAQ", "NYSE", "AMEX", "ARCA", "OTC", "BATS"].includes(ex)) return `${s}.US`;
  if (["HKEX", "SEHK"].includes(ex)) return `${padHk(s)}.HK`;
  if (ex === "TSE") return `${s}.T`;
  if (["KRX", "KOSDAQ"].includes(ex)) return `${s}.KS`;
  if (["TWSE", "TPEX"].includes(ex)) return `${s}.TW`;
  if (["SSE", "SZSE"].includes(ex)) return s;
  if (["SP", "TVC"].includes(ex)) {
    if (s === "HSI" || s === "HSCEI") return `${s}.HK`;
    return `${s}.US`;
  }
  return null;
}

function tvFuturesToRaw(exchange, sym) {
  const ex = String(exchange || "").toUpperCase();
  const s = String(sym || "").toUpperCase().replace(/!+$/, "");
  if (s.includes("=")) return s;
  const FUTURES_EXCHANGES = new Set([
    "CME",
    "CME_MINI",
    "CBOT",
    "NYMEX",
    "COMEX",
    "ICE",
    "ICE_EU",
    "EUREX",
    "SGX",
    "LIFFE",
    "CBOE",
    "CFE",
  ]);
  const isFuturesSym = /^\d+!$/.test(String(sym || "")) || /\d+!$/i.test(String(sym || ""));
  if (FUTURES_EXCHANGES.has(ex) || isFuturesSym) {
    const base = s.replace(/\d+$/, "");
    if (/^[A-Z0-9.]{1,8}$/.test(base)) return `${base}=F`;
  }
  return null;
}

function detectSymbolFromUrl(url) {
  try {
    const u = new URL(url);
    const host = u.hostname.toLowerCase();
    const path = u.pathname.toLowerCase();
    const query = u.searchParams;

    if (host.includes("sina.com.cn") && path.includes("/futures")) {
      const m =
        path.match(/\/futures\/quotes\/([a-z0-9]+)/) ||
        path.match(/\/futures\/[^/]*\/([a-z0-9]{2,8})/);
      if (m && /^[a-z]{1,4}\d{0,5}$/i.test(m[1])) return m[1].toUpperCase();
      const q = query.get("symbol");
      if (q && /^[a-z]{1,4}\d{0,5}$/i.test(q)) return q.toUpperCase();
      return null;
    }
    if (host.includes("eastmoney.com") && path.includes("/qihuo")) {
      const m = path.match(/\/qihuo\/([a-z0-9]+)\.html/);
      if (m && /^[a-z]{1,4}\d{0,5}$/i.test(m[1])) return m[1].toUpperCase();
      const q = query.get("code");
      if (q && /^[a-z]{1,4}\d{0,5}$/i.test(q)) return q.toUpperCase();
      return null;
    }
    if (host.includes("10jqka.com.cn") && path.includes("/futures")) {
      const m = path.match(/\/futures\/[^/]*\/([a-z0-9]{2,8})/);
      if (m && /^[a-z]{1,4}\d{0,5}$/i.test(m[1])) return m[1].toUpperCase();
      return null;
    }
    if (host.includes("hexun.com") && path.includes("futures")) {
      const m = path.match(/\/futures\/quote\/([a-z0-9]+)/);
      if (m && /^[a-z]{1,4}\d{0,5}$/i.test(m[1])) return m[1].toUpperCase();
      return null;
    }

    if (host.includes("tradingview.com")) {
      let tv = query.get("symbol");
      if (!tv) {
        const m = path.match(/\/symbols\/([a-z0-9_]+)-([a-z0-9.^=!]+)\/?$/i);
        if (m) tv = `${m[1]}:${m[2]}`;
      }
      if (!tv) {
        const m = path.match(/\/symbols\/([a-z0-9.^=!]+)\/?$/i);
        if (m) tv = m[1];
      }
      if (tv) {
        if (tv.includes(":")) {
          const parts = tv.split(":");
          const fut = tvFuturesToRaw(parts[0], parts[1]);
          if (fut) return fut;
          return tvExchangeToRaw(parts[0], parts[1]);
        }
        return `${tv.toUpperCase()}.US`;
      }
      return null;
    }

    // Moomoo：/stock/AAPL-US、/hans/stock/00700-HK、/stock/600519-SH
    if (host.includes("moomoo")) {
      const m = path.match(/\/(?:stock|etf|etfs|fund|funds)\/([a-z0-9.^=_-]+)(?:\/|$)/i);
      if (m) return decodeURIComponent(m[1]).toUpperCase();
      const code = query.get("code") || query.get("symbol");
      if (code) return String(code).toUpperCase();
      return null;
    }

    if (host.endsWith("yahoo.com") || host.endsWith("yahoo.co.jp") || host.endsWith("yahoo.com.tw")) {
      const m = path.match(/\/quote\/([a-z0-9.%^=_-]+)/);
      if (m) return decodeYahooSymbol(m[1]).toUpperCase();
      // 雅虎 SPA：地址栏可能只到 /quote，代码在 ?p=AAPL
      if (path.includes("/quote")) {
        const p = query.get("p");
        if (p) return decodeYahooSymbol(p).toUpperCase();
      }
      return null;
    }

    if (host.includes("naver.com")) {
      const code = query.get("code") || query.get("no");
      if (code && /^\d{6}$/.test(code)) return `${code}.KS`;
      const m = path.match(/\/item\/([a-z0-9._-]+)\/?$/);
      if (m && /^\d{6}$/.test(m[1])) return `${m[1]}.KS`;
      return null;
    }

    if (host.includes("daum.net")) {
      const m = path.match(/\/quotes\/(?:global\/)?a?(\d{6})/i);
      if (m) return `${m[1]}.KS`;
      return null;
    }

    if (host.includes("kabutan.jp")) {
      const m = path.match(/\/stock\/?(\d{4})/);
      const c = m || (() => {
        const v = query.get("code");
        return v && /^\d{4}$/.test(v) ? [null, v] : null;
      })();
      if (c && c[1]) return `${c[1]}.T`;
      return null;
    }

    if (host.includes("minkabu.jp")) {
      const m = path.match(/\/stock\/(\d{4})/);
      if (m) return `${m[1]}.T`;
      return null;
    }

    if (host.includes("aastocks.com")) {
      const hk = path.match(/quote-hk\/(\d{4,5})/);
      if (hk) return `${padHk(hk[1])}.HK`;
      const us = path.match(/quote-us\/([a-z0-9.]+)/);
      if (us) return `${us[1].toUpperCase()}.US`;
      return null;
    }

    if (host.includes("etnet.com.hk")) {
      const code = query.get("code");
      if (code && /^\d+$/.test(code)) return `${padHk(code)}.HK`;
      return null;
    }

    if (host.includes("futunn.com")) {
      const pathM = path.match(/\/(?:stock|etf|etfs|fund|funds)\/([a-z0-9.]+)-([a-z]{2})\/?$/i);
      if (pathM) {
        const code = pathM[1];
        const market = pathM[2].toLowerCase();
        if (market === "hk") return `${padHk(code)}.HK`;
        if (market === "us") return `${code.toUpperCase()}.US`;
        if (market === "tw") return `${code.toUpperCase()}.TW`;
        if (market === "cn") return code.toLowerCase();
      }
      const quoteM = path.match(/\/quote\/(hk|us|cn|tw)\/([a-z0-9.]+)\/?$/i);
      if (quoteM) {
        const market = quoteM[1].toLowerCase();
        const code = quoteM[2];
        if (market === "hk") return `${padHk(code)}.HK`;
        if (market === "us") return `${code.toUpperCase()}.US`;
        if (market === "tw") return `${code.toUpperCase()}.TW`;
        return code.toLowerCase();
      }
      const m = String(query.get("m") || "").toLowerCase();
      const code = query.get("code");
      if (code) {
        if (m === "hk") return `${padHk(code)}.HK`;
        if (m === "us") return `${code.toUpperCase()}.US`;
        if (m === "tw") return `${code.toUpperCase()}.TW`;
        if (m === "cn") return String(code).toLowerCase();
      }
      return null;
    }

    if (host.includes("eastmoney.com")) {
      const us = path.match(/\/us\/([a-z0-9.]+)\.html/);
      if (us) return `${us[1].toUpperCase()}.US`;
      const hk = path.match(/\/hk\/(\d{4,5})\.html/);
      if (hk) return `${padHk(hk[1])}.HK`;
    }

    if (host.includes("xueqiu.com")) {
      const m = path.match(/\/s\/([a-z0-9.]+)/);
      if (m) {
        const raw = m[1].toLowerCase();
        if (/^(sh|sz|bj)\d{6}/.test(raw)) return raw;
        if (/^\d{5}$/.test(raw)) return `${raw}.HK`;
        if (/^\d{6}$/.test(raw)) return raw;
        return `${raw.toUpperCase()}.US`;
      }
    }

    if (host.includes("marketwatch.com")) {
      const m = path.match(/\/investing\/stock\/([a-z0-9.]+)/);
      if (m) return `${m[1].toUpperCase()}.US`;
      return null;
    }
    if (host.includes("nasdaq.com")) {
      const m = path.match(/\/market-activity\/stocks\/([a-z0-9.]+)/);
      if (m) return `${m[1].toUpperCase()}.US`;
      return null;
    }
    if (host.includes("cnbc.com")) {
      const m = path.match(/\/quotes\/([a-z0-9.]+)/);
      if (m) return `${m[1].toUpperCase()}.US`;
      return null;
    }
    if (host.includes("stocktwits.com")) {
      const m = path.match(/\/symbol\/([a-z0-9.]+)/);
      if (m) return `${m[1].toUpperCase()}.US`;
      return null;
    }
    if (host.includes("finviz.com")) {
      const t = query.get("t");
      if (t) return `${t.toUpperCase()}.US`;
      return null;
    }
    if (host.includes("webull.com")) {
      const m = path.match(/\/quote\/(us|hk|cn)\/([a-z0-9.]+)/);
      if (m) {
        if (m[1] === "us") return `${m[2].toUpperCase()}.US`;
        if (m[1] === "hk") return `${padHk(m[2])}.HK`;
        return m[2];
      }
      return null;
    }
    if (host.includes("robinhood.com")) {
      const m = path.match(/\/stocks\/([a-z0-9.]+)/);
      if (m) return `${m[1].toUpperCase()}.US`;
      return null;
    }

    const qStock = ["c", "code", "stock", "secid"]
      .map((k) => query.get(k))
      .map((v) => v && String(v).match(/(?:sh|sz|bj)?\d{6}/i)?.[0])
      .find(Boolean);
    if (qStock) return qStock.toLowerCase();

    const stock = detectStockCode(path);
    if (stock) return stock;
    const bybit = path.match(/\/(?:trade|futures)(?:-[a-z]+)?\/(?:spot|futures|linear|inverse|option)\/([a-z0-9_\-]+)/);
    if (bybit) return bybit[1];
    const m = path.match(/\/(?:trade|futures)[^/]*\/([a-z0-9_\-]+)/);
    if (m) return m[1];
    const seg = path.split("/").filter(Boolean).pop();
    if (!seg) return null;
    const parts = seg.split(/[-_]/);
    const last = parts[parts.length - 1];
    const knownQuote = ["usdt", "usdc", "busd", "fdusd", "dai", "btc", "eth", "try", "eur", "cny", "usd"];
    const futuresSuffix = ["swap", "perp", "perpetual"];
    if (parts.length >= 2 && (knownQuote.includes(last) || futuresSuffix.includes(last))) {
      return seg;
    }
    return null;
  } catch (e) {
    return null;
  }
}

/** SPA 股票站兜底：og:url / og:title / 页面属性里的代码 */
function detectStockFromDom() {
  const ogUrl = document.querySelector('meta[property="og:url"]');
  if (ogUrl && ogUrl.content) {
    const raw = detectSymbolFromUrl(ogUrl.content);
    if (raw) return raw;
  }
  const attrs = ["data-code", "data-symbol", "data-stock", "data-secid", "data-market-code"];
  for (const attr of attrs) {
    const el = document.querySelector(`[${attr}]`);
    if (!el) continue;
    const v = String(el.getAttribute(attr) || "").trim();
    const code = v.match(/(?:sh|sz|bj)?\d{4,6}/i);
    if (code) return code[0].toLowerCase();
    const ticker = v.match(/^[A-Z][A-Z0-9.\-]{0,10}$/i);
    if (ticker) return ticker[0].toUpperCase();
  }
  const ogTitle = document.querySelector('meta[property="og:title"]');
  const title = (ogTitle && ogTitle.content) || document.title;
  return detectStockCode(title) || detectStockTicker(title);
}

function detectPageContext() {
  let exchange = detectExchangeFromUrl(location.href);
  if (!exchange) return null;
  let raw = detectSymbolFromUrl(location.href);
  if (!raw && exchange === "stock") {
    raw = detectStockFromDom();
  }
  if (!raw && (exchange === "futures" || /期货/.test(document.title))) {
    const m = document.title.match(/\b([A-Z]{1,4}\d{1,5})\b/i);
    if (m) raw = m[1].toUpperCase();
  }
  if (exchange === "stock" && raw && /^[A-Z0-9.]{1,8}=F$/i.test(raw)) {
    exchange = "futures";
  }
  if (!raw) {
    const m = document.title.match(/([A-Za-z]{2,10})\s*\/\s*([A-Za-z]{2,10})/);
    if (m) raw = m[1] + "/" + m[2];
  }
  if (!raw) return null;
  return { exchange, raw };
}

let lastKey = "";

function tick() {
  const ctx = detectPageContext();
  const key = ctx ? `${ctx.exchange}:${ctx.raw}` : "";
  if (key && key !== lastKey) {
    lastKey = key;
    try {
      chrome.storage.local.set({ pageContext: { exchange: ctx.exchange, raw: ctx.raw, key, ts: Date.now() } });
    } catch (e) {
      // 忽略存储错误
    }
  } else if (!key) {
    lastKey = "";
  }
}

// 交易所/OKX/Yahoo 等是单页应用，地址变化不刷新页面：定时轮询兜底 + popstate 即时触发
setInterval(tick, 1500);
tick();
// SPA 前进/后退（popstate）立即重新检测，不等轮询
window.addEventListener("popstate", () => setTimeout(tick, 50));
// 拦截 history.pushState/replaceState：SPA 页面内切换（如 Yahoo 换股票）URL 变化即时检测
try {
  const patchHistory = (type) => {
    const orig = history[type];
    history[type] = function (...args) {
      const r = orig.apply(this, args);
      setTimeout(tick, 50);
      return r;
    };
  };
  patchHistory("pushState");
  patchHistory("replaceState");
} catch (e) {
  // 某些页面禁止改写 history，轮询仍兜底
}
