// @ts-check
/** 免费版每日使用次数（本地计数，会员账户有效时不限次） */
import { UPDATE_CONFIG } from "./update-config.js";

// V5：升级键名重置旧计数（2026-08-13 用户要求再次恢复免费次数）
const KEY = "kiQuotaV5";

export function todayKey() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(
    d.getDate(),
  ).padStart(2, "0")}`;
}

export async function getQuota() {
  const data = await chrome.storage.local.get(KEY);
  const q = data[KEY] || { date: todayKey(), used: 0 };
  if (q.date !== todayKey()) {
    q.date = todayKey();
    q.used = 0;
  }
  return q;
}

/** 消耗一次使用额度；会员（active=true）不限次 */
export async function tryConsume(active) {
  if (active) return { allowed: true, remaining: Infinity, unlimited: true };
  const q = await getQuota();
  const limit = Math.max(1, Number(UPDATE_CONFIG.dailyFreeLimit) || 25);
  if (q.used >= limit) {
    return { allowed: false, remaining: 0, unlimited: false };
  }
  q.used += 1;
  await chrome.storage.local.set({ [KEY]: q });
  return { allowed: true, remaining: limit - q.used, unlimited: false };
}

export async function getQuotaInfo() {
  const q = await getQuota();
  const limit = Math.max(1, Number(UPDATE_CONFIG.dailyFreeLimit) || 25);
  return { used: q.used, limit, remaining: Math.max(0, limit - q.used) };
}
