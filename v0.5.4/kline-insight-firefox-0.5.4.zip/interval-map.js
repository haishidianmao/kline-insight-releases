// @ts-check

/**
 * 通用周期 → OKX 周期格式映射
 * OKX 的分钟用小写（15m），小时/日/周用大写（1H、1D、1W），不能统一大小写。
 */
const OKX_BAR_MAP = {
  "1m": "1m",
  "3m": "3m",
  "5m": "5m",
  "15m": "15m",
  "30m": "30m",
  "1h": "1H",
  "2h": "2H",
  "4h": "4H",
  "6h": "6H",
  "12h": "12H",
  "1d": "1D",
  "1w": "1W",
  "1M": "1M",
};

/**
 * @param {string} interval
 * @returns {string}
 */
export function toOkxBar(interval) {
  const mapped = OKX_BAR_MAP[interval];
  if (mapped) return mapped;
  // 兜底：分钟保持小写，其余转大写
  if (/^\d+m$/.test(interval)) return interval;
  return interval.toUpperCase();
}

/** Bybit K线周期映射（分钟用数字，小时用 60 的倍数，日/周/月用字母） */
const BYBIT_BAR_MAP = {
  "1m": "1",
  "3m": "3",
  "5m": "5",
  "15m": "15",
  "30m": "30",
  "1h": "60",
  "2h": "120",
  "4h": "240",
  "6h": "360",
  "12h": "720",
  "1d": "D",
  "1w": "W",
  "1M": "M",
};

/**
 * 通用周期 → Bybit 周期格式
 * @param {string} interval
 * @returns {string}
 */
export function toBybitBar(interval) {
  return BYBIT_BAR_MAP[interval] || String(interval).toUpperCase();
}

/** 通用周期 → 腾讯行情分钟/日/周/月格式（A股） */
const TENCENT_BAR_MAP = {
  "5m": "m5",
  "15m": "m15",
  "30m": "m30",
  "1h": "m60",
  "1d": "day",
  "1w": "week",
  "1M": "month",
};

/**
 * 通用周期 → 腾讯行情周期格式（A股）
 * @param {string} interval
 * @returns {string|null}
 */
export function toTencentBar(interval) {
  // 不支持的周期返回 null（调用方跳过腾讯源兜底其他源），不静默降级为日线——否则 4h/3m 会拿到日线冒充分钟线
  return TENCENT_BAR_MAP[interval] || null;
}

/** 通用周期 → 新浪期货分钟线 type（1/5/15/30/60；日/周/月走日线接口） */
const SINA_FUTURES_MIN_MAP = {
  "1m": 1,
  "5m": 5,
  "15m": 15,
  "30m": 30,
  "1h": 60,
};

/**
 * 通用周期 → 新浪期货分钟线 type；非分钟周期返回 null
 * @param {string} interval
 * @returns {number|null}
 */
export function toSinaFuturesType(interval) {
  return SINA_FUTURES_MIN_MAP[interval] ?? null;
}
