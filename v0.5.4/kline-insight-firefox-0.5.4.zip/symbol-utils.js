// @ts-check

/** OKX 常见计价币（用于把 BTCUSDT 这类无横线写法拆成 BTC-USDT） */
const OKX_QUOTES = ["USDT", "USDC", "FDUSD", "BTC", "ETH", "EUR", "TRY"];

/** 中文加密货币名称 → 币种代码（比特币 → BTC） */
const CRYPTO_CN_ALIASES = {
  "比特币": "BTC", "比特": "BTC", "以太坊": "ETH", "以太": "ETH",
  "狗狗币": "DOGE", "瑞波币": "XRP", "索拉纳": "SOL", "艾达币": "ADA",
  "卡尔达诺": "ADA", "艾达": "ADA", "波卡币": "DOT", "波卡": "DOT",
  "莱特币": "LTC", "比特现金": "BCH", "柴犬币": "SHIB", "币安币": "BNB",
  "柚子币": "EOS", "柚子": "EOS", "以太经典": "ETC", "波场币": "TRX",
  "波场": "TRX", "门罗币": "XMR", "达世币": "DASH", "恒星币": "XLM",
  "泰达币": "USDT", "索拉纳币": "SOL", "大零币": "ZEC", "小蚁币": "NEO",
  "阿童木": "ATOM", "宇宙": "ATOM", "链接": "LINK",
  "奥米加": "OMG", "多边形": "MATIC", "雪崩": "AVAX",
  "超级碗": "SUPER", "阿普特斯": "APT", "阿尔戈": "AR", "幻想": "FTM",
};

/** 常见加密货币代码（用于自动判断数据源：字母代码是币种还是美股） */
const EN_CRYPTO = new Set([
  "BTC", "ETH", "DOGE", "XRP", "SOL", "ADA", "DOT", "LTC", "BCH", "SHIB",
  "BNB", "EOS", "ETC", "TRX", "XMR", "DASH", "XLM", "USDT", "USDC", "FDUSD",
  "ATOM", "LINK", "OMG", "MATIC", "AVAX", "SUPER", "APT", "AR", "FTM", "TON",
  "SUI", "PEPE", "WIF", "NEAR", "OKB", "INJ", "OP", "ARB", "SEI", "TIA",
  "AAVE", "UNI", "LDO", "RNDR", "FET", "AGIX", "GRT", "SAND", "MANA", "AXS",
  "GALA", "ENA", "ETHFI", "JUP", "JTO", "PYTH", "ORDI", "SATS", "1000SATS",
]);

/**
 * 按标的自动判断数据源（数据源下拉隐藏后使用）：
 * - 中文币名 / 已知加密币 → binance
 * - 期货（带 = 或 RB2510 这类数字字母混合）→ futures
 * - 指数 ^ / 纯数字 / 带市场后缀 → stock
 * - 其余字母 → stock（美股）
 */
export function autoDetectExchange(raw) {
  const s = String(raw || "").trim().toUpperCase();
  if (!s) return "binance";
  if (CRYPTO_CN_ALIASES[String(raw).trim()]) return "binance";
  if (EN_CRYPTO.has(s)) return "binance";
  // 加密币对（BTCUSDT / BTC-USD / ETHUSDC / SOL / PEPEUSDT…）→ binance（须在 "-" 规则之前）
  if (
    /^(BTC|ETH|DOGE|SOL|XRP|BNB|ADA|DOT|LTC|BCH|SHIB|TRX|EOS|ETC|XMR|DASH|XLM|ATOM|LINK|MATIC|AVAX|FTM|TON|SUI|PEPE|NEAR|UNI|AAVE|LDO|ARB|OP|INJ|TIA|SEI|JUP|JTO|ORDI|SATS|WIF|ENA|ETHFI|GALA|AGIX|FET|RNDR|GRT|SAND|MANA|AXS|OKB|1000SATS|USDC|FDUSD|USDT)(-?)(USD|USDT|USDC|FDUSD)?$/i.test(s)
  ) {
    return "binance";
  }
  if (s.includes("=") || /^[A-Z]{1,3}\d{2,4}$/.test(s)) return "futures";
  if (s.startsWith("^")) return "stock";
  if (/^\d{4,6}$/.test(s)) return "stock";
  if (/\.(US|HK|T|TW|KS|SH|SZ|BJ|KQ)$/.test(s)) return "stock";
  if (/^(US|HK|JP|KR|TW|CN):/.test(s)) return "stock";
  if (s.includes("-")) return "stock";
  return "stock";
}

/**
 * 规范化交易对名称：
 * - 去掉首尾空格、转大写
 * - 币安：去掉所有横线/斜杠（BTC-USDT → BTCUSDT）
 * - OKX：斜杠转横线，无横线时按计价币拆分（btc/usdt → BTC-USDT，ETHUSDT → ETH-USDT）
 * - Bybit：与币安相同，无分隔符（BTC-USDT → BTCUSDT）
 * - 股票（全球）：A股 6 位数字（sh600519 → 600519）；美股（us:AAPL / AAPL.US → us:AAPL）；
 *   港股（hk:00700 / 0700.HK → hk:00700）；日股（jp:7203.T / 7203 → jp:7203.T）；
 *   韩股（kr:005930.KS / 005930.KS → kr:005930.KS）；台股（tw:2330.TW / 2330.TW → tw:2330.TW）
 * @param {"binance"|"okx"|"bybit"|"stock"|"futures"} exchange
 * @param {string} raw
 * @returns {string}
 */
export function normalizeSymbol(exchange, raw) {
  let s = String(raw || "").trim().toUpperCase().replace(/\s+/g, "");
  // 中文币名 → 代码（比特币 → BTC），避免乱码发往行情接口
  const cn = CRYPTO_CN_ALIASES[s];
  if (cn) s = cn;
  if (exchange === "stock") {
    const market = detectStockMarket(s);
    const code = stripStockMarket(s, market);
    // 空壳防护：纯符号/数字输入剥不出代码时返回空，避免 "us:" 这种 truthy 空壳
    if (!code) return "";
    return market === "cn" ? code : `${market}:${code}`;
  }
  if (exchange === "futures") {
    // 支持 cn:/us: 显式前缀；无前缀时带 "=" 视为全球期货，否则视为国内期货
    s = s.replace(/^(CN|US):/, "");
    if (s.includes("=")) return s.replace(/[^A-Z0-9=]/g, "");
    return s.replace(/[^A-Z0-9]/g, "");
  }
  if (exchange === "okx") {
    s = s.replace(/[/_]/g, "-");
    if (!s.includes("-")) {
      for (const quote of OKX_QUOTES) {
        if (s.endsWith(quote) && s.length > quote.length) {
          s = s.slice(0, -quote.length) + "-" + quote;
          break;
        }
      }
    }
  } else {
    s = s.replace(/[-/_]/g, "");
  }
  // 加密交易所：纯币种代码自动补默认计价币（比特币 → BTC → BTCUSDT）
  if (["binance", "bybit", "okx"].includes(exchange)) {
    const quotes = exchange === "okx" ? OKX_QUOTES : ["USDT", "USDC", "FDUSD", "BUSD", "TUSD"];
    // 已带计价币（BTCUSDT）或纯计价币输入（USDT）不补；
    // 排除"币种自身"（ETH 以 ETH 结尾但不能算已带计价币）
    const PURE_QUOTES = ["USDT", "USDC", "FDUSD", "BUSD", "TUSD", "EUR", "TRY"];
    const hasQuote = quotes.some(
      (q) => (s === q && PURE_QUOTES.includes(q)) || (s.endsWith(q) && s.length > q.length),
    );
    if (!hasQuote && /^[A-Z0-9]{2,10}$/.test(s)) {
      s = exchange === "okx" ? `${s}-USDT` : `${s}USDT`;
    }
  }
  return s;
}

/**
 * 识别股票所属市场：
 * - 显式前缀 us:/hk:/jp:/kr:/tw:/cn:
 * - 后缀 .US/.HK/.T/.KS/.KQ
 * - hk 前缀（hk00700）、us 前缀（usAAPL）
 * - 6 位数字 → A股；0 开头 5 位 → 港股；4 位数字 → 日股；其它字母 → 美股
 * @param {string} raw
 * @returns {"cn"|"us"|"hk"|"jp"|"kr"|"tw"}
 */
export function detectStockMarket(raw) {
  const s = String(raw || "").trim().toUpperCase();
  const prefix = s.match(/^(US|HK|JP|KR|TW|CN):/);
  if (prefix) return prefix[1].toLowerCase();
  // Moomoo 等站点：AAPL-US / 00700-HK / 7203-JP / 005930-KS / 600519-SH
  if (/-(US|HK|JP|TW|KS|KQ)$/.test(s)) {
    const m = s.match(/-([A-Z]+)$/);
    const mk = m[1].toLowerCase();
    if (mk === "us") return "us";
    if (mk === "hk") return "hk";
    if (mk === "jp") return "jp";
    if (mk === "tw") return "tw";
    return "kr";
  }
  if (/-(SH|SZ|BJ)$/.test(s)) return "cn";
  if (/\.TW$/.test(s)) return "tw";
  if (/\.T$/.test(s)) return "jp";
  if (/\.(KS|KQ)$/.test(s)) return "kr";
  if (/\.HK$/.test(s)) return "hk";
  if (/\.US$/.test(s)) return "us";
  if (/^(SH|SZ|BJ)/.test(s) || /^\d{6}$/.test(s)) return "cn";
  if (/^HK\d+/.test(s) || /^0\d{4}$/.test(s)) return "hk";
  if (/^JP\d+/.test(s) || /^\d{4}$/.test(s)) return "jp";
  if (/^KR\d+/.test(s)) return "kr";
  if (/^TW\d+/.test(s)) return "tw";
  return "us";
}

/**
 * 去掉市场前缀/后缀，返回纯代码（保持 A股 6 位、美股大写、港股 5 位补零、日股 4 位 + .T、韩股 6 位 + .KS、台股 4 位 + .TW）
 * @param {string} raw
 * @param {"cn"|"us"|"hk"|"jp"|"kr"|"tw"} market
 * @returns {string}
 */
export function stripStockMarket(raw, market) {
  let s = String(raw || "").trim().toUpperCase().replace(/\s+/g, "");
  s = s.replace(/^(US|HK|JP|KR|TW|CN):/, "");
  s = s.replace(/\.(US|HK|T|TW|KS|KQ)$/, "");
  s = s.replace(/-(US|HK|JP|TW|KS|KQ)$/, "");
  s = s.replace(/-(SH|SZ|BJ)$/, "");
  if (market === "cn") {
    s = s.replace(/^(SH|SZ|BJ)/, "");
    const m = s.match(/\d{6}/);
    return m ? m[0] : s;
  }
  s = s.replace(/^(HK|US|JP|KR)(?=\d)/, "");
  if (market === "us") {
    // 指数（^GSPC / ^N225 / ^KS11）允许数字，普通美股代码只保留字母与 - .
    return s.startsWith("^") ? s.replace(/[^A-Z0-9.^-]/g, "") : s.replace(/[^A-Z.-]/g, "");
  }
  const digits = s.replace(/\D/g, "");
  if (market === "hk") return digits ? digits.padStart(5, "0") : s;
  if (market === "jp") return digits ? `${digits}.T` : s;
  if (market === "kr") return digits ? `${digits}.KS` : s;
  if (market === "tw") return digits ? `${digits}.TW` : s;
  return digits;
}

/**
 * 把规范化的股票符号（可带 us:/hk:/jp:/kr:/cn: 前缀）拆成市场 + 代码
 * @param {string} symbol
 * @returns {{market: "cn"|"us"|"hk"|"jp"|"kr"|"tw", code: string}}
 */
export function parseStockSymbol(symbol) {
  const s = String(symbol || "").trim();
  const m = s.match(/^(US|HK|JP|KR|TW|CN):(.+)$/i);
  if (m) {
    const market = m[1].toLowerCase();
    return { market, code: stripStockMarket(m[2], market) };
  }
  const market = detectStockMarket(s);
  return { market, code: stripStockMarket(s, market) };
}

/**
 * 把规范化的期货符号拆成市场 + 代码：
 * - 带 "=" 的代码（ES=F / CL=F / 6E=F）视为全球期货
 * - 其余（RB2510 / AU0 / IF2509）视为国内期货
 * @param {string} symbol
 * @returns {{market: "cn"|"us", code: string}}
 */
export function parseFuturesSymbol(symbol) {
  const s = String(symbol || "")
    .trim()
    .toUpperCase()
    .replace(/\s+/g, "")
    .replace(/^(CN|US):/, "");
  if (s.includes("=")) {
    return { market: "us", code: s.replace(/[^A-Z0-9=]/g, "") };
  }
  return { market: "cn", code: s.replace(/[^A-Z0-9]/g, "") };
}
