// @ts-check
import { LANG } from "./i18n.js";
import { PATTERN_EN, STRATEGY_EN } from "./content-en.js";
import { PATTERN_JA, STRATEGY_JA } from "./content-ja.js";
import { PATTERN_KO, STRATEGY_KO } from "./content-ko.js";

const PATTERN_MAPS = { en: PATTERN_EN, ja: PATTERN_JA, ko: PATTERN_KO };
const STRATEGY_MAPS = { en: STRATEGY_EN, ja: STRATEGY_JA, ko: STRATEGY_KO };

/** 形态字段本地化：英文取词典，缺省回退中文原文 */
export function patternField(p, field, lang = LANG) {
  if (!p) return "";
  const m = PATTERN_MAPS[lang];
  if (m && m[p.id] && m[p.id][field]) {
    return m[p.id][field];
  }
  return p[field] || "";
}

/** 策略字段本地化：英文取词典，缺省回退中文原文 */
export function strategyField(s, field, lang = LANG) {
  if (!s) return "";
  const m = STRATEGY_MAPS[lang];
  if (m && m[s.id] && m[s.id][field]) {
    return m[s.id][field];
  }
  return s[field] || "";
}
