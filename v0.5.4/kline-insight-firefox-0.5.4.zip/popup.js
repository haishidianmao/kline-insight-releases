// 弹窗：点击按钮在用户操作上下文中打开侧边栏（Chrome / Firefox 通用）
import { initI18n, t } from "./i18n.js";

const api = typeof browser !== "undefined" && browser.runtime ? browser : chrome;
const btn = document.getElementById("open-sidebar");
const statusEl = document.getElementById("popup-status");

initI18n();

btn.addEventListener("click", async () => {
  try {
    if (api.sidebarAction && api.sidebarAction.open) {
      // Firefox
      await api.sidebarAction.open();
      statusEl.textContent = t("popup_opened");
      window.close();
    } else if (api.sidePanel && api.sidePanel.open) {
      // Chrome
      const win = await api.windows.getCurrent();
      await api.sidePanel.open({
        windowId: win ? win.id : api.windows.WINDOW_ID_CURRENT,
      });
      statusEl.textContent = t("popup_opened");
      window.close();
    } else {
      statusEl.textContent = t("popup_unsupported");
    }
  } catch (err) {
    statusEl.textContent = t("popup_open_failed", { msg: err && err.message ? err.message : String(err) });
    statusEl.className = "popup-status error";
  }
});
