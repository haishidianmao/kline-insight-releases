// @ts-check
/**
 * 形态与策略库的英文内容词典（Phase 2 内容翻译）。
 * 界面在非中文语言下优先取这里的内容，缺省回退中文原文。
 * 日文/韩文内容词典随后补充（content-ja.js / content-ko.js）。
 */

export const PATTERN_EN = {
  "s-hammer": {
    summary: "A hammer at the bottom of a downtrend: a long lower shadow suggests buyers are stepping in and price may stop falling.",
    description:
      "A small body with a very long lower shadow (at least twice the body). After a downtrend, it shows price was pushed down hard during the session but bought back at the close, a sign of weakening sellers.",
    rules:
      "Lower shadow ≥ 55% of the full range; body ≤ 35% of the range; upper shadow ≤ 15%; body clearly above zero (distinct from a doji); must follow a downtrend.",
    notes:
      "A hammer and a hanging man have the same shape; only location matters: bottom = hammer (bullish), top = hanging man (bearish). A single hammer is a weak signal; wait for a bullish close the next day.",
  },
  "s-inverted-hammer": {
    summary: "An inverted hammer at a downtrend bottom: a long upper shadow shows buyers tried to push up; selling pressure is fading.",
    description:
      "A small body with a very long upper shadow. At a downtrend bottom it shows an intraday rally attempt; although the close fell back, sellers could no longer press price far below the open.",
    rules: "Upper shadow ≥ 55% of range; body ≤ 35%; lower shadow ≤ 15%; must follow a downtrend.",
    notes: "Same shape as a shooting star; bottom = bullish inverted hammer, top = bearish shooting star. Needs a bullish close next day; medium reliability.",
  },
  "s-hanging-man": {
    summary: "A hanging man at a rally top: the long lower shadow reveals heavy intraday selling; despite the recovery, topping risk rises.",
    description:
      "A small body with a very long lower shadow. After an uptrend it shows violent intraday selling that was bought back at the close—an early warning that upside momentum is fading.",
    rules: "Lower shadow ≥ 55% of range; body ≤ 35%; upper shadow ≤ 15%; must follow an uptrend.",
    notes: "Same shape as a hammer but at the top, with the opposite meaning. It is only a warning; a bearish close or gap down the next day makes it stronger.",
  },
  "s-shooting-star": {
    summary: "A shooting star at a rally top: long upper shadow, tiny body; price surged then collapsed, heavy overhead supply.",
    description:
      "A small body with a very long upper shadow. After an uptrend, price spiked up but was pushed back to the open at the close, signaling exhausted upside.",
    rules: "Upper shadow ≥ 55% of range; body ≤ 35%; lower shadow ≤ 15%; must follow an uptrend.",
    notes: "The closer to the end of a rally and the longer the upper shadow, the more reliable. A gap down or bearish close next day raises the topping probability.",
  },
  "s-doji": {
    summary: "A doji: open and close are nearly identical; bulls and bears are temporarily balanced and the market is indecisive.",
    description:
      "Open and close nearly coincide, leaving a tiny body. A doji reflects a fierce tug-of-war ending in a draw. After a strong run it often warns of a turn; in a range it means little.",
    rules: "Body ≤ 10% of the full range; upper and lower shadows each ≤ 50% of the range.",
    notes: "A doji alone is not a signal; location matters—high doji warns of a top, low doji may mark a bottom, and rising volume strengthens it.",
  },
  "s-long-legged-doji": {
    summary: "A long-legged doji: both shadows are long, a violent tug-of-war with no direction, often at turning points.",
    description:
      "Nearly no body and long shadows on both sides. Price swung sharply up and down in one session; disagreement is extreme. At the end of a trend it often signals the trend is losing power.",
    rules: "Body ≤ 10% of range; each shadow ≥ 30% of the range.",
    notes: "Meaningful at tops or bottoms; in the middle of a trend it is usually just consolidation.",
  },
  "s-dragonfly-doji": {
    summary: "A dragonfly doji: long lower shadow, no upper shadow; a sharp intraday drop was fully recovered—bullish at bottoms.",
    description:
      "Open, close and high nearly coincide, with only a long lower shadow. Price was hammered down then fully bought back; buyers fought back hard. At the end of a decline it leans bullish.",
    rules: "Body ≤ 10% of range; lower shadow ≥ 60%; upper shadow ≤ 10%.",
    notes: "At a top the meaning reverses; judge by location. It carries a stronger bullish intent than a plain doji.",
  },
  "s-gravestone-doji": {
    summary: "A gravestone doji: long upper shadow, no lower shadow; an intraday surge was fully given back—bearish at tops.",
    description:
      "Open, close and low nearly coincide, with only a long upper shadow. Price rallied hard but closed back where it started; overhead supply is heavy. At the end of an advance it leans bearish.",
    rules: "Body ≤ 10% of range; upper shadow ≥ 60%; lower shadow ≤ 10%.",
    notes: "At a bottom the meaning reverses; it carries a stronger bearish intent than a plain doji.",
  },
  "s-four-price-doji": {
    summary: "Four-price doji: open, high, low and close are almost identical; activity is minimal and the market is fully stalled.",
    description:
      "All four prices nearly coincide with a tiny range. Usually seen in extremely quiet sessions or news vacuums; traders are in a wait-and-see mood.",
    rules: "Range ≤ 30% of the recent average range; body ≤ 10% of the range.",
    notes: "No directional meaning by itself. Watch for a sudden volume spike afterward—volume may decide the next direction.",
  },
  "s-spinning-top": {
    summary: "A spinning top: small body with symmetric shadows; bulls and bears are deadlocked and the market hesitates.",
    description:
      "A small body with shadows on both sides, shaped like a spinning top. Both sides acted but neither prevailed. At the end of a trend it often hints that momentum is fading.",
    rules: "Body 15%–45% of range; each shadow ≥ 15% of the range.",
    notes: "Alone it has limited meaning; it is usually a component of patterns such as harami or star patterns.",
  },
  "s-white-marubozu": {
    summary: "White marubozu: open at the low, close at the high; bulls controlled the entire session—strong momentum.",
    description:
      "A bullish candle with almost no shadows: open equals the low and close equals the high. Buying persisted from open to close with almost no seller resistance.",
    rules: "Bullish candle; body ≥ 95% of the range.",
    notes: "During an advance it confirms strength; after a long decline at low levels it can mark a reversal start.",
  },
  "s-black-marubozu": {
    summary: "Black marubozu: open at the high, close at the low; bears controlled the session—strong downside momentum.",
    description:
      "A bearish candle with almost no shadows: open equals the high and close equals the low. Selling persisted from open to close with almost no buyer resistance.",
    rules: "Bearish candle; body ≥ 95% of the range.",
    notes: "During a decline it confirms strength; at high levels it may mark the start of a reversal; judge by location.",
  },
  "s-white-opening-marubozu": {
    summary: "White opening marubozu: opens at the low but closes below the high; bulls strong at the open but met selling intraday.",
    description:
      "A bullish candle whose open is the low (no lower shadow), but the close is below the high (upper shadow remains). Buyers dominated early, then met some supply.",
    rules: "Bullish; body ≥ 60% of range; lower shadow ≤ 5%; upper shadow ≥ 20%.",
    notes: "A strong-but-mixed candle; the longer the upper shadow, the more overhead supply to watch.",
  },
  "s-white-closing-marubozu": {
    summary: "White closing marubozu: closes at the high; late buyers pushed price to the top—bulls dominate the close.",
    description:
      "A bullish candle whose close is the high (no upper shadow), but the open is above the low (lower shadow remains). Late-session buying drove price to its best level; bullish follow-through is likely.",
    rules: "Bullish; body ≥ 60% of range; upper shadow ≤ 5%; lower shadow ≥ 20%.",
    notes: "A strong close is a positive sign; with rising volume, short-term momentum is stronger.",
  },
  "s-black-opening-marubozu": {
    summary: "Black opening marubozu: opens at the high but closes above the low; bears pressed early but found buying later.",
    description:
      "A bearish candle whose open is the high (no upper shadow), but the close is above the low (lower shadow remains). Sellers dominated at the open, then buyers absorbed the dip.",
    rules: "Bearish; body ≥ 60% of range; upper shadow ≤ 5%; lower shadow ≥ 20%.",
    notes: "A weak candle, but a longer lower shadow means stronger dip-buying; confirm with the next session.",
  },
  "s-black-closing-marubozu": {
    summary: "Black closing marubozu: closes at the low; late selling is heavy—bears dominate.",
    description:
      "A bearish candle whose close is the low (no lower shadow), but the open is below the high (upper shadow remains). Sellers pressed through the close to finish at the day's worst level—clearly weak.",
    rules: "Bearish; body ≥ 60% of range; lower shadow ≤ 5%; upper shadow ≥ 20%.",
    notes: "A weak close is a bearish sign; a high-volume decline adds momentum.",
  },
  "s-long-white": {
    summary: "A long white candle: the body is much larger than recent average—strong buying and solid bullish momentum.",
    description:
      "A bullish candle with a body far above the recent average (roughly 1.5× or more). Buying power far exceeded recent norms; the bias is bullish.",
    rules: "Bullish; body ≥ 60% of range; body ≥ 1.5× the recent average body; not a marubozu (avoid double reporting).",
    notes: "Strong on the day; after a steep rally, a long white candle can also warn of overheating and a pullback.",
  },
  "s-long-black": {
    summary: "A long black candle: the body is much larger than recent average—heavy selling and solid bearish momentum.",
    description:
      "A bearish candle with a body far above the recent average (roughly 1.5× or more). Selling power far exceeded recent norms; the bias is bearish.",
    rules: "Bearish; body ≥ 60% of range; body ≥ 1.5× the recent average body; not a marubozu.",
    notes: "Weak on the day; after a steep decline, a long black candle can also mean panic is nearing exhaustion.",
  },
  "s-short-white": {
    summary: "A short white candle: a small body, buyers slightly ahead; momentum is modest.",
    description:
      "A bullish candle with a body well below the recent average. Buyers were only slightly ahead; trend persistence is unconfirmed.",
    rules: "Bullish; body 12%–35% of range; body ≤ 80% of the recent average body.",
    notes: "During a decline it can mean a weak bounce; near the end of a base it can mean accumulation.",
  },
  "s-short-black": {
    summary: "A short black candle: a small body, sellers slightly ahead; momentum is modest.",
    description:
      "A bearish candle with a body well below the recent average. Sellers were only slightly ahead; trend persistence is unconfirmed.",
    rules: "Bearish; body 12%–35% of range; body ≤ 80% of the recent average body.",
    notes: "During an advance it can be a brief pause; at a top it can be the first sign of weakness.",
  },
  "s-high-wave": {
    summary: "A high-wave candle: long shadows on both sides with a tiny body—violent disagreement and unstable sentiment.",
    description:
      "A tiny body with very long shadows; price swung wildly within one session. Disagreement is extreme and direction unclear; near the end of a trend it often signals an approaching turn.",
    rules: "Body ≤ 20% of range; each shadow ≥ 35% of the range.",
    notes: "Only a breakout candle afterward gives direction; before that, avoid conclusions.",
  },
  "s-bullish-belt-hold": {
    summary: "Bullish belt hold: opens near the low and closes high with a full body; decisive buying after a decline—a strengthening signal.",
    description:
      "The open is at (or near) the low, then price rose in one direction to close with a full-bodied bullish candle and no lower shadow. Buyers controlled the session from the open.",
    rules: "Bullish; body ≥ 60% of range; lower shadow ≤ 5%; upper shadow ≤ 25%; must follow a downtrend.",
    notes: "Strongest on the first occurrence in a downtrend; weakens if the next session fails to close bullish.",
  },
  "s-bearish-belt-hold": {
    summary: "Bearish belt hold: opens near the high and closes low with a full body; decisive selling after a rally—a weakening signal.",
    description:
      "The open is at (or near) the high, then price fell in one direction to close with a full-bodied bearish candle and no upper shadow. Sellers controlled the session from the open.",
    rules: "Bearish; body ≥ 60% of range; upper shadow ≤ 5%; lower shadow ≤ 25%; must follow an uptrend.",
    notes: "Strongest on the first occurrence at the end of an uptrend; a bearish close next day makes it stronger.",
  },
  "d-bullish-engulfing": {
    summary: "Bullish engulfing: a bullish body completely engulfs the prior bearish body—strong counterattack, high bottom-reversal odds.",
    description:
      "In a downtrend a bearish candle is followed by a larger bullish candle whose open is at/below the prior close and close above the prior open, fully swallowing the prior body. Bulls have overwhelmed bears.",
    rules:
      "Must follow a downtrend; prior candle bearish, second bullish; bullish body fully covers the bearish body (lower open, higher close); bullish body clearly larger.",
    notes: "One of the more reliable reversal patterns. The lower the location, the larger the body, and the higher the volume, the stronger the signal.",
  },
  "d-bearish-engulfing": {
    summary: "Bearish engulfing: a bearish body completely engulfs the prior bullish body—strong counterattack, high top-reversal odds.",
    description:
      "In an uptrend a bullish candle is followed by a larger bearish candle whose open is at/above the prior close and close below the prior open, fully swallowing the prior body. Bears have overwhelmed bulls.",
    rules:
      "Must follow an uptrend; prior candle bullish, second bearish; bearish body fully covers the bullish body (higher open, lower close); bearish body clearly larger.",
    notes: "The higher the location, the larger the body, and the higher the volume, the stronger the signal. Especially worth caution in high-level stalls.",
  },
  "d-bullish-harami": {
    summary: "Bullish harami: a small bullish candle sits entirely inside the prior large bearish candle—seller momentum is fading; the decline may stop.",
    description:
      "In a downtrend a large bearish candle is followed by a much smaller bullish candle fully inside its body (like a fetus in the womb). Selling pressure is clearly weakening.",
    rules:
      "Must follow a downtrend; prior candle a large bearish, second bullish; second body fully inside the first and at least ~1.2× smaller.",
    notes: "A milder reversal signal than engulfing; usually needs a third candle to confirm direction.",
  },
  "d-bearish-harami": {
    summary: "Bearish harami: a small bearish candle sits entirely inside the prior large bullish candle—buyer momentum is fading; the rally may stall.",
    description:
      "In an uptrend a large bullish candle is followed by a much smaller bearish candle fully inside its body. Buying power is clearly weakening and chasing interest fades.",
    rules:
      "Must follow an uptrend; prior candle a large bullish, second bearish; second body fully inside the first and clearly smaller.",
    notes: "After a sustained rally it often marks the late stage; a bearish close next day raises the weakening odds.",
  },
  "d-bullish-harami-cross": {
    summary: "Bullish harami cross: a doji sits inside a large bearish candle—violent turnover; bottom-reversal odds are high.",
    description:
      "In a downtrend a large bearish candle is followed by a doji fully inside its body. A stronger indecision/turnover signal than a plain harami, often found at important bottoms.",
    rules: "Must follow a downtrend; prior candle a large bearish; second is a doji inside the prior body.",
    notes: "Stronger reversal implication than a plain harami, but still wait for a third candle to confirm.",
  },
  "d-bearish-harami-cross": {
    summary: "Bearish harami cross: a doji sits inside a large bullish candle—violent turnover; top-reversal odds are high.",
    description:
      "In an uptrend a large bullish candle is followed by a doji fully inside its body. Upside momentum suddenly stalls with heavy turnover; often found at important tops.",
    rules: "Must follow an uptrend; prior candle a large bullish; second is a doji inside the prior body.",
    notes: "Especially caution after a sharp rally; a classic top warning.",
  },
  "d-piercing-line": {
    summary: "Piercing line: after a bearish candle, price gaps down then closes deep inside the prior body—a clear buyer counterattack.",
    description:
      "In a downtrend a bearish candle is followed by a gap-down open; price then rebounds strongly to close above the midpoint of the prior body but below its open. Sellers were overwhelmed after pressing price down.",
    rules:
      "Must follow a downtrend; prior bearish, second bullish; second open no higher than the prior low; close above the prior body's midpoint but below its open.",
    notes: "Mirror image of dark cloud cover. The deeper the penetration (near the prior open), the stronger; if the close is only near the midpoint, the signal weakens.",
  },
  "d-dark-cloud-cover": {
    summary: "Dark cloud cover: after a bullish candle, price gaps up then closes deep inside the prior body—a clear seller counterattack.",
    description:
      "In an uptrend a bullish candle is followed by a gap-up open; price then collapses to close below the midpoint of the prior body but above its open. Buyers were overwhelmed after pushing price up.",
    rules:
      "Must follow an uptrend; prior bullish, second bearish; second open no lower than the prior high; close below the prior body's midpoint but above its open.",
    notes: "A classic top reversal. The deeper the bearish body penetrates the prior bullish body, the stronger.",
  },
  "d-bullish-tweezers": {
    summary: "Bullish tweezers bottom: two candles with nearly identical lows—buyers defended the same price twice, forming support.",
    description:
      "In a downtrend, two consecutive candles (usually bearish then bullish) share almost the same low, clamping the bottom like tweezers. Sellers probed twice and were absorbed at the same level.",
    rules: "Must follow a downtrend; the two lows differ by ≤ 0.3%; prior bearish and second bullish.",
    notes: "Support is meaningful, especially if the level is also a prior low or a round number.",
  },
  "d-bearish-tweezers": {
    summary: "Bearish tweezers top: two candles with nearly identical highs—sellers capped the same price twice, forming resistance.",
    description:
      "In an uptrend, two consecutive candles (usually bullish then bearish) share almost the same high. Buyers pushed twice and were rejected at the same level.",
    rules: "Must follow an uptrend; the two highs differ by ≤ 0.3%; prior bullish and second bearish.",
    notes: "Resistance is meaningful, especially at a prior high or a round number; stay cautious below it.",
  },
  "d-bullish-meeting-lines": {
    summary: "Bullish meeting lines: after a bearish candle, a bullish candle closes at the same price—sellers' push was fully recovered.",
    description:
      "In a downtrend a bearish candle is followed by a bullish candle with almost the same close. Sellers pressed price to a level and buyers immediately pulled it back—the decline met effective resistance.",
    rules: "Must follow a downtrend; prior bearish, second bullish; the two closes differ by ≤ 0.2%.",
    notes: "A mild reversal signal; another bullish close next day raises the odds.",
  },
  "d-bearish-meeting-lines": {
    summary: "Bearish meeting lines: after a bullish candle, a bearish candle closes at the same price—buyers' push was fully rejected.",
    description:
      "In an uptrend a bullish candle is followed by a bearish candle with almost the same close. Buyers pushed price to a level and sellers immediately pressed it back—the rally met effective supply.",
    rules: "Must follow an uptrend; prior bullish, second bearish; the two closes differ by ≤ 0.2%.",
    notes: "Another bearish close next day raises the weakening odds.",
  },
  "d-bullish-separating-lines": {
    summary: "Bullish separating lines: in an uptrend a bearish candle is followed by a bullish candle opening at the same price—the pullback ended.",
    description:
      "In an uptrend a bearish candle (pullback) is followed by a bullish candle with the same open. The identical open shows turnover at one level, while the strong bullish close means the trend resumes.",
    rules: "Must follow an uptrend; prior bearish, second bullish; the two opens differ by ≤ 0.2%.",
    notes: "A continuation pattern; the trend is intact until price breaks the prior open.",
  },
  "d-bearish-separating-lines": {
    summary: "Bearish separating lines: in a downtrend a bullish candle is followed by a bearish candle opening at the same price—the bounce ended.",
    description:
      "In a downtrend a bullish candle (bounce) is followed by a bearish candle with the same open. The identical open shows turnover at one level, while the strong bearish close means the decline resumes.",
    rules: "Must follow a downtrend; prior bullish, second bearish; the two opens differ by ≤ 0.2%.",
    notes: "A continuation pattern; the decline is intact until price breaks above the prior open.",
  },
  "d-bullish-kicking": {
    summary: "Bullish kicking: a black marubozu is followed by a gap-up white marubozu—a violent reversal of a bearish trend.",
    description:
      "A full-bodied black marubozu (extreme selling) is followed by a gap-up full-bodied white marubozu, with a clear gap between them. Extreme bears were suddenly overwhelmed by extreme bulls—a violent reversal.",
    rules:
      "Prior candle a black marubozu; second a white marubozu; second open above the prior high (gap up); both bodies ≥ 90% of their ranges.",
    notes: "Rare and usually accompanies major news or capital flows. Strong but do not chase; watch for gap-fill risk.",
  },
  "d-bearish-kicking": {
    summary: "Bearish kicking: a white marubozu is followed by a gap-down black marubozu—a violent reversal of a bullish trend.",
    description:
      "A full-bodied white marubozu (extreme buying) is followed by a gap-down full-bodied black marubozu, with a clear gap between them. Extreme bulls were suddenly overwhelmed by extreme bears—a violent reversal.",
    rules:
      "Prior candle a white marubozu; second a black marubozu; second open below the prior low (gap down); both bodies ≥ 90% of their ranges.",
    notes: "Rare but strong; do not blindly chase shorts; watch gap-fill risk.",
  },
  "d-homing-pigeon": {
    summary: "Homing pigeon: a second bearish body nests inside the first—seller momentum is fading; the decline may stop.",
    description:
      "In a downtrend a large bearish candle is followed by a much smaller bearish candle fully inside its body (both bearish). Sellers still pressed but with clearly reduced force; the decline may be near its end.",
    rules:
      "Must follow a downtrend; both bearish; second body fully inside the first and at least ~1.2× smaller.",
    notes: "Weaker than a bullish harami because the second candle is still bearish; needs a subsequent bullish close.",
  },
  "d-matching-low": {
    summary: "Matching low: two bearish candles close at the same low level—the level held for two days, support appears.",
    description:
      "In a downtrend two consecutive bearish candles close at almost the same price, near their lows. Sellers pushed to the same low twice but could not go further—buyers absorbed the supply.",
    rules: "Must follow a downtrend; both bearish; the two closes differ by ≤ 0.2%.",
    notes: "Two bearish closes side by side at the low means sellers temporarily cannot make new lows; a potential bottom that still needs a bullish confirmation.",
  },
  "d-matching-high": {
    summary: "Matching high: two bullish candles close at the same high level—the level resisted two days, pressure appears.",
    description:
      "In an uptrend two consecutive bullish candles close at almost the same price, near their highs. Buyers pushed to the same high twice but could not break through—supply appeared.",
    rules: "Must follow an uptrend; both bullish; the two closes differ by ≤ 0.2%.",
    notes: "Two bullish closes side by side at the high means buyers temporarily cannot make new highs; a potential top that still needs a bearish confirmation.",
  },
  "t-morning-star": {
    summary: "Morning star: long bearish, small body, long bullish—sellers exhaust, buyers take over; a classic bottom reversal.",
    description:
      "Three candles in a downtrend: a long bearish candle (sellers in control), a small-bodied candle (doji or spinning top) near/below the prior close showing exhaustion, then a long bullish candle closing above the midpoint of the first body—buyers reclaim control.",
    rules:
      "Must follow a downtrend; first a long bearish (body ≥ 50% of range); second body ≤ 35% of range; third bullish closing above the first body's midpoint.",
    notes: "A highly reliable bottom reversal. The bigger the gap around the second candle and the longer the third, the stronger.",
  },
  "t-evening-star": {
    summary: "Evening star: long bullish, small body, long bearish—buyers exhaust, sellers take over; a classic top reversal.",
    description:
      "Three candles in an uptrend: a long bullish candle, a small-bodied candle near/above the prior close showing exhaustion, then a long bearish candle closing below the midpoint of the first body—sellers reclaim control.",
    rules:
      "Must follow an uptrend; first a long bullish (body ≥ 50% of range); second body ≤ 35% of range; third bearish closing below the first body's midpoint.",
    notes: "A highly reliable top reversal. The longer the third candle and the higher the location, the stronger.",
  },
  "t-morning-doji-star": {
    summary: "Morning doji star: a long bearish candle, a gap-down doji, then a long bullish candle—a stronger bottom signal than a plain morning star.",
    description:
      "Like a morning star, but the middle candle is a doji. In a downtrend price falls hard, gaps down into a doji (a draw), then a long bullish candle reclaims the loss. The doji shows sellers can no longer advance.",
    rules:
      "Must follow a downtrend; first a long bearish; second a doji closing below the first close; third bullish closing above the first body's midpoint.",
    notes: "Considered a stronger bottom signal than a plain morning star.",
  },
  "t-evening-doji-star": {
    summary: "Evening doji star: a long bullish candle, a gap-up doji, then a long bearish candle—a stronger top signal than a plain evening star.",
    description:
      "Like an evening star, but the middle candle is a doji. In an uptrend price rallies hard, gaps up into a doji (a draw), then a long bearish candle sells off. The doji shows buyers can no longer advance.",
    rules:
      "Must follow an uptrend; first a long bullish; second a doji closing above the first close; third bearish closing below the first body's midpoint.",
    notes: "Considered a stronger top signal than a plain evening star.",
  },
  "t-abandoned-baby-bullish": {
    summary: "Bullish abandoned baby: a doji isolated by gaps on both sides—complete turnover; a rare, strong bottom signal.",
    description:
      "In a downtrend: a long bearish candle, then a gap-down doji (gap from the prior candle), then a gap-up bullish candle (gap from the doji). The isolated doji, like an abandoned baby, means selling is fully exhausted and turnover is complete.",
    rules:
      "Must follow a downtrend; first a long bearish; second a doji whose high is below the first low; third bullish whose low is above the second high.",
    notes: "Very rare, but highly reliable when both gaps remain unfilled.",
  },
  "t-abandoned-baby-bearish": {
    summary: "Bearish abandoned baby: a doji isolated by gaps on both sides—complete turnover; a rare, strong top signal.",
    description:
      "In an uptrend: a long bullish candle, then a gap-up doji, then a gap-down bearish candle. The isolated doji means buying is fully exhausted and turnover is complete.",
    rules:
      "Must follow an uptrend; first a long bullish; second a doji whose low is above the first high; third bearish whose high is below the second low.",
    notes: "Rare but reliable; the topping implication is strongest when both gaps remain unfilled.",
  },
  "t-three-white-soldiers": {
    summary: "Three white soldiers: three bullish candles march higher, each closing near its high—sustained buying; a strong uptrend.",
    description:
      "Three consecutive bullish candles, each closing above the prior and opening within the prior body (not gapping too high), closing near the session high. Buyers advance steadily—a healthy uptrend.",
    rules:
      "All three bullish; each close above the prior close; the last two open within the prior body; closes near the highs.",
    notes: "Most effective early in an advance or after breaking a key level; after many days of gains, beware short-term overheating.",
  },
  "t-three-black-crows": {
    summary: "Three black crows: three bearish candles march lower, each closing near its low—sustained selling; a strong downtrend.",
    description:
      "Three consecutive bearish candles, each closing below the prior and opening within the prior body, closing near the session low. Sellers advance steadily—a healthy downtrend.",
    rules:
      "All three bearish; each close below the prior close; the last two open within the prior body; closes near the lows.",
    notes: "Most effective early in a decline or after breaking a key level; after many days of losses, beware short-term oversold.",
  },
  "t-three-inside-up": {
    summary: "Three inside up: a large bearish candle, a harami that stops the slide, then a bullish close above the first open—a confirmed bottom.",
    description:
      "In a downtrend: a large bearish candle, a bullish candle inside its body (bullish harami), then a third bullish candle closing above the first open. The harami confirms exhaustion; the third confirms the reversal.",
    rules:
      "Must follow a downtrend; first a large bearish; second bullish with body inside the first; third bullish closing above the first open.",
    notes: "An enhanced harami; the third close determines the signal strength.",
  },
  "t-three-inside-down": {
    summary: "Three inside down: a large bullish candle, a harami that stalls the rally, then a bearish close below the first open—a confirmed top.",
    description:
      "In an uptrend: a large bullish candle, a bearish candle inside its body (bearish harami), then a third bearish candle closing below the first open. The harami confirms exhaustion; the third confirms the reversal.",
    rules:
      "Must follow an uptrend; first a large bullish; second bearish with body inside the first; third bearish closing below the first open.",
    notes: "An enhanced harami; the third close determines the signal strength.",
  },
  "t-three-outside-up": {
    summary: "Three outside up: an engulfing starts the reversal and a third bullish close makes a new high—a confirmed bottom.",
    description:
      "In a downtrend: a bearish candle, a bullish candle fully engulfing it (bullish engulfing), then a third bullish candle closing above the second—the reversal continues.",
    rules: "Must follow a downtrend; second bullish engulfs the first; third closes above the second close.",
    notes: "An enhanced engulfing; the three candles flow in one move, giving high reliability.",
  },
  "t-three-outside-down": {
    summary: "Three outside down: an engulfing starts the reversal and a third bearish close makes a new low—a confirmed top.",
    description:
      "In an uptrend: a bullish candle, a bearish candle fully engulfing it (bearish engulfing), then a third bearish candle closing below the second—the reversal continues.",
    rules: "Must follow an uptrend; second bearish engulfs the first; third closes below the second close.",
    notes: "An enhanced engulfing with high reliability.",
  },
  "t-advance-block": {
    summary: "Advance block: three bullish candles with shrinking bodies and longer upper shadows—buyers are losing steam; watch for a top.",
    description:
      "In an uptrend, three bullish candles whose bodies shrink in turn, with clearly longer upper shadows on the last (or last two). Buyers still push price higher but with fading force and growing overhead supply.",
    rules:
      "Must follow an uptrend; all three bullish; the last two close higher than the prior; the third body clearly smaller than the first (≤ ~0.8×); the third upper shadow longer than its body.",
    notes: "A warning, not a confirmation; a bearish candle afterward raises the topping odds.",
  },
  "t-deliberation": {
    summary: "Deliberation: after two long bullish candles, a gap-up small body shows buyers stalled—the rally pauses.",
    description:
      "In an uptrend, two full-bodied bullish candles are followed by a gap-up small-bodied candle (doji or spinning top). Buyers suddenly lose steam and hesitate at the high—a pause before a possible top.",
    rules:
      "Must follow an uptrend; first two bullish with bodies ≥ 50% of range; third body ≤ 35% of range and open not below the second close.",
    notes: "A pause by itself; a bearish close breaking the small candle's low confirms weakness.",
  },
  "t-tri-star-bullish": {
    summary: "Bullish tri-star: three dojis at the low with a gap between the first two—after a deadlock, selling is exhausted; a bottom may form.",
    description:
      "In a downtrend, three dojis appear, with a downward gap between the first two. Repeated dojis show a tug-of-war, and the gap-down doji means sellers could no longer push lower—a bottom stalemate may turn.",
    rules: "Must follow a downtrend; all three dojis; the second high below the first low (gap down).",
    notes: "Very rare. Three dojis can still resolve lower; wait for a bullish close to confirm.",
  },
  "t-tri-star-bearish": {
    summary: "Bearish tri-star: three dojis at the high with a gap between the first two—after a deadlock, buying is exhausted; a top may form.",
    description:
      "In an uptrend, three dojis appear, with an upward gap between the first two. Repeated dojis show a tug-of-war, and the gap-up doji means buyers could no longer push higher—a top stalemate may turn.",
    rules: "Must follow an uptrend; all three dojis; the second low above the first high (gap up).",
    notes: "Very rare; wait for a bearish close to confirm a top.",
  },
  "t-upside-gap-two-crows": {
    summary: "Upside gap two crows: after a gap up, two bearish candles drift lower—heavy supply at the gap; watch for a top.",
    description:
      "In an uptrend, a bullish candle is followed by a gap-up bearish candle (still closing above the first bullish close), then a second bearish candle opening above and closing below the prior—yet both remain above the gap. The two crows press down, showing heavy supply at the gap.",
    rules:
      "Must follow an uptrend; first bullish; second bearish opening above the first close (gap); third bearish opening above and closing below the second; third close above the first close.",
    notes: "If the pullback eventually fills the gap, the bearish signal strengthens.",
  },
  "t-two-crows": {
    summary: "Two crows: after a bullish candle, two bearish candles gap up then fall back—buyers failed; watch for weakness.",
    description:
      "In an uptrend, a bullish candle is followed by a bearish candle that gaps up but closes inside the prior body, then a third bearish candle opening inside the second and closing lower (still above the first open). The two crows press down step by step.",
    rules:
      "Must follow an uptrend; first bullish; second bearish opening above the first close and closing inside the first body; third opening above the second close and below the second open, closing below the second close but above the first open.",
    notes: "A mild top warning; if the third closes below the first open, the signal strengthens.",
  },
  "t-unique-three-river-bottom": {
    summary: "Unique three river bottom: a long bearish, a long-lower-shadow bearish, then a small bullish—support strengthens step by step.",
    description:
      "In a downtrend: a long bearish candle; a second bearish that makes a new low but closes above the first close with a clear lower shadow (dip buying); then a small bullish candle closing above the second and in the upper part of its range. Selling fades while buying builds.",
    rules:
      "Must follow a downtrend; first body ≥ 60% of range; second low below the first low, close above the first close, lower shadow ≥ 30%; third bullish closing above the second close and in the upper third of its range.",
    notes: "A relatively mild bottom signal; needs follow-through.",
  },
  "t-three-stars-in-south": {
    summary: "Three stars in the south: three shrinking bearish candles that stop making new lows—sellers are spent; a bottom may form.",
    description:
      "In a downtrend: a long bearish candle with a lower shadow; a second bearish making a new low but closing back inside the first body; then a small bearish fully inside the second. Selling momentum fades step by step.",
    rules:
      "Must follow a downtrend; first body ≥ 50% of range; second low below the first low with close inside the first body; third body ≤ 20% of range with high/low inside the second.",
    notes: "A stabilization signal; still needs a bullish close to confirm.",
  },
  "t-stick-sandwich": {
    summary: "Stick sandwich: two bearish candles with the same close sandwich a bullish candle—the support level held twice.",
    description:
      "In a downtrend: a bearish candle, a bullish bounce, then a bearish candle closing at almost the same price as the first. The identical closes show the level was defended twice—solid support.",
    rules:
      "Must follow a downtrend; first bearish, second bullish, third bearish; first and third closes differ by ≤ 0.3%.",
    notes: "The matching closes are the key; repeated defense makes the support meaningful.",
  },
  "t-concealing-baby-swallow": {
    summary: "Concealing baby swallow: after two gap-down marubozu candles, a third bearish closes at a new low—sellers' last blow.",
    description:
      "In a downtrend: a black marubozu, a second black marubozu gapping below the first low, then a third bearish opening inside the second's body and closing below the second low. Two gaps followed by a fresh low often mark the final capitulation.",
    rules:
      "Must follow a downtrend; first body ≥ 90% of range; second a black marubozu opening below the first low; third bearish opening inside the second body and closing below the second low.",
    notes: "Rare; found at the end of an accelerating decline. It means the last leg down—high reversal odds but high risk; wait for a bullish confirmation.",
  },
  "m-rising-three-methods": {
    summary: "Rising three methods: a long bullish candle, a few small pullbacks above its low, then a long bullish close—a bullish continuation.",
    description:
      "In an uptrend: a long bullish candle, then 2–4 small candles (mostly bearish) whose highs/lows stay inside the first range, then a long bullish candle closing at a new high. A classic “two steps forward, one step back” continuation.",
    rules:
      "Must follow an uptrend; first body ≥ 60% of range; 2–4 middle candles stay inside the first range with at least one bearish; final bullish close above the first close.",
    notes: "Confirms the uptrend continues; the pattern fails if a middle candle closes below the first low.",
  },
  "m-falling-three-methods": {
    summary: "Falling three methods: a long bearish candle, a few small bounces below its high, then a long bearish close—a bearish continuation.",
    description:
      "In a downtrend: a long bearish candle, then 2–4 small candles (mostly bullish) whose highs/lows stay inside the first range, then a long bearish candle closing at a new low. A classic bearish continuation.",
    rules:
      "Must follow a downtrend; first body ≥ 60% of range; 2–4 middle candles stay inside the first range with at least one bullish; final bearish close below the first close.",
    notes: "Confirms the downtrend continues; the pattern fails if a middle candle closes above the first high.",
  },
  "m-mat-hold": {
    summary: "Mat hold: during the pullback one candle dips below the first bullish low (shakeout), then a long bullish close reclaims it—a stronger continuation.",
    description:
      "Similar to rising three methods, but at least one middle candle breaks below the first bullish low (a shakeout), after which price is bought back and the final bullish candle closes above the first close. The shakeout makes the advance more solid.",
    rules:
      "Must follow an uptrend; first a long bullish; among the 2–4 middle candles at least one low is below the first low; final bullish close above the first close.",
    notes: "One extra shakeout versus rising three methods; most reliable in strong trends. The quick recovery is the key.",
  },
  "m-ladder-bottom": {
    summary: "Ladder bottom: accelerating bearish candles, a long-upper-shadow candle, then a bullish reclaim—a bottom reversal.",
    description:
      "In a downtrend: three bearish candles making new lows (sellers accelerating), a fourth bearish candle with a long upper shadow (intraday counterattack), then a fifth bullish candle recovering most of the loss and closing above the third close. Sellers exhausted after their final sprint.",
    rules:
      "Must follow a downtrend; first three bearish with lower closes in turn; fourth bearish with upper shadow ≥ 50% of range; fifth bullish closing above the second/third close.",
    notes: "The long upper shadow on the fourth candle is the key; the fifth bullish close confirms.",
  },
  "m-ladder-top": {
    summary: "Ladder top: accelerating bullish candles, a long-lower-shadow candle, then a bearish pullback—a top reversal.",
    description:
      "In an uptrend: three bullish candles making new highs (buyers accelerating), a fourth bullish candle with a long lower shadow (intraday selling), then a fifth bearish candle closing below the third close. Buyers exhausted after their final sprint.",
    rules:
      "Must follow an uptrend; first three bullish with higher closes in turn; fourth bullish with lower shadow ≥ 50% of range; fifth bearish closing below the third close.",
    notes: "The long lower shadow on the fourth candle is the key; the fifth bearish close confirms.",
  },
  "m-upside-tasuki-gap": {
    summary: "Upside tasuki gap: after a gap up, a bearish candle dips into the gap but does not fill it—a bullish continuation.",
    description:
      "In an uptrend, an upward gap appears between two bullish candles; then a bearish candle opens inside the second body and closes into the gap zone (above the first close, below the second open). The unfilled gap confirms the advance is a continuation, not exhaustion.",
    rules:
      "Must follow an uptrend; first bullish; second bullish low above the first high (gap); third bearish opening inside the second body and closing above the first close but below the second open.",
    notes: "If the third close falls below the first close (gap filled), the pattern fails and turns bearish.",
  },
  "m-downside-tasuki-gap": {
    summary: "Downside tasuki gap: after a gap down, a bullish candle bounces into the gap but does not fill it—a bearish continuation.",
    description:
      "In a downtrend, a downward gap appears between two bearish candles; then a bullish candle opens inside the second body and closes into the gap zone (below the first close, above the second open). The unfilled gap confirms the decline continues.",
    rules:
      "Must follow a downtrend; first bearish; second bearish high below the first low (gap); third bullish opening inside the second body and closing below the first close but above the second open.",
    notes: "If the third close rises above the first close (gap filled), the pattern fails and turns bullish.",
  },
  "m-upside-gap-three-methods": {
    summary: "Upside gap three methods: after a gap up, a few small bearish candles hold above the gap, then a bullish close breaks out—strength continues.",
    description:
      "In an uptrend, a bullish candle gaps up; then 2–3 small bearish candles consolidate above the gap without filling it; finally a bullish candle closes above the second candle's close. The gap acts as support—a strong continuation.",
    rules:
      "Must follow an uptrend; first bullish; second bullish low above the first high (gap); 2–3 middle bearish lows stay above the first high; final bullish close above the second close.",
    notes: "The pattern fails if the gap is filled; it is stronger than a plain rising three methods.",
  },
  "m-three-gaps-up": {
    summary: "Three gaps up: after three consecutive upward gaps, momentum is overstretched—beware exhaustion and a pullback.",
    description:
      "Three consecutive upward gaps (each candle's low above the prior high). More gaps mean more euphoria, but also rapidly consumed buying power. The old adage “three gaps and the move is done” describes this extreme condition.",
    rules: "Four candles where the last three each gap above the prior candle's high.",
    notes: "An exhaustion warning, not an automatic reversal; in strong trends more gaps can follow. Risk rises sharply once volume stalls or a bearish candle appears.",
  },
  "m-three-gaps-down": {
    summary: "Three gaps down: after three consecutive downward gaps, selling is overstretched—beware a sharp bounce.",
    description:
      "Three consecutive downward gaps (each candle's high below the prior low). Panic selling is released all at once and selling power is rapidly consumed, raising the odds of a technical rebound.",
    rules: "Four candles where the last three each gap below the prior candle's low.",
    notes: "An oversold warning, not an automatic bottom; in panic markets more gaps can follow. A high-volume bullish candle or gap fill raises the rebound odds.",
  },
  "m-eight-new-price-lines-up": {
    summary: "Eight new price lines up: eight consecutive closes each making a new high—strong but entering an overheated zone.",
    description:
      "Eight consecutive candles whose closes rise one after another (each a new closing high). Traditional Japanese candlestick theory holds that after eight new highs, upside momentum is overconsumed and a pullback can come at any time.",
    rules: "The last eight consecutive candles each close above the prior close.",
    notes: "An overheating warning, not a shorting signal; in a strong bull market the streak can go further. Combine with other signals.",
  },
  "m-eight-new-price-lines-down": {
    summary: "Eight new price lines down: eight consecutive closes each making a new low—strong decline but entering an ice-cold zone.",
    description:
      "Eight consecutive candles whose closes fall one after another (each a new closing low). After eight new lows, selling is overreleased and a technical bounce can come at any time.",
    rules: "The last eight consecutive candles each close below the prior close.",
    notes: "An oversold warning, not a bottom-fishing signal; wait for stabilization signs such as a long bullish candle, volume surge, or gap fill.",
  },
};

export const STRATEGY_EN = {
  turtle: {
    summary: "Enter on 20/55-day Donchian channel breakouts, manage with ATR stops, pyramid on strength.",
    rules: "Close above the 20-day high to go long / below the 20-day low to go short; 2×ATR stop; add once per 0.5×ATR move in your favor.",
  },
  livermore: {
    summary: "Trade only at pivotal points (breakouts of platforms/round numbers) in the direction of the trend; leave immediately when wrong.",
    rules: "Follow price when it breaks a long consolidation range on volume; exit at once if the breakout fails (close back inside).",
  },
  "ma-cross": {
    summary: "Use fast/slow moving-average crosses to define trend direction and hold with the trend.",
    rules: "MA7 crossing above MA25 = long; below = short; signals are stronger when MA7/25/99 align.",
  },
  guppy: {
    summary: "Separation and convergence of short-term vs long-term moving-average groups define trend and entries.",
    rules: "Short group (3/5/8/10/12) above the long group (15/30/45/60) = bullish; expansion after consolidation is a launch signal.",
  },
  "elder-triple": {
    summary: "Big timeframe sets direction, medium timeframe finds the pullback, small timeframe times the entry—buy dips with the trend.",
    rules: "Long-term MA up → long only; wait for a pullback to the medium MA; confirm with an oscillator before entering.",
  },
  wyckoff: {
    summary: "Read accumulation/distribution phases through price-volume action (spring, shakeout, breakout).",
    rules: "Low-volume stabilization plus a high-volume bullish candle at the end of a decline = accumulation; high-volume stall plus long upper shadows at the top = distribution.",
  },
  bollinger: {
    summary: "Price mean-reverts after touching the bands; a squeeze followed by expansion starts trends.",
    rules: "Close below the lower band with RSI<30 → seek a bounce; above the upper band with RSI>70 → watch for a fall; after a squeeze, trade the breakout on volume.",
  },
  rsi: {
    summary: "RSI<30 oversold, >70 overbought; confirm reversals with divergence and candlestick patterns.",
    rules: "RSI(14)<30 with a bullish candlestick pattern → long; >70 with a bearish pattern → short; divergences are more reliable.",
  },
  stochastic: {
    summary: "K/D crosses below 20 favor longs, above 80 favor shorts; watch divergence from price.",
    rules: "Uses the range position as a K proxy: below 20 oversold, above 80 overbought; confirm with candles.",
  },
  donchian: {
    summary: "Enter on breaks of N-day highs/lows; the channel midline is the exit reference.",
    rules: "Break the 20-day upper band → long, lower band → short; reduce below the 10-day midline.",
  },
  "volume-breakout": {
    summary: "Breakouts are reliable only with significant volume—price and volume must confirm.",
    rules: "Trade a 20-day high/low breakout only when volume ≥ 1.5× average; low-volume breakouts are treated as fake.",
  },
  obv: {
    summary: "Price and OBV rising together confirm health; divergence warns of a turn.",
    rules: "New price high without a new OBV high → bearish divergence; new low without a new OBV low → bullish divergence.",
  },
  vwap: {
    summary: "VWAP is the institutional intraday cost line: above = bullish bias, below = bearish bias.",
    rules: "Close above VWAP with rising MAs → long with trend; below VWAP with falling MAs → short.",
  },
  atr: {
    summary: "Use ATR to size positions and stops; cut size when volatility expands.",
    rules: "Reduce position to half and widen stops when ATR% > 3%; when < 1%, wait for a breakout to add.",
  },
  keltner: {
    summary: "EMA20 ± 2×ATR channel: above the upper band is strong, below the lower is weak, inside is consolidation.",
    rules: "Close above the upper band with rising MAs → trend continues; below the lower band → trend weakens.",
  },
  squeeze: {
    summary: "Bollinger inside Keltner = a squeeze; a volume breakout after the squeeze is a strong launch.",
    rules: "After the squeeze (Bollinger width < Keltner width), a volume breakout above the range top → long, below → short.",
  },
  soros: {
    summary: "Go with trends that reinforce expectations; watch for turns when trend and fundamentals diverge.",
    rules: "Trend + volume + no divergence → reflexive continuation; divergence/reversal candles at the end → watch for a reflexive turn.",
  },
  tudor: {
    summary: "Look for reversal days at extremes: long shadows or reversal candles at the end of a long move.",
    rules: "After many trend bars at range extremes, a reversal candle (hammer/shooting star/engulfing) → counter-trend entry.",
  },
  "williams-r": {
    summary: "%R below -80 oversold, above -20 overbought; confirm with candlestick patterns.",
    rules: "%R<-80 with a bullish candle → long; %R>-20 with a bearish candle → short.",
  },
  kroll: {
    summary: "Stay with the big trend and hold; keep the position as long as pullbacks respect key MAs.",
    rules: "Hold while long-term MAs are bullish-aligned; add on stabilization near MA25; exit below MA99.",
  },
  minervini: {
    summary: "Strong stocks in stage 2: uptrend + tight consolidation + high-volume breakout buy point.",
    rules: "Bullish MAs + price in the upper part of a base + low-volume pullback + high-volume break above prior highs.",
  },
  elliott: {
    summary: "Price moves in 5-wave impulses and 3-wave corrections; retracements into the golden zone often start the next wave.",
    rules: "After an impulse, a retracement that stabilizes in 0.382–0.618 → expect the next wave; a break below 0.786 puts the structure in doubt.",
  },
  dow: {
    summary: "Trend is defined by the direction of highs and lows: higher highs + higher lows = uptrend.",
    rules: "20-day highs and lows rising together → bullish; falling together → bearish; conflicting → ranging.",
  },
  kostolany: {
    summary: "“Markets are born in despair, grow in doubt, and die in euphoria”—use sentiment against the crowd.",
    rules: "Extreme oversold + panic volume → contrarian buying interest; extreme overbought + euphoric volume → contrarian caution.",
  },
  schwartz: {
    summary: "Enter counter to small pullbacks/bounces but with the major trend.",
    rules: "When the major trend is up, wait for a reversal candle near support/MA on the pullback, then buy; vice versa.",
  },
  chan: {
    summary: "Use pivots (中枢) and divergence (背驰): momentum fading at the end of a move plus a pullback to the pivot is the classic buy.",
    rules: "After price leaves the pivot, volume-price divergence (exhaustion) → watch a return to the pivot/support; expanding momentum means the trend continues.",
  },
  "chart-pattern": {
    summary: "Breakouts and targets from head-and-shoulders, double tops/bottoms, triangles, flags, wedges.",
    rules: "Trade in the breakout direction: bottom patterns break up, top patterns break down; measure targets by pattern height.",
  },
  banmuxia: {
    summary: "Left-side trading: use repeated MACD divergence to find high-odds bottoms/tops with low leverage and strict discipline.",
    rules: "New low with a higher MACD histogram (bottom divergence) → left-side staged buying; new high with a lower histogram (top divergence) → staged exits; repeated divergence is more reliable; keep leverage at 2–3× and effective leverage ≤ 0.5×.",
  },
  bitking: {
    summary: "Trade only daily/weekly major trends (≥30%); hold with the trend and pyramid with unrealized profits; no ranging trades.",
    rules: "Only when major MAs are clear and the move is ≥30%; add only on stabilized pullbacks with the trend; never add against the trend; fix the stop before entry and execute precisely.",
  },
  "macd-cross": {
    summary: "MACD crossing above its signal line = golden cross (long); below = death cross (short).",
    rules: "DIF crosses above DEA with the histogram turning positive → long; below with negative histogram → short; golden crosses above zero are stronger.",
  },
  adx: {
    summary: "ADX measures trend strength: >25 valid trend, <20 ranging—avoid trend trades in ranges.",
    rules: "ADX>25 with +DI>-DI → long with trend; ADX>25 with -DI>+DI → short; ADX<20 → stand aside.",
  },
  ichimoku: {
    summary: "Tenkan/Kijun crosses and the cloud define trend and support/resistance.",
    rules: "Price above the cloud with Tenkan>Kijun → bullish; below with Tenkan<Kijun → bearish; inside the cloud → stand aside.",
  },
  momentum: {
    summary: "Buy recent strength and avoid recent weakness—momentum persistence is one of the most robust anomalies.",
    rules: "20-day return positive and expanding → hold strength; negative → avoid weakness; momentum rolling over warns of reversal.",
  },
  supertrend: {
    summary: "An ATR-based dynamic channel; closes above/below it decide long/short.",
    rules: "Close above MA20−2×ATR → hold long; below MA20+2×ATR → short.",
  },
  alligator: {
    summary: "Three smoothed MAs (jaw/teeth/lips) that separate after being tangled = trend start; direction follows the opening mouth.",
    rules: "After the tangle (alligator sleeping), an upward opening mouth → long, downward → short; the best win rate is at the initial opening.",
  },
  "connors-rsi2": {
    summary: "Buy when RSI(2) is extremely oversold; short-term reversion is a classic high-win-rate low-buy strategy.",
    rules: "RSI(2)<10 near recent lows → buy; RSI(2)>90 → sell/avoid.",
  },
  zscore: {
    summary: "Price more than 2 standard deviations from its mean has a statistical edge to revert.",
    rules: "Z>2 sell, Z<-2 buy, exit near Z=0.",
  },
  grid: {
    summary: "Buy low and sell high across price levels in a range; earns volatility spread, unsuitable for trends.",
    rules: "Best in ranges (ADX<20) with moderate volatility; a trend start makes grids get stuck against the market.",
  },
  dca: {
    summary: "Invest a fixed amount on a fixed schedule; averages cost, suited to long-term allocation rather than timing.",
    rules: "Can be executed at any time; higher volatility improves the edge; it does not predict short-term moves.",
  },
  kelly: {
    summary: "Optimal position size from win rate and payoff: f = (bp − q)/b.",
    rules: "Win rate/payoff come from backtests; this strategy uses half-Kelly and caps any position at half the Kelly value.",
  },
  martingale: {
    summary: "Doubling down after losses to recover—fragile equity and margin-call risk in extremes.",
    rules: "Limited to small positions with a hard cap; stop after 5 drawdowns; high risk, not for beginners (rule description).",
  },
  retest: {
    summary: "Enter when price pulls back to the breakout level and holds—more stable than chasing the breakout.",
    rules: "After breaking the 20-day channel, enter on a stabilized retest of the edge; a breakdown invalidates the breakout.",
  },
  orb: {
    summary: "Trade the opening range: break the range top long, bottom short—suited to intraday.",
    rules: "Take the first N bars' range after the open; enter with volume on a break; exit immediately on a fake breakout.",
  },
  gap: {
    summary: "High-volume gaps usually continue the trend; ordinary gaps tend to fill.",
    rules: "Up gap + volume → strength continues; down gap + volume → weakness; low-volume gaps are prone to fill.",
  },
  island: {
    summary: "Two opposite gaps isolate a group of bars into an island—top islands bearish, bottom islands bullish.",
    rules: "Two consecutive opposite gaps (gap then counter-gap) form the island; judge with volume and location.",
  },
  "candle-combo": {
    summary: "Directional signals from hammer, engulfing, morning/evening star, three soldiers/crows and similar combinations.",
    rules: "Bullish combinations (hammer/bullish engulfing/morning star/three soldiers) → watch longs; bearish combinations are the opposite.",
  },
  "ad-line": {
    summary: "A/D line reflects accumulation/distribution; divergence from price warns of a turn.",
    rules: "Price and A/D rising together → healthy inflow; new price high without a new A/D high → distribution warning.",
  },
  cmf: {
    summary: "CMF>0 inflow, <0 outflow; signals are stronger beyond ±0.1.",
    rules: "CMF(20)>0.1 with price rising → long; <-0.1 → short/avoid.",
  },
  mfi: {
    summary: "Volume-weighted RSI: <20 oversold, >80 overbought; divergence is more reliable.",
    rules: "MFI<20 with a bullish candle → buy the dip; >80 with a bearish candle → sell the top.",
  },
  chandelier: {
    summary: "Set the stop 3×ATR below the recent high; let profits run.",
    rules: "Long stop = highest high of the last 22 bars − 3×ATR; short stop = lowest low of the last 22 bars + 3×ATR.",
  },
  lynn: {
    summary: "“Invest in what you understand”: find growth stocks and hold long-term; on price, look for growth momentum.",
    rules: "Needs fundamentals (PEG, earnings growth); this tool only provides price momentum and trend references, not a full valuation.",
  },
  "oneil-canslim": {
    summary: "Strong growth stocks: current earnings, annual earnings, new products, supply, leaders, institutions, market direction.",
    rules: "On price: uptrend + tight low-volume pullback + high-volume breakout of prior highs (N-point buy); fundamentals must be checked separately.",
  },
  buffett: {
    summary: "Buy great companies with a margin of safety and hold long-term; price data only offers sentiment context.",
    rules: "Needs fundamentals (ROE, cash flow, valuation); on price, watch extreme cheapness and low volatility.",
  },
  murphy: {
    summary: "Trend, patterns, volume and indicators must verify each other; act only when several tools resonate.",
    rules: "The strongest signal is when MA direction, breakout, volume and indicators align; stand aside when evidence conflicts.",
  },
  sperandeo: {
    summary: "“A Dow-theory practitioner”: trade only major trends; entries come when the secondary correction ends.",
    rules: "Once the major trend (MA alignment) is clear, wait for a secondary pullback to key MA/support to stabilize before entering.",
  },
  "fib-retrace": {
    summary: "After an impulse, a retracement into the 0.382–0.618 golden zone is a with-trend entry for the next leg.",
    rules: "Enter with the trend when price stabilizes in the golden zone without breaking 0.786; below 0.786 the structure is broken.",
  },
  "fake-break": {
    summary: "A breakout that immediately closes back inside the channel is fake; fading it often pays.",
    rules: "After an up-break, a close back inside the channel → short (bull trap); after a down-break, a close back inside → long (bear trap).",
  },
};
