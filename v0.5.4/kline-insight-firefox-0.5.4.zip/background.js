// 后台脚本（ESM 模块）：拉取行情并处理扩展页面的取数请求
// Chrome MV3 service worker 与 Firefox 事件页均支持 "type": "module"，
// 因此这里可以直接 import 核心引擎做批量扫描。

import { toOkxBar, toBybitBar, toTencentBar, toSinaFuturesType } from "./interval-map.js";
import { normalizeSymbol, parseStockSymbol, parseFuturesSymbol } from "./symbol-utils.js";

console.log("[kline-insight] background 已启动");

// 给图标加个角标，方便识别
try {
  chrome.action.setBadgeText({ text: "K线" });
  chrome.action.setBadgeBackgroundColor({ color: "#4f8cff" });
} catch (err) {
  console.warn("[kline-insight] 设置角标失败：", err);
}

const BINANCE_KLINE = "https://api.binance.com/api/v3/klines";
// 币安备用域名：大陆网络 api.binance.com 常被限/超时（实测 15s 无响应），
// data-api.binance.vision 大陆直连 0.6s 通（2026-08-13 实测）
const BINANCE_KLINE_BACKUP = "https://data-api.binance.vision/api/v3/klines";
const OKX_CANDLES = "https://www.okx.com/api/v5/market/candles";
const BYBIT_KLINE = "https://api.bybit.com/v5/market/kline";
// Gate.io：大陆网络实测直连 0.69s 通（2026-08-13，OKX/Bybit/KuCoin/MEXC/HTX 全超时）——OKX/Bybit 失败时的兜底源
const GATE_CANDLES = "https://api.gateio.ws/api/v4/spot/candlesticks";
const TENCENT_KLINE = "https://web.ifzq.gtimg.cn/appstock/app/fqkline/get";
const TENCENT_MINUTE_KLINE = "https://ifzq.gtimg.cn/appstock/app/kline/mkline";
const EASTMONEY_KLINE = "https://push2his.eastmoney.com/api/qt/stock/kline/get";
const SINA_CN_KLINE = "https://quotes.sina.cn/cn/api/jsonp_v2.php";
const SINA_FUTURES_KLINE = "https://stock2.finance.sina.com.cn/futures/api/jsonp.php";
const SINA_US_DAILY = "https://stock.finance.sina.com.cn/usstock/api/jsonp_v2.php";
const STOOQ_CSV = "https://stooq.com/q/d/l/";
const YAHOO_CHART = "https://query1.finance.yahoo.com/v8/finance/chart/";

/** 单次网络请求超时（毫秒）：超时立即放弃，避免一个慢接口拖死整个流程 */
const FETCH_TIMEOUT_MS = 15000;
/** 行情结果短期缓存：同一标的+周期 1 分钟内不重复拉取 */
const KLINE_CACHE_TTL_MS = 60 * 1000;
/** 数据源失败后暂停使用的时间（毫秒） */
const SOURCE_COOLDOWN_MS = 15 * 60 * 1000;

/** 数据源失败记忆：key = 市场+来源，连续失败后 15 分钟内自动跳过该源 */
const sourceFailures = new Map();
/** 最近一次取数使用的数据源（按请求 reqId 记录，用于状态栏展示） */
const fetchProgress = new Map();
const klineCache = new Map();

/** 原生 fetch（供带超时版本内部使用，避免递归） */
const originalFetch = globalThis.fetch;

/** 带超时的 fetch：超时抛错，由上层换下一个数据源 */
async function fetchWithTimeout(url, options = {}, timeoutMs = FETCH_TIMEOUT_MS) {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    return await originalFetch(url, { ...options, signal: ctrl.signal });
  } catch (err) {
    if (err && err.name === "AbortError") {
      // 大陆网络提示：海外数据源（交易所/美股/指数）在大陆直连常超时，明确告知而非让用户以为是插件故障
      throw new Error(`请求超时（>${Math.round(timeoutMs / 1000)}秒）。中国大陆网络可能无法直连该海外数据源，请检查网络或稍后重试`);
    }
    throw err;
  } finally {
    clearTimeout(timer);
  }
}

/** 全源失败统一提示：若错误为超时/网络类，附加中国大陆网络说明 */
function cnNetworkHint(err) {
  const msg = String((err && err.message) || err);
  if (/超时|Failed to fetch|NetworkError|网络异常|Load failed|ETIMEDOUT|ECONNRESET|fetch failed/i.test(msg)) {
    return `${msg}。若在中国大陆网络，海外数据源（交易所/美股/指数）可能无法直连，请检查网络或稍后重试`;
  }
  return msg;
}

/** 本文件内所有 fetch 调用自动带超时（含未来新增的请求） */
const fetch = fetchWithTimeout;

function markSourceFailed(key) {
  if (!key) return;
  const rec = sourceFailures.get(key) || { failAt: 0 };
  rec.failAt = Date.now();
  sourceFailures.set(key, rec);
}

function sourceOnCooldown(key) {
  const rec = sourceFailures.get(key);
  return !!rec && Date.now() - rec.failAt < SOURCE_COOLDOWN_MS;
}

function klineCacheKey(msg) {
  return `${msg.exchange}|${msg.symbol}|${msg.interval}|${msg.limit || msg.bars || ""}`;
}

function klineCacheGet(key) {
  const hit = klineCache.get(key);
  if (hit && Date.now() - hit.ts < KLINE_CACHE_TTL_MS) return hit.candles;
  if (hit) klineCache.delete(key);
  return null;
}

function klineCacheSet(key, candles) {
  if (klineCache.size >= 200) {
    const oldest = [...klineCache.entries()].sort((a, b) => a[1].ts - b[1].ts)[0];
    if (oldest) klineCache.delete(oldest[0]);
  }
  klineCache.set(key, { ts: Date.now(), candles });
}

/** 把“正在用哪个数据源”广播给请求方（K线查看器/侧边栏状态栏） */
function reportProgress(reqId, label, ok = false) {
  if (!reqId) return;
  if (ok && label) fetchProgress.set(reqId, { label, ts: Date.now() });
  try {
    const p = chrome.runtime.sendMessage({ type: "FETCH_PROGRESS", reqId, label, ok });
    if (p && typeof p.catch === "function") p.catch(() => {});
  } catch {
    // 接收方可能已关闭，忽略
  }
}

/**
 * 多源竞速：同时发请求，取第一个数据够用的源；全部失败时退回最全的残缺数据。
 * 每个源自带超时，卡住的源不会拖累整体。
 * @param {Array<{label: string, key: string, fn: () => Promise<any>}>} sources
 * @param {(label: string, ok?: boolean) => void} [trace]
 * @param {string[]} errors
 * @param {number} minBars
 */
async function raceSources(sources, trace, errors, minBars = 1) {
  const jobs = [];
  for (const s of sources) {
    if (sourceOnCooldown(s.key)) {
      errors.push(`${s.label}：数据源冷却中（近期失败自动跳过，稍后再试）`);
      continue;
    }
    if (trace) trace(s.label);
    jobs.push({
      s,
      p: Promise.resolve()
        .then(() => s.fn())
        .then((candles) => ({ candles }))
        .catch((error) => {
          // 审计 H1：区分错误类型——网络/HTTP 类错误才冷却源（markSourceFailed），
          // "标的不支持/无数据"（err.code === "UNSUPPORTED"）是业务性错误，冷却会让一次
          // 误输入废掉全市场源 15 分钟（如腾讯对北交所 92 开头 throw）
          if (error && error.code !== "UNSUPPORTED") markSourceFailed(s.key);
          return { error };
        }),
    });
  }
  if (!jobs.length) return null;
  const pending = new Set(jobs);
  let bestPartial = null;
  while (pending.size) {
    const settled = await Promise.race([...pending].map((j) => j.p.then((r) => ({ j, r }))));
    pending.delete(settled.j);
    const { s } = settled.j;
    const { r } = settled;
    if (r.candles && r.candles.length) {
      if (r.candles.length >= minBars) {
        if (trace) trace(s.label, true);
        return r.candles;
      }
      // 数据不全不拉黑：新上市标的可能所有源都只有少量K线，仍要能取到最全的一份
      if (!bestPartial || r.candles.length > bestPartial.candles.length) {
        bestPartial = { label: s.label, candles: r.candles };
      }
    } else if (r.error) {
      markSourceFailed(s.key);
      errors.push(`${s.label}：${r.error.message}`);
    } else {
      errors.push(`${s.label}：暂不支持该周期/市场`);
    }
  }
  if (bestPartial) {
    if (trace) trace(bestPartial.label, true);
    return bestPartial.candles;
  }
  return null;
}

export { raceSources, fetchWithTimeout };

/** 币安K线行 → Candle */
function mapBinanceRow(k) {
  return {
    open: Number(k[1]),
    high: Number(k[2]),
    low: Number(k[3]),
    close: Number(k[4]),
    volume: Number(k[5]),
    timestamp: Number(k[0]),
  };
}

/** OKX K线行 → Candle（OKX 返回时间倒序） */
function mapOkxRow(k) {
  return {
    open: Number(k[1]),
    high: Number(k[2]),
    low: Number(k[3]),
    close: Number(k[4]),
    volume: Number(k[5]),
    timestamp: Number(k[0]),
  };
}

/**
 * 拉取币安K线
 * @param {{symbol: string, interval: string, limit: number}} p
 * @returns {Promise<Candle[]>}
 */
async function fetchBinance({ symbol, interval, limit }) {
  // 币安 klines 单次上限 1000 根，超出会返回 400（定投 5 年窗口需要 1260 根，先截断不报错）
  const lmt = Math.min(limit || 500, 1000);
  const q = `symbol=${encodeURIComponent(normalizeSymbol("binance", symbol))}&interval=${encodeURIComponent(interval)}&limit=${lmt}`;
  // 主域名失败（大陆常超时）自动切备用域名，主域名 8s 内没响应不等了
  const hosts = [BINANCE_KLINE, BINANCE_KLINE_BACKUP];
  let lastErr = null;
  for (let i = 0; i < hosts.length; i++) {
    try {
      const res = await fetchWithTimeout(`${hosts[i]}?${q}`, {}, i === 0 ? 8000 : FETCH_TIMEOUT_MS);
      if (res.status === 451) {
        throw new Error(
          "币安在你的网络被区域限制（HTTP 451），无法访问。请改用 OKX，或选择「手动粘贴数据」。",
        );
      }
      if (!res.ok) throw new Error(`币安接口返回 HTTP ${res.status}`);
      const data = await res.json();
      if (!Array.isArray(data) || data.length === 0) {
        throw new Error("币安没有返回K线数据，请检查交易对名称（如 BTCUSDT）");
      }
      return data.map(mapBinanceRow);
    } catch (e) {
      lastErr = e;
      if (i === 0) continue; // 主域名失败 → 备用
      break; // 备用也失败 → 抛错
    }
  }
  // 审计 H3：币安整体失败（网络类）写冷却——fallbackCrypto 回退前查冷却，避免重复重试刚失败的源
  if (lastErr && !/451|HTTP \d|没有返回/.test(lastErr.message)) markSourceFailed("crypto:binance");
  throw lastErr || new Error("币安行情获取失败");
}

/**
 * 拉取 OKX K线（返回按时间倒序，最新在前）
 * @param {{symbol: string, interval: string, limit: number, after?: string}} p
 * @returns {Promise<Candle[]>}
 */
async function fetchOkxPage({ symbol, interval, limit, after }) {
  // 审计 H2：OKX candles 接口 limit 上限 300，超限会返回错误导致静默回退币安（用户以为在看 OKX 实际是币安数据）
  const safeLimit = Math.min(Number(limit) || 300, 300);
  let url = `${OKX_CANDLES}?instId=${encodeURIComponent(normalizeSymbol("okx", symbol))}&bar=${encodeURIComponent(toOkxBar(interval))}&limit=${safeLimit}`;
  if (after) url += `&after=${after}`;
  const res = await fetch(url);
  if (!res.ok) throw new Error(`OKX 接口返回 HTTP ${res.status}`);
  const data = await res.json();
  if (data.code !== "0") {
    throw new Error(
      `OKX 接口错误：${data.msg || data.code}。请检查产品ID，OKX 格式为大写加横线，例如 BTC-USDT。`,
    );
  }
  if (!Array.isArray(data.data) || data.data.length === 0) {
    throw new Error("OKX 没有返回K线数据，请检查产品ID（如 BTC-USDT）");
  }
  return data.data.map(mapOkxRow);
}

/**
 * 拉取 OKX K线（正序）
 */
async function fetchOkx(p) {
  try {
    const rows = await fetchOkxPage(p);
    return rows.reverse();
  } catch (err) {
    // 大陆网络 OKX 常超时（15s 无响应）：回退币安双域名 → Gate.io（大陆直连实测 0.69s 通）
    return fallbackCrypto(p, err, "OKX");
  }
}

/**
 * 拉取 OKX 历史K线（分页翻页，正序）
 * @param {{symbol: string, interval: string, bars: number}} p
 */
async function fetchOkxHistory({ symbol, interval, bars }) {
  const rows = [];
  let after;
  const pages = Math.min(Math.ceil(bars / 300), 8);
  for (let page = 0; page < pages && rows.length < bars; page++) {
    const batch = await fetchOkxPage({ symbol, interval, limit: 300, after });
    if (batch.length === 0) break;
    rows.push(...batch);
    after = batch[batch.length - 1].timestamp;
  }
  return rows.reverse().slice(-bars);
}

/**
 * 拉取 Bybit K线（返回按时间倒序，最新在前；category=spot 现货）
 * @param {{symbol: string, interval: string, limit: number, end?: string}} p
 * @returns {Promise<Candle[]>}
 */
async function fetchBybitPage({ symbol, interval, limit, end }) {
  let url = `${BYBIT_KLINE}?category=spot&symbol=${encodeURIComponent(normalizeSymbol("bybit", symbol))}&interval=${encodeURIComponent(toBybitBar(interval))}&limit=${limit}`;
  if (end) url += `&end=${end}`;
  const res = await fetch(url);
  if (!res.ok) throw new Error(`Bybit 接口返回 HTTP ${res.status}`);
  const data = await res.json();
  if (data.retCode !== 0) {
    throw new Error(
      `Bybit 接口错误：${data.retMsg || data.retCode}。请检查交易对（如 BTCUSDT）。`,
    );
  }
  const list = (data.result && data.result.list) || [];
  if (!list.length) {
    throw new Error("Bybit 没有返回K线数据，请检查交易对（如 BTCUSDT）");
  }
  return list.map((k) => ({
    open: Number(k[1]),
    high: Number(k[2]),
    low: Number(k[3]),
    close: Number(k[4]),
    volume: Number(k[5]),
    timestamp: Number(k[0]),
  }));
}

/**
 * 拉取 Bybit K线（正序）
 */
async function fetchBybit(p) {
  try {
    const rows = await fetchBybitPage(p);
    return rows.reverse();
  } catch (err) {
    // 大陆网络 Bybit 常超时：回退币安双域名 → Gate.io
    return fallbackCrypto(p, err, "Bybit");
  }
}

/** OKX/Bybit 失败后的加密K线兜底：币安双域名（含备用）→ Gate.io（大陆直连通） */
async function fallbackCrypto(p, err, fromLabel) {
  // 审计 H3：币安失败会写冷却，回退前先查——避免刚失败的币安（主8s+备15s=23s）又被完整重试一遍，
  // 大陆网络最坏从 61s 降到 ~15s
  if (sourceOnCooldown("crypto:binance")) {
    try {
      return await fetchGate(p);
    } catch (e2) {
      throw new Error(cnNetworkHint(`${fromLabel}行情获取失败：${err.message}（币安冷却中跳过，Gate 兜底也失败：${e2.message}）`));
    }
  }
  try {
    return await fetchBinance(p);
  } catch (e1) {
    try {
      return await fetchGate(p);
    } catch (e2) {
      throw new Error(cnNetworkHint(`${fromLabel}行情获取失败：${err.message}（币安/Gate 兜底也失败：${e1.message} / ${e2.message}）`));
    }
  }
}

/** Gate.io 周期 → 原生格式（与币安同为 5m/15m/1h/1d/1w/1M；1M=monthly） */
function toGateInterval(interval) {
  const map = { "1m": "1m", "5m": "5m", "15m": "15m", "30m": "30m", "1h": "1h", "4h": "4h", "1d": "1d", "1w": "1w", "1M": "1M" };
  return map[interval] || interval;
}

/**
 * 拉取 Gate.io K线（大陆直连通；行格式 [秒时间戳, 成交量, 收盘, 最高, 最低, 开盘, 量, 收盘标志]）
 * @param {{symbol: string, interval: string, limit: number}} p
 */
async function fetchGate({ symbol, interval, limit }) {
  const lmt = Math.min(limit || 500, 1000);
  const pair = normalizeSymbol("binance", symbol).replace(/^(\w+)(USDT|USDC|FDUSD|USD|BTC|ETH|EUR|TRY)$/, "$1_$2");
  const url = `${GATE_CANDLES}?currency_pair=${encodeURIComponent(pair)}&interval=${encodeURIComponent(toGateInterval(interval))}&limit=${lmt}`;
  const res = await fetchWithTimeout(url, {}, FETCH_TIMEOUT_MS);
  if (!res.ok) throw new Error(`Gate.io 接口返回 HTTP ${res.status}`);
  const data = await res.json();
  if (!Array.isArray(data) || data.length === 0) {
    throw new Error("Gate.io 没有返回K线数据，请检查交易对（如 BTC_USDT）");
  }
  return data.map((k) => ({
    // Gate 行: [时间戳秒, 成交量, 收盘, 最高, 最低, 开盘, 量, 是否收盘]
    timestamp: Number(k[0]) * 1000,
    open: Number(k[5]),
    high: Number(k[3]),
    low: Number(k[4]),
    close: Number(k[2]),
    volume: Number(k[1]),
  }));
}

/**
 * 拉取 Bybit 历史K线（end 游标向前翻页，正序）
 * @param {{symbol: string, interval: string, bars: number}} p
 */
async function fetchBybitHistory({ symbol, interval, bars }) {
  const rows = [];
  let end;
  const pages = Math.min(Math.ceil(bars / 300), 8);
  for (let page = 0; page < pages && rows.length < bars; page++) {
    const batch = await fetchBybitPage({ symbol, interval, limit: 300, end });
    if (batch.length === 0) break;
    rows.push(...batch);
    end = String(batch[batch.length - 1].timestamp);
  }
  return rows.reverse().slice(-bars);
}

/**
 * 拉取币安历史K线（单次最多 1000 根）
 * @param {{symbol: string, interval: string, bars: number}} p
 */
async function fetchBinanceHistory({ symbol, interval, bars }) {
  return fetchBinance({ symbol, interval, limit: Math.min(bars, 1000) });
}

/** 币安/Bybit 永续候选：同计价币优先，其次常见 USDT 永续（0GUSDC → 0GUSDC、0GUSDT） */
function perpCandidates(symbol, exchange) {
  const s = normalizeSymbol(exchange, symbol);
  const m = s.match(/^(.*?)(USDC|FDUSD|BUSD|USD|EUR|TRY)$/);
  const out = [s];
  if (m && m[1] && m[2] !== "USDT") out.push(`${m[1]}USDT`);
  return out;
}

/** OKX 永续合约候选：同计价币优先，其次 USDT 永续（0G-USDC → 0G-USDC-SWAP、0G-USDT-SWAP） */
function okxSwapCandidates(symbol) {
  const s = normalizeSymbol("okx", symbol).replace(/-SWAP$/, "");
  const out = [`${s}-SWAP`];
  const idx = s.lastIndexOf("-");
  if (idx > 0) {
    const base = s.slice(0, idx);
    const quote = s.slice(idx + 1);
    if (quote !== "USDT") out.push(`${base}-USDT-SWAP`);
  }
  return out;
}

/** 币安资金费率（USDT-M 永续 premiumIndex，含下一次结算时间） */
async function fetchBinanceFundingRate({ symbol }) {
  const candidates = perpCandidates(symbol, "binance");
  let lastErr = null;
  for (const s of candidates) {
    const url = `https://fapi.binance.com/fapi/v1/premiumIndex?symbol=${encodeURIComponent(s)}`;
    const res = await fetch(url);
    if (res.status === 451) {
      throw new Error("币安合约接口在你的网络被区域限制（HTTP 451），无法获取资金费率。请改用 OKX 或 Bybit 数据源。");
    }
    if (!res.ok) {
      lastErr = new Error(`币安资金费率接口返回 HTTP ${res.status}`);
      continue;
    }
    const data = await res.json();
    if (data && data.symbol && data.lastFundingRate != null) {
      const next = Number(data.nextFundingTime) || 0;
      return {
        instId: data.symbol,
        fundingRate: Number(data.lastFundingRate) || 0,
        fundingTime: next - 8 * 3600 * 1000,
        nextFundingTime: next,
      };
    }
    lastErr = new Error(`币安没有返回资金费率，请确认 ${s} 是 USDT 永续合约`);
  }
  throw lastErr || new Error("币安没有返回资金费率");
}

/** Bybit 资金费率（linear 永续 ticker，含下一次结算时间） */
async function fetchBybitFundingRate({ symbol }) {
  const candidates = perpCandidates(symbol, "bybit");
  let lastErr = null;
  for (const s of candidates) {
    const url = `https://api.bybit.com/v5/market/tickers?category=linear&symbol=${encodeURIComponent(s)}`;
    const res = await fetch(url);
    if (!res.ok) {
      lastErr = new Error(`Bybit 资金费率接口返回 HTTP ${res.status}`);
      continue;
    }
    const data = await res.json();
    const list = data && data.result && data.result.list;
    if (data.retCode === 0 && Array.isArray(list) && list[0] && list[0].fundingRate != null) {
      const t = list[0];
      const next = Number(t.nextFundingTime) || 0;
      return {
        instId: t.symbol,
        fundingRate: Number(t.fundingRate) || 0,
        fundingTime: next - 8 * 3600 * 1000,
        nextFundingTime: next,
      };
    }
    lastErr = new Error(`Bybit 资金费率错误：${(data && data.retMsg) || data.retCode}（合约 ${s}）`);
  }
  throw lastErr || new Error("Bybit 没有返回资金费率");
}

/** OKX 资金费率（公开接口，自动匹配永续合约 ID） */
async function fetchOkxFundingRate({ symbol }) {
  const candidates = okxSwapCandidates(symbol);
  let lastErr = null;
  for (const instId of candidates) {
    const url = `https://www.okx.com/api/v5/public/funding-rate?instId=${encodeURIComponent(instId)}`;
    const res = await fetch(url);
    if (!res.ok) {
      lastErr = new Error(`OKX 资金费率接口返回 HTTP ${res.status}`);
      continue;
    }
    const data = await res.json();
    if (data.code === "0" && data.data && data.data[0]) {
      const row = data.data[0];
      return {
        instId,
        fundingRate: Number(row.fundingRate),
        fundingTime: Number(row.fundingTime),
        nextFundingTime: Number(row.nextFundingTime),
      };
    }
    lastErr = new Error(`OKX 资金费率错误：${(data && data.msg) || "无数据"}（合约 ${instId}）`);
  }
  throw lastErr || new Error("OKX 没有返回资金费率");
}

/** 资金费率入口：跟随当前数据源，各交易所查各所的永续 */
async function fetchFundingRate(msg) {
  const exchange = msg.exchange || "okx";
  if (exchange === "stock" || exchange === "futures") {
    throw new Error("资金费率仅适用于加密货币交易对（币安 / OKX / Bybit）");
  }
  if (exchange === "binance" || exchange === "bybit") {
    // 本所优先；若本所被区域限制或没有该永续，再回退 OKX 匹配
    const own =
      exchange === "binance" ? fetchBinanceFundingRate(msg) : fetchBybitFundingRate(msg);
    try {
      return await own;
    } catch (err) {
      const fallback = await fetchOkxFundingRate(msg).catch(() => null);
      if (fallback) return fallback;
      throw new Error(
        `${exchange === "binance" ? "币安" : "Bybit"}资金费率获取失败：${err.message}`,
      );
    }
  }
  return fetchOkxFundingRate(msg);
}

/**
 * OKX 爆仓数据（最近已成交爆仓单，按仓位方向汇总损失）。
 * 全网免费爆仓接口只有 OKX 提供，币安/Bybit 页面也走 OKX，并自动匹配 OKX 合约。
 */
async function fetchOkxLiquidations({ symbol }) {
  const candidates = okxSwapCandidates(symbol);
  let lastErr = null;
  for (const instId of candidates) {
    const uly = instId.replace(/-SWAP$/, "");
    const url = `https://www.okx.com/api/v5/public/liquidation-orders?instType=SWAP&uly=${encodeURIComponent(uly)}&state=filled&limit=100`;
    const res = await fetch(url);
    if (!res.ok) {
      lastErr = new Error(`OKX 爆仓接口返回 HTTP ${res.status}`);
      continue;
    }
    const data = await res.json();
    if (data.code !== "0" || !Array.isArray(data.data)) {
      lastErr = new Error(`OKX 爆仓数据错误：${(data && data.msg) || "无数据"}（合约 ${instId}）`);
      continue;
    }
    let longLoss = 0;
    let shortLoss = 0;
    let count = 0;
    for (const item of data.data) {
      const details = item.details || [];
      for (const r of details) {
        const loss = Math.abs(Number(r.bkLoss) || 0);
        count++;
        if (loss > 0) {
          if (r.posSide === "long") longLoss += loss;
          else if (r.posSide === "short") shortLoss += loss;
        }
      }
    }
    return { instId, count, longLoss, shortLoss };
  }
  throw lastErr || new Error("OKX 没有返回爆仓数据");
}

/** 爆仓数据入口：跟随当前数据源做合约匹配（数据本身来自 OKX 公开接口） */
function fetchLiquidations(msg) {
  if (msg && (msg.exchange === "stock" || msg.exchange === "futures")) {
    return Promise.reject(new Error("爆仓数据仅适用于加密货币交易对（币安 / OKX / Bybit）"));
  }
  return fetchOkxLiquidations(msg);
}

/**
 * 恐慌贪婪指数（alternative.me，无密钥）
 */
async function fetchFearGreed() {
  const url = "https://api.alternative.me/fng/?limit=30&format=json";
  const res = await fetch(url);
  if (!res.ok) throw new Error(`恐慌贪婪指数接口返回 HTTP ${res.status}`);
  const data = await res.json();
  const list = (data && data.data) || [];
  if (!list.length || list[0].value == null) {
    throw new Error("恐慌贪婪指数没有返回数据");
  }
  const current = Number(list[0].value);
  const history = list
    .slice(0, 7)
    .map((x) => ({ value: Number(x.value), ts: Number(x.timestamp) }));
  return {
    current,
    classification: list[0].value_classification,
    history,
    avg7: history.reduce((a, b) => a + b.value, 0) / Math.max(history.length, 1),
  };
}

/** A股代码 → 腾讯 secid（6/9 开头沪市，0/1/2/3 开头深市；北交所 92 开头腾讯不支持 → 返回 null 由东财/新浪兜底） */
function toTencentSecid(code) {
  const c = String(code || "").trim();
  if (/^92\d{4}$/.test(c)) return null; // 北交所：腾讯不覆盖，走东财/新浪
  if (/^[69]/.test(c)) return `sh${c}`;
  if (/^[0123]/.test(c)) return `sz${c}`;
  // 审计 H1：业务性"不支持"错误带 code: "UNSUPPORTED"——raceSources 据此不冷却该源
  const err = new Error(`暂不支持 ${c}：新三板行情暂未接入，请使用沪市（6/9开头）或深市（0/1/2/3开头）代码`);
  err.code = "UNSUPPORTED";
  throw err;
}

/** 全球股票 → 腾讯 secid（A股 sh/sz + 数字、美股 usAAPL、港股 hk00700；日/韩/台暂不在腾讯） */
function stockToTencentSecid({ market, code }) {
  if (market === "cn") return toTencentSecid(code);
  if (market === "us") return `us${String(code).replace(/-/g, ".")}`;
  if (market === "hk") return `hk${code}`;
  return null;
}

/**
 * 腾讯行情K线（复权；bar 可为 day/week/month/m5/m15/m30/m60）
 * @param {{secid: string, bar?: string, lmt?: number}} p
 */
async function fetchTencentKline({ secid, bar = "day", lmt = 120 }) {
  // A股分钟K线（5m/15m/30m/1h）只有 mkline 接口支持，fqkline 对分钟返回空数据
  const isMinute = ["m5", "m15", "m30", "m60"].includes(bar);
  const url = isMinute
    ? `${TENCENT_MINUTE_KLINE}?param=${encodeURIComponent(secid)},${bar},,${lmt}`
    : `${TENCENT_KLINE}?param=${encodeURIComponent(secid)},${bar},,,${lmt},qfq`;
  const res = await fetch(url);
  if (!res.ok) throw new Error(`腾讯行情接口返回 HTTP ${res.status}`);
  const data = await res.json();
  const node = data && data.data && data.data[secid];
  const rows = (node && (node.qfqday || node.day || node[bar] || node.data)) || [];
  if (!rows.length) {
    // 审计 H1：腾讯对部分代码/市场返回空是业务性"不支持"（如北交所），非源故障——不冷却
    const err = new Error(`腾讯行情没有返回 ${secid} 的K线数据`);
    err.code = "UNSUPPORTED";
    throw err;
  }
  return rows.map((p) => {
    const open = Number(p[1]);
    const c2 = Number(p[2]);
    const high = Number(p[3]);
    const low = Number(p[4]);
    // 标准列序为 [日期,开,收,高,低,量]；部分接口是 [日期,开,高,低,收,量]。
    // 用 OHLC 合法性判断自动纠正，避免把 high/low/close 映射错位
    if (high >= Math.max(open, c2) && low <= Math.min(open, c2)) {
      return {
        timestamp: toTencentTs(p[0]),
        open,
        close: c2,
        high,
        low,
        volume: Number(p[5]),
      };
    }
    return {
      timestamp: toTencentTs(p[0]),
      open,
      close: low,
      high: c2,
      low: high,
      volume: Number(p[5]),
    };
  }).slice(-lmt);
}

/** 东财 secid：A股 1.600519 / 0.000001（北交所 0.920367），港股 116.00700，美股 105.AAPL */
function eastmoneySecid({ market, code }) {
  const c = String(code || "").replace(/\.(SS|SZ|HK|US)$/i, "").toUpperCase();
  if (market === "cn") {
    // 北交所 92 开头 → 东财 market 0（实测 0.920367 有数据，1.920367 无）；沪市 6/9 开头 → 1.；深市 0/1/2/3 → 0.
    if (/^92\d{4}$/.test(c)) return `0.${c}`;
    return c.startsWith("6") || c.startsWith("9") ? `1.${c}` : `0.${c}`;
  }
  if (market === "hk") return `116.${c}`;
  if (market === "us") return `105.${c}`;
  return null;
}

/** 东财周期 → klt：5m/15m/30m/60m/日/周/月 */
const EASTMONEY_KLT = { "5m": 5, "15m": 15, "30m": 30, "1h": 60, "1d": 101, "1w": 102, "1M": 103 };

/**
 * 东方财富历史K线（A股/港股/美股，分钟与日/周/月都支持，作腾讯之后的第一备用源）
 * @param {{market: string, code: string, interval: string, limit: number}} p
 * @returns {Promise<Candle[]|null>} 不支持的市场/周期返回 null，由调用方跳过
 */
async function fetchEastMoneyKlines({ market, code, interval, limit }) {
  const secid = eastmoneySecid({ market, code });
  const klt = EASTMONEY_KLT[interval];
  if (!secid || !klt) return null;
  const lmt = Math.min(limit || 200, 800);
  const url =
    `${EASTMONEY_KLINE}?secid=${encodeURIComponent(secid)}` +
    `&fields1=f1,f2,f3,f4,f5,f6&fields2=f51,f52,f53,f54,f55,f56,f57,f58` +
    `&klt=${klt}&fqt=1&beg=0&end=20500101&lmt=${lmt}`;
  const res = await fetch(url);
  if (!res.ok) throw new Error(`东财接口返回 HTTP ${res.status}`);
  const data = await res.json();
  const node = data && data.data;
  const rows = node && Array.isArray(node.klines) ? node.klines : [];
  if (!rows.length) throw new Error(`东财没有返回 ${secid} 的K线数据`);
  const candles = rows.map((line) => {
    const p = String(line).split(",");
    const open = Number(p[1]);
    const close = Number(p[2]);
    const high = Number(p[3]);
    const low = Number(p[4]);
    return {
      timestamp: toTencentTs(p[0]),
      open,
      high,
      low,
      close,
      volume: Number(p[5]),
    };
  }).filter((c) => c.open > 0 && c.close > 0 && c.high > 0 && c.low > 0);
  if (!candles.length) throw new Error(`东财返回的 ${secid} K线数据无效`);
  return candles.slice(-lmt);
}

/** 新浪 A股周期 → scale：5m/15m/30m/1h/日（240=日线） */
const SINA_SCALE = { "5m": 5, "15m": 15, "30m": 30, "1h": 60, "1d": 240 };

/**
 * 新浪行情K线（A股分钟/日线、美股日线，作第二备用源）
 * @param {{market: string, code: string, interval: string, limit: number}} p
 * @returns {Promise<Candle[]|null>}
 */
async function fetchSinaKlines({ market, code, interval, limit }) {
  const c = String(code || "").replace(/\.(SS|SZ|HK|US)$/i, "");
  if (market === "cn") {
    const scale = SINA_SCALE[interval];
    if (!scale) return null;
    // 北交所 92 开头 → bj 前缀（新浪实测支持 bj920367）；沪市 6/9 → sh；深市 → sz
    const symbol = /^92\d{4}$/.test(c) ? `bj${c}` : c.startsWith("6") || c.startsWith("9") ? `sh${c}` : `sz${c}`;
    const lmt = Math.min(limit || 200, 800);
    const url = `${SINA_CN_KLINE}/var%20_${symbol}=/CN_MarketDataService.getKLineData?symbol=${symbol}&scale=${scale}&ma=no&datalen=${lmt}`;
    const res = await fetch(url);
    if (!res.ok) throw new Error(`新浪接口返回 HTTP ${res.status}`);
    const text = await res.text();
    const m = text.match(/\(\s*(\[.*\])\s*\)/s);
    if (!m) throw new Error(`新浪没有返回 ${symbol} 的K线数据`);
    const rows = JSON.parse(m[1]);
    if (!rows || !rows.length) throw new Error(`新浪没有返回 ${symbol} 的K线数据`);
    const candles = rows.map((r) => ({
      timestamp: toTencentTs(String(r.day || "").trim().replace(" ", "T")),
      open: Number(r.open),
      high: Number(r.high),
      low: Number(r.low),
      close: Number(r.close),
      volume: Number(r.volume),
    })).filter((x) => x.open > 0 && x.close > 0 && x.high > 0 && x.low > 0);
    if (!candles.length) throw new Error(`新浪返回的 ${symbol} K线数据无效`);
    return candles.slice(-lmt);
  }
  if (market === "us" && (interval === "1d" || interval === "1w" || interval === "1M")) {
    const url = `${SINA_US_DAILY}/var%20_${c}=/US_MinKService.getDailyK?symbol=${c}`;
    const res = await fetch(url);
    if (!res.ok) throw new Error(`新浪美股接口返回 HTTP ${res.status}`);
    const text = await res.text();
    const m = text.match(/\(\s*(\[.*\])\s*\)/s);
    if (!m) throw new Error(`新浪没有返回 ${c} 的K线数据`);
    const rows = JSON.parse(m[1]);
    if (!rows || !rows.length) throw new Error(`新浪没有返回 ${c} 的K线数据`);
    const lmt = Math.min(limit || 200, 800);
    const candles = rows.map((r) => ({
      timestamp: toTencentTs(String(r.d || "").replace(/\./g, "")),
      open: Number(r.o),
      high: Number(r.h),
      low: Number(r.l),
      close: Number(r.c),
      volume: Number(r.v),
    })).filter((x) => x.open > 0 && x.close > 0 && x.high > 0 && x.low > 0);
    if (!candles.length) throw new Error(`新浪返回的 ${c} K线数据无效`);
    return candles.slice(-lmt);
  }
  return null;
}

/** 新浪期货K线（国内期货：分钟线 getFewMinLine / 日线 getDailyKLine，返回 JSONP 数组） */
function aggregateFuturesCandles(candles, interval) {
  const buckets = new Map();
  for (const c of candles) {
    const d = new Date(c.timestamp);
    let key;
    if (interval === "1w") {
      const mondayOffset = (d.getDay() + 6) % 7;
      const monday = new Date(d.getFullYear(), d.getMonth(), d.getDate() - mondayOffset);
      key = monday.toISOString().slice(0, 10);
    } else {
      key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
    }
    const prev = buckets.get(key);
    if (!prev) {
      buckets.set(key, { ...c, timestamp: Date.parse(`${key}T00:00:00`) });
    } else {
      prev.high = Math.max(prev.high, c.high);
      prev.low = Math.min(prev.low, c.low);
      prev.close = c.close;
      prev.volume = (prev.volume || 0) + (c.volume || 0);
    }
  }
  return [...buckets.values()];
}

async function fetchSinaFuturesKlines({ symbol, interval, limit }) {
  const { code } = parseFuturesSymbol(symbol);
  const sym = code.toUpperCase();
  const lmt = Math.min(limit || 200, 800);
  const type = toSinaFuturesType(interval);
  let url;
  if (type != null) {
    url = `${SINA_FUTURES_KLINE}/var%20_${sym}=/InnerFuturesNewService.getFewMinLine?symbol=${sym}&type=${type}`;
  } else {
    if (!["1d", "1w", "1M"].includes(interval)) {
      return null;
    }
    url = `${SINA_FUTURES_KLINE}/var%20_${sym}=/InnerFuturesNewService.getDailyKLine?symbol=${sym}`;
  }
  const res = await fetch(url);
  if (!res.ok) throw new Error(`新浪期货接口返回 HTTP ${res.status}`);
  const text = await res.text();
  const m = text.match(/\(\s*(\[.*\])\s*\)/s);
  if (!m) throw new Error(`新浪期货没有返回 ${sym} 的K线数据`);
  const rows = JSON.parse(m[1]);
  if (!rows || !rows.length) throw new Error(`新浪期货没有返回 ${sym} 的K线数据`);
  const candles = rows
    .map((r) => ({
      timestamp: toTencentTs(String(r.d || "").trim().replace(" ", "T")),
      open: Number(r.o),
      high: Number(r.h),
      low: Number(r.l),
      close: Number(r.c),
      volume: Number(r.v),
    }))
    .filter((x) => x.open > 0 && x.close > 0 && x.high > 0 && x.low > 0);
  if (!candles.length) throw new Error(`新浪期货返回的 ${sym} K线数据无效`);
  const out = interval === "1w" || interval === "1M" ? aggregateFuturesCandles(candles, interval) : candles;
  return out.slice(-lmt);
}

/** 东财期货K线（国内期货 secid=113.xxxx，作新浪的备用源） */
async function fetchEastMoneyFuturesKlines({ symbol, interval, limit }) {
  const { code } = parseFuturesSymbol(symbol);
  const klt = EASTMONEY_KLT[interval];
  if (!klt) return null;
  const secid = `113.${code.toLowerCase()}`;
  const lmt = Math.min(limit || 200, 800);
  const url =
    `${EASTMONEY_KLINE}?secid=${encodeURIComponent(secid)}` +
    `&fields1=f1,f2,f3,f4,f5,f6&fields2=f51,f52,f53,f54,f55,f56,f57,f58` +
    `&klt=${klt}&fqt=0&beg=0&end=20500101&lmt=${lmt}`;
  const res = await fetch(url);
  if (!res.ok) throw new Error(`东财期货接口返回 HTTP ${res.status}`);
  const data = await res.json();
  const node = data && data.data;
  const rows = node && Array.isArray(node.klines) ? node.klines : [];
  if (!rows.length) throw new Error(`东财期货没有返回 ${secid} 的K线数据`);
  const candles = rows
    .map((line) => {
      const p = String(line).split(",");
      const open = Number(p[1]);
      const close = Number(p[2]);
      const high = Number(p[3]);
      const low = Number(p[4]);
      return {
        timestamp: toTencentTs(p[0]),
        open,
        high,
        low,
        close,
        volume: Number(p[5]),
      };
    })
    .filter((c) => c.open > 0 && c.close > 0 && c.high > 0 && c.low > 0);
  if (!candles.length) throw new Error(`东财期货返回的 ${secid} K线数据无效`);
  return candles.slice(-lmt);
}

/** Stooq 期货代码（ES=F → es.f、CL=F → cl.f） */
function toStooqFuturesSymbol(code) {
  return String(code || "").toLowerCase().replace("=", ".f");
}

/** Stooq 期货K线（日/周/月；Yahoo 之后的兜底） */
async function fetchStooqFuturesKlines({ symbol, interval, limit }) {
  const barMap = { "1d": "d", "1w": "w", "1M": "m" };
  const bar = barMap[interval];
  if (!bar) return null;
  const { code } = parseFuturesSymbol(symbol);
  const sym = toStooqFuturesSymbol(code);
  const d2 = new Date().toISOString().slice(0, 10).replace(/-/g, "");
  const url = `${STOOQ_CSV}?s=${encodeURIComponent(sym)}&i=${bar}&d1=20000101&d2=${d2}&f=sdohlcv`;
  const res = await fetch(url);
  if (!res.ok) throw new Error(`Stooq 接口返回 HTTP ${res.status}`);
  const text = await res.text();
  const candles = parseStooqCsv(text);
  if (!candles.length) throw new Error(`Stooq 没有返回 ${sym} 的K线数据`);
  return candles.slice(-Math.min(limit || 320, 2000));
}

/**
 * 期货K线入口：
 * - 国内（RB2510/AU0/IF2509）：新浪期货、东财期货并行竞速
 * - 全球（ES=F/CL=F/GC=F）：Yahoo、Stooq 并行竞速
 * 每个源自带超时，失败自动跳过并记录。
 * @param {{symbol: string, interval: string, limit: number}} p
 * @param {(label: string, ok?: boolean) => void} [trace]
 */
async function fetchFuturesKlines({ symbol, interval, limit }, trace) {
  const parsed = parseFuturesSymbol(symbol);
  const lmt = Math.min(limit || 320, 800);
  const errors = [];
  const minBars = Math.min(lmt, 30);
  const sources =
    parsed.market === "cn"
      ? [
          {
            label: "新浪期货",
            key: "futures-cn:sina",
            fn: () => fetchSinaFuturesKlines({ symbol, interval, limit: lmt }),
          },
          {
            label: "东财期货",
            key: "futures-cn:eastmoney",
            fn: () => fetchEastMoneyFuturesKlines({ symbol, interval, limit: lmt }),
          },
        ]
      : [
          {
            label: "Yahoo",
            key: "futures-us:yahoo",
            fn: () => fetchYahooKlines({ market: "us", code: parsed.code, interval, limit: lmt }),
          },
          {
            label: "Stooq",
            key: "futures-us:stooq",
            fn: () => fetchStooqFuturesKlines({ symbol, interval, limit: lmt }),
          },
        ];
  const candles = await raceSources(sources, trace, errors, minBars);
  if (candles) return candles;
  throw new Error(cnNetworkHint(`${parsed.market === "cn" ? "国内" : "全球"}期货 ${symbol} 行情获取失败：${errors.join("；")}`));
}

/** 腾讯日期字符串 → 时间戳（分钟数据如 20240804150000 无法直接 Date.parse，解析失败返回 undefined） */
function toTencentTs(dateStr) {
  const s = String(dateStr || "").trim();
  if (!s) return undefined;
  const ts = Date.parse(s);
  if (!Number.isNaN(ts)) return ts;
  // 兼容 YYYYMMDDHHmmss / YYYYMMDD
  const m = s.match(/^(\d{4})(\d{2})(\d{2})(?:(\d{2})(\d{2})(\d{2})?)?$/);
  if (m) {
    return new Date(
      Number(m[1]),
      Number(m[2]) - 1,
      Number(m[3]),
      Number(m[4] || 0),
      Number(m[5] || 0),
      Number(m[6] || 0),
    ).getTime();
  }
  return undefined;
}

/**
 * Stooq 股票代码（全球 CSV 源）：AAPL → aapl.us、00700 → 0700.hk、7203.T → 7203.jp、
 * 005930.KS → 005930.ks、2330.TW → 2330.tw
 * @param {{symbol: string, interval: string, limit: number}} p
 */
export function toStooqSymbol({ market, code }) {
  const c = String(code || "");
  if (c.startsWith("^")) return c.toLowerCase(); // 指数（^spx 等）原样
  if (market === "us") return `${String(code).replace(/-/g, ".").toLowerCase()}.us`;
  if (market === "hk") return `${String(Number(code)).padStart(4, "0")}.hk`;
  if (market === "jp") return `${code.replace(/\.T$/i, "").toLowerCase()}.jp`;
  if (market === "kr") return `${code.replace(/\.KS$/i, "").toLowerCase()}.ks`;
  if (market === "tw") return `${code.replace(/\.TW$/i, "").toLowerCase()}.tw`;
  if (market === "cn") return `${code}.cn`;
  return `${code}.us`;
}

/**
 * 常见指数的各数据源代码（Stooq / Yahoo）
 * 腾讯行情不提供指数K线，指数数据走 Stooq → Yahoo 回退
 */
const INDEX_SOURCES = {
  SPX:   { stooq: "^spx",   yahoo: "^GSPC" },
  IXIC:  { stooq: "^ndq",   yahoo: "^IXIC" },
  DJI:   { stooq: "^dji",   yahoo: "^DJI" },
  NDX:   { stooq: "^ndx",   yahoo: "^NDX" },
  VIX:   { stooq: "^vix",   yahoo: "^VIX" },
  RUT:   { stooq: "^rut",   yahoo: "^RUT" },
  DXY:   { stooq: "^dxy",   yahoo: "^DX-Y.NYB" },
  HSI:   { stooq: "^hsi",   yahoo: "^HSI" },
  HSCEI: { stooq: "^hsce",  yahoo: "^HSCE" },
  TWII:  { stooq: "^twse",  yahoo: "^TWII" },
  NI225: { stooq: "^nkx",   yahoo: "^N225" },
  TPX:   { stooq: "^topx",  yahoo: "^TOPX" },
  KOSPI: { stooq: "^kospi", yahoo: "^KS11" },
  KOSDAQ:{ stooq: "^kosdaq",yahoo: "^KQ11" },
};

const INDEX_BY_YAHOO = Object.fromEntries(
  Object.entries(INDEX_SOURCES).map(([canon, src]) => [src.yahoo.toUpperCase(), canon]),
);

/** 规范指数代码：SPX / ^GSPC → SPX；非指数返回 null */
export function canonicalIndexCode(code) {
  const s = String(code || "").toUpperCase();
  if (INDEX_SOURCES[s]) return s;
  return INDEX_BY_YAHOO[s] || null;
}

/** Stooq CSV → 标准蜡烛数组（按时间升序） */
export function parseStooqCsv(text) {
  const lines = String(text || "").trim().split(/\r?\n/);
  if (lines.length < 2) return [];
  const header = lines[0].toLowerCase().split(",");
  const idx = {
    date: header.indexOf("date"),
    open: header.indexOf("open"),
    high: header.indexOf("high"),
    low: header.indexOf("low"),
    close: header.indexOf("close"),
    volume: header.indexOf("volume"),
  };
  const out = [];
  for (let i = 1; i < lines.length; i++) {
    const cols = lines[i].split(",");
    const get = (k) => (idx[k] >= 0 ? cols[idx[k]] : undefined);
    const date = get("date");
    const open = Number(get("open"));
    const high = Number(get("high"));
    const low = Number(get("low"));
    const close = Number(get("close"));
    if (!date || !(open > 0) || !(high > 0) || !(low > 0) || !(close > 0)) continue;
    const ts = Date.parse(date);
    if (Number.isNaN(ts)) continue;
    out.push({
      timestamp: ts,
      open,
      high,
      low,
      close,
      volume: Number(get("volume")) || 0,
    });
  }
  return out.sort((a, b) => a.timestamp - b.timestamp);
}

/**
 * Stooq 历史K线（全球免费源，免登录；日/周/月全，分钟级只有近几天）
 */
async function fetchStooqKlines({ market, code, interval, limit }) {
  const barMap = { "1d": "d", "1w": "w", "1M": "m" };
  const bar = barMap[interval];
  if (!bar) {
    return null;
  }
  const sym = toStooqSymbol({ market, code });
  const d2 = new Date().toISOString().slice(0, 10).replace(/-/g, "");
  const url = `${STOOQ_CSV}?s=${encodeURIComponent(sym)}&i=${bar}&d1=20000101&d2=${d2}&f=sdohlcv`;
  const res = await fetch(url);
  if (!res.ok) throw new Error(`Stooq 接口返回 HTTP ${res.status}`);
  const text = await res.text();
  const candles = parseStooqCsv(text);
  if (!candles.length) {
    throw new Error(`Stooq 没有返回 ${sym} 的K线数据`);
  }
  return candles.slice(-Math.min(limit || 320, 2000));
}

/** Yahoo Finance 股票代码（AAPL / BRK-B / 0700.HK / 7203.T / 005930.KS / 2330.TW） */
function toYahooSymbol({ market, code }) {
  const c = String(code || "");
  if (c.startsWith("^")) return c; // 指数（^GSPC 等）原样
  if (market === "us") return code.replace(/\./g, "-");
  if (market === "hk") return `${String(Number(code)).padStart(4, "0")}.HK`;
  if (market === "cn") return /^[69]/.test(c) ? `${c}.SS` : `${c}.SZ`;
  if (market === "tw") return code; // Yahoo 台股原样 2330.TW
  return code;
}

/**
 * StockAnalysis 历史K线（美股全覆盖含冷门股，免费无 key；仅日/周/月线）
 */
async function fetchStockAnalysisKlines({ market, code, interval, limit }) {
  if (market !== "us") return null;
  const ivMap = { "1d": "Daily", "1w": "Weekly", "1M": "Monthly" };
  const period = ivMap[interval];
  if (!period) return null;
  const url = `https://stockanalysis.com/api/symbol/s/${encodeURIComponent(code)}/history?range=5Y&period=${period}&adjusted=true`;
  const res = await fetch(url);
  if (!res.ok) throw new Error(`StockAnalysis 接口返回 HTTP ${res.status}`);
  const data = await res.json();
  if (!data || !Array.isArray(data.data) || !data.data.length) {
    throw new Error(`StockAnalysis 没有返回 ${code} 的K线数据`);
  }
  const out = [];
  for (const row of data.data) {
    const open = Number(row.o);
    const high = Number(row.h);
    const low = Number(row.l);
    const close = Number(row.c);
    if (!(open > 0) || !(high > 0) || !(low > 0) || !(close > 0)) continue;
    out.push({
      timestamp: Date.parse(row.t),
      open,
      high,
      low,
      close,
      volume: Number(row.v || 0),
    });
  }
  // 接口返回倒序（最新在前）
  out.reverse();
  if (!out.length) throw new Error(`StockAnalysis 没有返回 ${code} 的有效K线`);
  return out.slice(-Math.min(limit || 320, 2000));
}

/**
 * Yahoo Finance 历史K线（全球覆盖最全，作最后兜底；部分网络不可达）
 */
async function fetchYahooKlines({ market, code, interval, limit }) {
  const ivMap = { "15m": "15m", "30m": "30m", "1h": "60m", "1d": "1d", "1w": "1wk", "1M": "1mo" };
  const iv = ivMap[interval];
  if (!iv) return null;
  const range = iv === "15m" || iv === "30m" ? "1mo" : iv === "60m" ? "2y" : "10y";
  const sym = toYahooSymbol({ market, code });
  // query1 失败时回退 query2（两个节点数据可能不同步）
  const hosts = [YAHOO_CHART, "https://query2.finance.yahoo.com/v8/finance/chart/"];
  let lastErr = null;
  for (const host of hosts) {
    try {
      const url =
        `${host}${encodeURIComponent(sym)}?interval=${iv}&range=${range}` +
        `&includePrePost=false&events=div%2Csplit`;
      const res = await fetch(url);
      if (!res.ok) {
        throw new Error(
          res.status === 404
            ? `Yahoo 接口返回 HTTP 404（${sym} 可能已退市或无此代码）`
            : `Yahoo 接口返回 HTTP ${res.status}`,
        );
      }
      const data = await res.json();
      const chart = data && data.chart;
      const result = chart && chart.result && chart.result[0];
      if (!result || !Array.isArray(result.timestamp)) {
        throw new Error(`Yahoo 没有返回 ${sym} 的K线数据`);
      }
      const quote = (result.indicators && result.indicators.quote && result.indicators.quote[0]) || {};
      const out = [];
      for (let i = 0; i < result.timestamp.length; i++) {
        const open = Number(quote.open && quote.open[i]);
        const high = Number(quote.high && quote.high[i]);
        const low = Number(quote.low && quote.low[i]);
        const close = Number(quote.close && quote.close[i]);
        if (!(open > 0) || !(high > 0) || !(low > 0) || !(close > 0)) continue;
        out.push({
          timestamp: result.timestamp[i] * 1000,
          open,
          high,
          low,
          close,
          volume: Number((quote.volume && quote.volume[i]) || 0),
        });
      }
      if (!out.length) throw new Error(`Yahoo 没有返回 ${sym} 的有效K线`);
      return out.slice(-Math.min(limit || 320, 2000));
    } catch (e) {
      lastErr = e;
    }
  }
  throw lastErr || new Error(`Yahoo 没有返回 ${sym} 的K线数据`);
}

/**
 * 拉取全球股票K线（多源并行竞速）：
 * - A股/美股/港股：腾讯、东财、新浪同时发，谁先返回完整数据用谁
 * - 日股/韩股/台股：Stooq、Yahoo 并行
 * - 每个源 8 秒超时，失败自动跳过并记录，15 分钟内不再重复踩坑
 * @param {{symbol: string, interval: string, limit: number}} p
 * @param {(label: string, ok?: boolean) => void} [trace]
 */
export async function fetchStockKlines({ symbol, interval, limit }, trace) {
  const { market, code } = parseStockSymbol(symbol);
  const marketLabel = { cn: "A股", us: "美股", hk: "港股", jp: "日股", kr: "韩股", tw: "台股" }[market] || market;
  const errors = [];
  const lmt = Math.min(limit || 320, 800);
  const minBars = Math.min(lmt, 30);

  // 指数：腾讯不提供，走 Stooq → Yahoo
  const idx = canonicalIndexCode(code);
  if (idx) {
    const src = INDEX_SOURCES[idx];
    const candles = await raceSources(
      [
        {
          label: "Stooq",
          key: `stock:${market}:stooq`,
          fn: () => fetchStooqKlines({ market, code: src.stooq, interval, limit: lmt }),
        },
        {
          label: "Yahoo",
          key: `stock:${market}:yahoo`,
          fn: () => fetchYahooKlines({ market, code: src.yahoo, interval, limit: lmt }),
        },
      ],
      trace,
      errors,
      minBars,
    );
    if (candles) return candles;
    throw new Error(cnNetworkHint(`${marketLabel} ${symbol}（指数）行情获取失败：${errors.join("；")}`));
  }

  // 全市场并行竞速：A股/港股优先国内复权源（腾讯/东财），美股同时竞速 Stooq/Yahoo（腾讯美股数据残缺），日股/韩股/台股直接 Stooq + Yahoo
  const sources = [];
  const domesticOnly = market === "cn" || market === "hk";
  if (market === "cn" || market === "us" || market === "hk") {
    if (market === "cn") {
      sources.push({
        label: "腾讯行情",
        key: `stock:${market}:tencent`,
        fn: () => {
          const secid = stockToTencentSecid({ market, code });
          const bar = toTencentBar(interval);
          return secid && bar ? fetchTencentKline({ secid, bar, lmt }) : null;
        },
      });
      sources.push({
        label: "东财行情",
        key: `stock:${market}:eastmoney`,
        fn: () => fetchEastMoneyKlines({ market, code, interval, limit: lmt }),
      });
      sources.push({
        label: "新浪行情",
        key: `stock:${market}:sina`,
        fn: () => fetchSinaKlines({ market, code, interval, limit: lmt }),
      });
    } else {
      sources.push({
        label: "东财行情",
        key: `stock:${market}:eastmoney`,
        fn: () => fetchEastMoneyKlines({ market, code, interval, limit: lmt }),
      });
      sources.push({
        label: "腾讯行情",
        key: `stock:${market}:tencent`,
        fn: () => {
          const secid = stockToTencentSecid({ market, code });
          const bar = toTencentBar(interval);
          return secid && bar ? fetchTencentKline({ secid, bar, lmt }) : null;
        },
      });
      sources.push({
        label: "新浪行情",
        key: `stock:${market}:sina`,
        fn: () => fetchSinaKlines({ market, code, interval, limit: lmt }),
      });
    }
  }
  if (!domesticOnly) {
    sources.push({
      label: "Stooq",
      key: `stock:${market}:stooq`,
      fn: () => fetchStooqKlines({ market, code, interval, limit: lmt }),
    });
    sources.push({
      label: "StockAnalysis",
      key: `stock:${market}:stockanalysis`,
      fn: () => fetchStockAnalysisKlines({ market, code, interval, limit: lmt }),
    });
    sources.push({
      label: "Yahoo",
      key: `stock:${market}:yahoo`,
      fn: () => fetchYahooKlines({ market, code, interval, limit: lmt }),
    });
  }

  const candles = await raceSources(sources, trace, errors, minBars);
  if (candles) return candles;
  // A股/港股主源失败后的兜底：Stooq / Yahoo（仅日/周/月可用，分钟数据自动跳过）
  if (domesticOnly) {
    const fallback = await raceSources(
      [
        {
          label: "Stooq",
          key: `stock:${market}:stooq`,
          fn: () => fetchStooqKlines({ market, code, interval, limit: lmt }),
        },
        {
          label: "Yahoo",
          key: `stock:${market}:yahoo`,
          fn: () => fetchYahooKlines({ market, code, interval, limit: lmt }),
        },
      ],
      trace,
      errors,
      minBars,
    );
    if (fallback) return fallback;
  }
  throw new Error(
    cnNetworkHint(
      `${marketLabel} ${symbol} 行情获取失败：${errors.join("；")}。该标的可能已退市、停牌、代码有误或超出数据源覆盖范围`,
    ),
  );
}

/** 股票历史K线（多源回退，上限 800 根） */
async function fetchStockHistory({ symbol, interval, bars }) {
  return fetchStockKlines({ symbol, interval, limit: Math.min(bars, 800) });
}

/** 期货历史K线（国内/全球，上限 800 根） */
async function fetchFuturesHistory({ symbol, interval, bars }) {
  return fetchFuturesKlines({ symbol, interval, limit: Math.min(bars, 800) });
}

/**
 * 东财财报披露日期（RPT_LICO_FN_CPD 业绩报表）
 * @param {{code: string}} p
 */
async function fetchEarningsDate({ code }) {
  const filter = encodeURIComponent(`(SECURITY_CODE="${String(code).trim()}")`);
  const url =
    `https://datacenter-web.eastmoney.com/api/data/v1/get?reportName=RPT_LICO_FN_CPD&columns=ALL` +
    `&filter=${filter}&sortColumns=NOTICE_DATE&sortTypes=-1&pageSize=5&pageNumber=1`;
  const res = await fetch(url);
  if (!res.ok) throw new Error(`东财财报接口返回 HTTP ${res.status}`);
  const data = await res.json();
  const rows = data && data.result && data.result.data;
  if (!Array.isArray(rows) || !rows.length) {
    throw new Error(`未找到代码 ${code} 的财报披露数据`);
  }
  return rows.map((r) => ({
    name: r.SECURITY_NAME_ABBR,
    reportDate: r.REPORTDATE,
    noticeDate: r.NOTICE_DATE,
    profit: r.PARENT_NETPROFIT,
    income: r.TOTAL_OPERATE_INCOME,
  }));
}

const isFirefox = typeof browser !== "undefined";

if (isFirefox) {
  // 火狐：点击工具栏图标打开侧边栏（若 manifest 配置了 default_popup，则由弹窗接管）
  chrome.action.onClicked.addListener(() => {
    if (browser.sidebarAction && browser.sidebarAction.open) {
      browser.sidebarAction.open().catch((err) => {
        console.error("打开火狐侧边栏失败：", err);
      });
    }
  });
} else if (chrome.sidePanel) {
  /** Chrome：让「点击图标」直接打开侧边面板（无 popup 时 openPanelOnActionClick 生效） */
  function enablePanelOnClick() {
    if (!chrome.sidePanel || !chrome.sidePanel.setPanelBehavior) return;
    chrome.sidePanel
      .setPanelBehavior({ openPanelOnActionClick: true })
      .then(() => console.log("[kline-insight] 已启用「点击图标打开侧边栏」"))
      .catch((err) => console.error("[kline-insight] setPanelBehavior 失败：", err));
  }
  enablePanelOnClick();
  chrome.runtime.onInstalled.addListener(enablePanelOnClick);
  chrome.runtime.onStartup.addListener(enablePanelOnClick);
  // 兜底：若 openPanelOnActionClick 未生效，onClicked 会触发并手动打开面板
  chrome.action.onClicked.addListener(async () => {
    try {
      const win = await chrome.windows.getCurrent();
      await chrome.sidePanel.open({ windowId: win ? win.id : chrome.windows.WINDOW_ID_CURRENT });
      console.log("[kline-insight] 已通过 onClicked 打开侧边栏");
    } catch (err) {
      console.error("[kline-insight] 打开侧边栏失败：", err);
    }
  });
}

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg && msg.type === "FETCH_KLINES") {
    const fn =
      msg.exchange === "okx"
        ? fetchOkx
        : msg.exchange === "bybit"
          ? fetchBybit
          : msg.exchange === "stock"
            ? fetchStockKlines
            : msg.exchange === "futures"
            ? fetchFuturesKlines
              : fetchBinance;
    const cacheKey = klineCacheKey(msg);
    const hit = klineCacheGet(cacheKey);
    if (hit) {
      sendResponse({ ok: true, candles: hit.slice(), source: "缓存" });
      return;
    }
    const trace = (label, ok) => reportProgress(msg.reqId, label, ok);
    fn(msg, trace)
      .then((candles) => {
        klineCacheSet(cacheKey, candles);
        const info = msg.reqId ? fetchProgress.get(msg.reqId) : null;
        sendResponse({ ok: true, candles, source: info ? info.label : null });
        if (msg.reqId) setTimeout(() => fetchProgress.delete(msg.reqId), 2000);
      })
      .catch((err) => {
        if (msg.reqId) setTimeout(() => fetchProgress.delete(msg.reqId), 2000);
        sendResponse({ ok: false, error: err.message || String(err) });
      });
    return true; // 异步响应
  }
  if (msg && msg.type === "FETCH_HISTORY") {
    const fn =
      msg.exchange === "okx"
        ? fetchOkxHistory
        : msg.exchange === "bybit"
          ? fetchBybitHistory
          : msg.exchange === "stock"
            ? fetchStockHistory
            : msg.exchange === "futures"
            ? fetchFuturesHistory
              : fetchBinanceHistory;
    const cacheKey = klineCacheKey(msg);
    const hit = klineCacheGet(cacheKey);
    if (hit) {
      sendResponse({ ok: true, candles: hit.slice(), source: "缓存" });
      return;
    }
    const trace = (label, ok) => reportProgress(msg.reqId, label, ok);
    fn(msg, trace)
      .then((candles) => {
        klineCacheSet(cacheKey, candles);
        const info = msg.reqId ? fetchProgress.get(msg.reqId) : null;
        sendResponse({ ok: true, candles, source: info ? info.label : null });
        if (msg.reqId) setTimeout(() => fetchProgress.delete(msg.reqId), 2000);
      })
      .catch((err) => {
        if (msg.reqId) setTimeout(() => fetchProgress.delete(msg.reqId), 2000);
        sendResponse({ ok: false, error: err.message || String(err) });
      });
    return true;
  }
  if (msg && msg.type === "FETCH_FUNDING_RATE") {
    fetchFundingRate(msg)
      .then((data) => sendResponse({ ok: true, data }))
      .catch((err) => sendResponse({ ok: false, error: err.message || String(err) }));
    return true;
  }
  if (msg && msg.type === "FETCH_LIQUIDATIONS") {
    fetchLiquidations(msg)
      .then((data) => sendResponse({ ok: true, data }))
      .catch((err) => sendResponse({ ok: false, error: err.message || String(err) }));
    return true;
  }
  if (msg && msg.type === "FETCH_FEAR_GREED") {
    fetchFearGreed()
      .then((data) => sendResponse({ ok: true, data }))
      .catch((err) => sendResponse({ ok: false, error: err.message || String(err) }));
    return true;
  }
  if (msg && msg.type === "FETCH_EARNINGS") {
    fetchEarningsDate(msg)
      .then((data) => sendResponse({ ok: true, data }))
      .catch((err) => sendResponse({ ok: false, error: err.message || String(err) }));
    return true;
  }
  if (msg && msg.type === "FETCH_STOCK_KLINES") {
    fetchTencentKline(msg)
      .then((data) => sendResponse({ ok: true, data }))
      .catch((err) => sendResponse({ ok: false, error: err.message || String(err) }));
    return true;
  }

});
