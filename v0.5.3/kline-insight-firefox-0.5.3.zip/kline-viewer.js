// @ts-check
import {
  analyze,
  detectFibonacciSetups,
  recommendStrategies,
  buildStrategyPlan,
} from "./lib/index.js";
import { normalizeSymbol } from "./symbol-utils.js";
import { tryConsume } from "./quota.js";
import { getCachedState, getDeviceId, isActive } from "./account.js";
import { detectPageContext } from "./page-detector.js";
import { initI18n, setLang, t, LANG, strategyName, categoryName, strategyAuthor } from "./i18n.js";
import { strategyField } from "./content-i18n.js";
import { localizePlan } from "./plan-l10n.js";
import { trAnalysis, trFragments } from "./analysis-l10n.js";
import { saveCanvas, shotFilename } from "./screenshot.js";
import { addNote, removeNote, notesFor, emptyNotes } from "./notes.js";

const api = typeof browser !== "undefined" && browser.runtime ? browser : chrome;
const $ = (sel) => document.querySelector(sel);
const UP = "#2ecc71";
const DOWN = "#e74c3c";
const GRID = "#232f47";
const BG = "#171e2d";
const ACCENT = "#4f8cff";
const GOLD = "#f1c40f";
const FIB_COLORS = {
  0.236: "rgba(79,140,255,0.75)",
  0.382: "rgba(46,204,113,0.85)",
  0.5: "rgba(241,196,15,0.9)",
  0.618: "rgba(231,76,60,0.85)",
  0.786: "rgba(155,89,182,0.85)",
  1.272: "rgba(230,126,34,0.7)",
  1.618: "rgba(230,126,34,0.7)",
};

/** @type {any} */
let lastResult = null;
let viewRange = null;
let selectedSetupIdx = null;
let panState = null;
let panMoved = false;
let hoverIdx = null;
let hoverY = null;
let runSeq = 0;
let currentKey = "";
let viewerWindowId = null;
let explicitContext = false;
let fetchReqSeq = 0;
let noteStore = emptyNotes();
let lastIntraday = null;
let intradaySeq = 0;

function setStatus(text, isError = false) {
  const el = $("#status");
  el.textContent = text;
  el.className = `status${isError ? " error" : ""}`;
}

// 接收后台的取数进度广播：显示“正在用哪个数据源”
api.runtime.onMessage.addListener((msg) => {
  if (msg && msg.type === "FETCH_PROGRESS" && msg.reqId === fetchReqSeq) {
    if (msg.ok) {
      setStatus(t("status_source", { label: msg.label }));
    } else if (msg.label) {
      setStatus(t("status_fetch_progress", { label: msg.label }));
    }
  }
});

function clampRange(range, n) {
  if (n <= 0) return [0, 0];
  if (!range || range.length !== 2) return [0, n - 1];
  let [s, e] = range;
  s = Math.max(0, Math.min(n - 1, Math.round(s)));
  e = Math.max(s, Math.min(n - 1, Math.round(e)));
  return [s, e];
}

function defaultViewRange(count) {
  const n = Math.max(1, count || 1);
  return [Math.max(0, n - 100), n - 1];
}

function fmtPrice(v) {
  if (v == null) return "-";
  const n = Number(v);
  if (!Number.isFinite(n)) return String(v);
  const abs = Math.abs(n);
  return n.toFixed(abs >= 1000 ? 2 : abs >= 1 ? 3 : 5);
}

function fmtNum(v) {
  if (v == null) return "-";
  const abs = Math.abs(v);
  return v.toLocaleString("zh-CN", { maximumFractionDigits: abs >= 10000 ? 0 : abs >= 100 ? 2 : 4 });
}

const LOCAL_API_BASE = "https://getmarketcompass.site";
const LOCAL_API_TIMEOUT = 30000;

/** 本地经济模型 API 请求：带超时，失败时抛出带 status 的错误；options 可传 fetch 选项（如 method/headers/body） */
async function fetchLocalApi(url, timeoutMs = LOCAL_API_TIMEOUT, options = {}) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const res = await fetch(url, { signal: controller.signal, ...options });
    let data = null;
    try {
      data = await res.json();
    } catch {
      // 非 JSON 响应，按 HTTP 错误处理
    }
    if (!res.ok || !data || data.ok !== true) {
      const err = new Error((data && data.error) || `HTTP ${res.status}`);
      err.status = res.status;
      err.data = data;
      throw err;
    }
    return data;
  } finally {
    clearTimeout(timer);
  }
}

/** 分钟预测 API 使用的标的：加密货币去掉计价币（BTCUSDT → BTC），股票/指数去掉市场前缀 */
function intradayApiSymbol() {
  const raw = $("#symbol").value.trim();
  const exchange = $("#exchange").value;
  // 先规范化（stock 分支会给股票加市场前缀，如 ^SOX → us:^SOX），
  // 再剥离市场前缀（us:/hk:/jp:/kr:/tw:/sh:/sz:/cn:）——经济模型不识别该格式；
  // 保留 ^（如 ^SOX），经济模型内置了 ^sox → sox 的指数映射
  const symbol = normalizeSymbol(exchange, raw);
  if (!symbol) return "";
  const cleaned = symbol.replace(/^(us|hk|jp|kr|tw|sh|sz|cn|nasdaq|nyse)\s*:/i, "");
  if (["binance", "bybit", "okx"].includes(exchange)) {
    const m = cleaned.match(/^(.*?)(USDT|USDC|FDUSD|USD|BTC|ETH|EUR|TRY)$/);
    // OKX 归一化带横线（BTC-USDT），去掉尾横线避免 BTC-
    if (m && m[1]) return m[1].replace(/-+$/, "");
  }
  // 港股补 .HK 后缀（服务端只认 0700.HK）
  if (/^hk\s*:/i.test(symbol)) {
    return `${String(Number(cleaned)).padStart(4, "0")}.HK`;
  }
  return cleaned;
}

function intradayDirectionMeta(direction) {
  const d = String(direction || "").toLowerCase();
  const text = String(direction || t("economy_dir_watch"));
  const LONG = ["多", "long", "bullish", "buy", "看涨", "看多", "强気", "上昇", "상승", "매수", "강세"];
  const SHORT = ["空", "short", "bearish", "sell", "看跌", "看空", "弱気", "下落", "하락", "매도", "약세"];
  if (LONG.some((k) => d.includes(k))) return { cls: "long", label: text, color: "#e74c3c" };
  if (SHORT.some((k) => d.includes(k))) return { cls: "short", label: text, color: "#2ecc71" };
  return { cls: "watch", label: text, color: "#9aa3b2" };
}

function fmtConfidence(v) {
  if (v == null || v === "") return "-";
  const n = Number(v);
  // 服务端返回中文分级字符串（低/中/中高/高）时本地化显示
  if (!Number.isFinite(n)) {
    const map = { "低": t("economy_conf_low"), "中": t("economy_conf_mid"), "中高": t("economy_conf_midhigh"), "高": t("economy_conf_high") };
    return map[String(v)] || String(v);
  }
  const pct = n <= 1 ? n * 100 : n;
  return `${Math.min(100, Math.max(0, pct)).toFixed(0)}%`;
}

function fmtIntradayTime(v) {
  if (v == null || v === "") return "";
  const d = new Date(v);
  if (!Number.isFinite(d.getTime())) return String(v);
  const mm = String(d.getMonth() + 1).padStart(2, "0");
  const dd = String(d.getDate()).padStart(2, "0");
  const hh = String(d.getHours()).padStart(2, "0");
  const mi = String(d.getMinutes()).padStart(2, "0");
  return `${mm}-${dd} ${hh}:${mi}`;
}

function fmtIntradayWindow(w) {
  if (!w) return "";
  const s = fmtIntradayTime(w.start);
  const e = fmtIntradayTime(w.end);
  if (s && e) return `${s} → ${e}`;
  return s || e || "";
}

/** 读取最近的普通标签页（排除扩展自身页面） */
async function findLastPageTab() {
  try {
    const tabs = await api.tabs.query({});
    const normal = (tabs || []).filter(
      (t) => t.url && !t.url.startsWith("chrome-extension://") && !t.url.startsWith("moz-extension://"),
    );
    normal.sort((a, b) => (b.lastAccessed || 0) - (a.lastAccessed || 0));
    return normal[0] || null;
  } catch {
    return null;
  }
}

/** 从 URL 参数或最近标签页识别标的 */
async function detectSymbol() {
  const params = new URLSearchParams(location.search);
  const qIv = params.get("interval");
  const qLmt = params.get("limit");
  if (qIv && [...$("#interval").options].some((o) => o.value === qIv)) $("#interval").value = qIv;
  if (qLmt && [...$("#limit").options].some((o) => o.value === qLmt)) $("#limit").value = qLmt;
  // 优先使用侧边栏传入的参数（用户明确的意图），其次最近访问的真实行情页
  const qEx = params.get("exchange");
  const qSym = params.get("symbol");
  if (qEx && qSym) {
    explicitContext = true;
    return { exchange: qEx, raw: qSym };
  }
  // 其次：侧边栏刚检测到的上下文（用户明确在看股票/期货/交易所页面）
  try {
    const data = await api.storage.local.get("lastViewerContext");
    const lc = data.lastViewerContext;
    if (lc && lc.exchange && lc.symbol) {
      explicitContext = true;
      return { exchange: lc.exchange, raw: lc.symbol };
    }
  } catch {
    /* 忽略 */
  }
  // 再回退到内容脚本写入的上下文
  try {
    const data = await api.storage.local.get("pageContext");
    if (data.pageContext && data.pageContext.key) {
      explicitContext = true;
      return data.pageContext;
    }
  } catch {
    /* 忽略 */
  }
  // 最后才用“最近访问的普通标签页”兜底
  const tab = await findLastPageTab();
  if (tab && tab.url) {
    const ctx = detectPageContext(tab.url, tab.title || "");
    if (ctx) return ctx;
  }
  return null;
}

/** 读取查看器所在窗口当前激活的普通页面上下文（自动跟随与「读取当前页面」用） */
async function getActiveTabContext() {
  if (viewerWindowId == null) return null;
  try {
    const tabs = await api.tabs.query({ active: true, windowId: viewerWindowId });
    const tab = tabs && tabs[0];
    if (!tab || !tab.url || /^(chrome|moz)-extension:/.test(tab.url)) return null;
    return detectPageContext(tab.url, tab.title || "");
  } catch {
    return null;
  }
}

function applyContext(ctx) {
  const exchange = ["okx", "bybit", "stock", "futures"].includes(ctx.exchange) ? ctx.exchange : "binance";
  const symbol = normalizeSymbol(exchange, ctx.raw);
  if (!symbol) return;
  $("#exchange").value = exchange;
  $("#symbol").value = symbol;
  // 程序化切到股票/期货时同样处理 4h（与用户手动切换一致，避免日线冒充 4h）
  const no4h = ["stock", "futures"].includes(exchange);
  const fourH = [...$("#interval").options].find((o) => o.value === "4h");
  if (fourH) fourH.disabled = no4h;
  if (no4h && $("#interval").value === "4h") $("#interval").value = "1d";
}

async function runAnalysis() {
  const seq = ++runSeq;
  const exchange = $("#exchange").value;
  const raw = $("#symbol").value.trim();
  if (!raw) {
    setStatus(t("status_symbol_required"), true);
    return;
  }
  const symbol = normalizeSymbol(exchange, raw);
  if (!symbol) {
    setStatus(t("status_bad_symbol"), true);
    return;
  }
  const interval = $("#interval").value;
  const limit = Number($("#limit").value) || 200;
  setStatus(t("status_fetching", { sym: symbol, iv: interval }));
  try {
    const res = await api.runtime.sendMessage({
      type: "FETCH_KLINES",
      exchange,
      symbol,
      interval,
      limit,
      reqId: ++fetchReqSeq,
    });
    if (!res || !res.ok) throw new Error((res && res.error) || t("status_fetch_failed"));
    if (seq !== runSeq) return; // 期间已发起新的识别/演示，丢弃本次结果
    lastResult = analyze(res.candles);
    currentKey = `${exchange}:${symbol}`;
    viewRange = null;
    selectedSetupIdx = null;
    cancelIntradayForecast();
    render();
    renderNotes();
    setStatus(
      t("status_analyzed", {
        sym: symbol,
        iv: interval,
        n: lastResult.count,
        d: lastResult.detections.length,
        f: lastResult.fibSetups.length,
        src: res.source ? `（${res.source}）` : "",
      }),
    );
  } catch (err) {
    const em = String(err && err.message ? err.message : err);
    const eh = trAnalysis(em);
    setStatus(eh !== em ? eh : trFragments(em), true);
  }
}

function render() {
  if (!lastResult) return;
  lastResult.fibSetups = detectFibonacciSetups(lastResult.candles);
  drawChart();
  renderFibList();
  renderLevels();
  renderVolume();
  renderStrategies();
  renderIntradayPanel();
}

function renderIntradayStatus(text, isError = false) {
  const list = $("#intraday-list");
  if (!list) return;
  list.innerHTML = "";
  const div = document.createElement("div");
  div.className = `intraday-status${isError ? " error" : ""}`;
  div.textContent = text;
  list.appendChild(div);
}

function renderIntradayPanel() {
  const list = $("#intraday-list");
  if (!list) return;
  list.innerHTML = "";
  if (!lastIntraday) {
    list.appendChild(emptyDiv(t("intraday_empty")));
    return;
  }
  const r = lastIntraday;
  const dir = intradayDirectionMeta(r.direction);
  const card = document.createElement("div");
  card.className = "intraday-card";

  const headline = document.createElement("div");
  headline.className = "intraday-headline";
  const dirEl = document.createElement("span");
  dirEl.className = `intraday-direction ${dir.cls}`;
  dirEl.textContent = dir.label;
  headline.appendChild(dirEl);
  const scaleEl = document.createElement("span");
  scaleEl.className = "intraday-scale";
  scaleEl.textContent = t("intraday_scale_minute");
  headline.appendChild(scaleEl);
  const conf = document.createElement("span");
  conf.className = "intraday-confidence";
  conf.textContent = `${t("intraday_confidence")} ${fmtConfidence(r.confidence)}`;
  headline.appendChild(conf);
  card.appendChild(headline);

  const marketRow = document.createElement("div");
  marketRow.className = "intraday-row";
  const marketLabel = document.createElement("span");
  marketLabel.textContent = t("intraday_market_status");
  const marketValue = document.createElement("b");
  const marketMap = { "交易中": t("economy_market_open"), "已收盘": t("economy_market_closed"), "未开盘": t("economy_market_pending") };
  marketValue.textContent = marketMap[String(r.marketStatus)] || String(r.marketStatus || "-");
  marketRow.append(marketLabel, marketValue);
  card.appendChild(marketRow);

  const priceRow = document.createElement("div");
  priceRow.className = "intraday-row";
  const priceLabel = document.createElement("span");
  priceLabel.textContent = t("intraday_price");
  const priceValue = document.createElement("b");
  priceValue.textContent = r.price != null ? fmtPrice(r.price) : "-";
  priceRow.append(priceLabel, priceValue);
  card.appendChild(priceRow);

  const targets = r.targets || {};
  if (targets.high || targets.low) {
    const targetGrid = document.createElement("div");
    targetGrid.className = "intraday-targets";
    const makeTarget = (key, label, cls) => {
      const tg = targets[key];
      if (!tg || tg.price == null) return null;
      const wrap = document.createElement("div");
      wrap.className = "intraday-target";
      const labelEl = document.createElement("div");
      labelEl.className = "label";
      labelEl.textContent = label;
      const priceEl = document.createElement("div");
      priceEl.className = `price ${cls}`;
      priceEl.textContent = fmtPrice(tg.price);
      const winEl = document.createElement("div");
      winEl.className = "window";
      winEl.textContent = tg.window ? `${t("intraday_window")} ${fmtIntradayWindow(tg.window)}` : "";
      wrap.append(labelEl, priceEl, winEl);
      return wrap;
    };
    const highEl = makeTarget("high", t("intraday_target_high"), "high");
    const lowEl = makeTarget("low", t("intraday_target_low"), "low");
    if (highEl) targetGrid.appendChild(highEl);
    if (lowEl) targetGrid.appendChild(lowEl);
    if (targetGrid.children.length) card.appendChild(targetGrid);
  }

  const disclaimer = document.createElement("div");
  disclaimer.className = "intraday-disclaimer";
  disclaimer.textContent = r.disclaimer || t("intraday_disclaimer_default");
  card.appendChild(disclaimer);

  list.appendChild(card);
}

function renderIntradayUnavailable(err) {
  const detail = err && err.message && err.name !== "AbortError" ? `（${err.message}）` : "";
  renderIntradayStatus(t("intraday_status_unavailable") + detail, true);
}

/** 点击「分钟预测」 */
async function runIntradayForecast() {
  const seq = ++intradaySeq;
  const raw = $("#symbol").value.trim();
  if (!raw) {
    setStatus(t("status_symbol_required"), true);
    return;
  }
  // 限次：分钟预测是付费核心内容——免费版每日 N 次，会员不限
  const acc = await getCachedState();
  const q = await tryConsume(!!(acc && acc.expiresAt && isActive(acc.expiresAt)));
  if (!q.allowed) {
    setStatus(t("account_need_upgrade"), true);
    return;
  }
  const symbol = intradayApiSymbol();
  if (!symbol) {
    setStatus(t("status_bad_symbol"), true);
    return;
  }
  const btn = $("#intraday-btn");
  btn.disabled = true;
  btn.textContent = t("intraday_btn_loading");
  renderIntradayStatus(t("intraday_status_loading"));
  try {
    // 服务端每日限次：分钟预测请求必须携带 deviceId（服务端按设备记账，客户端计数可被绕过）
    const deviceId = await getDeviceId();
    // A股（6 位纯数字代码）分钟预测：插件端直连腾讯/东财/新浪抓 5m K线（大陆用户网络必通，
    // 服务器海外访问国内源不通、Twelve Data 免费档也不覆盖 A股），把 K线 POST 给服务器算预测——
    // 不消耗 Twelve Data 额度，服务器只做分析计算
    let data;
    if (/^\d{6}$/.test(symbol)) {
      const res = await api.runtime.sendMessage({
        type: "FETCH_KLINES",
        exchange: "stock",
        symbol,
        interval: "5m",
        limit: 320,
        reqId: ++fetchReqSeq,
      });
      if (!res || !res.ok) throw new Error((res && res.error) || t("status_fetch_failed"));
      // 截断到最近 320 根（约 7 个交易日）：东财 lmt 参数不严格生效可能返回上千根，
      // 全量 POST 会超服务器 body 上限（136KB > 64KB 曾致连接被断）
      const candles = (res.candles || []).slice(-320);
      if (!candles.length) throw new Error(t("status_fetch_failed"));
      const klines = candles.map((c) => ({
        timestamp: c.timestamp,
        open: c.open,
        high: c.high,
        low: c.low,
        close: c.close,
      }));
      data = await fetchLocalApi(
        `${LOCAL_API_BASE}/api/intraday`,
        LOCAL_API_TIMEOUT,
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ symbol, interval: "5m", horizon: 4, lang: LANG, klines, deviceId }),
        },
      );
    } else {
      data = await fetchLocalApi(
        `${LOCAL_API_BASE}/api/intraday?symbol=${encodeURIComponent(symbol)}&interval=5m&horizon=4&lang=${LANG}&deviceId=${encodeURIComponent(deviceId)}`,
      );
    }
    if (seq !== intradaySeq) return;
    lastIntraday = data;
    renderIntradayPanel();
    drawChart();
    setStatus(t("intraday_status_loaded", { sym: symbol }));
  } catch (err) {
    if (seq !== intradaySeq) return;
    lastIntraday = null;
    drawChart();
    if (err.name === "AbortError" || !err.status || err.status === 502 || err.status === 404) {
      renderIntradayUnavailable(err);
      setStatus(t("intraday_status_unavailable"), true);
    } else {
      renderIntradayStatus(t("intraday_error", { msg: err.message || "" }), true);
      setStatus(t("intraday_error", { msg: err.message || "" }), true);
    }
  } finally {
    if (seq === intradaySeq) {
      btn.disabled = false;
      btn.textContent = t("intraday_btn");
    }
  }
}

function cancelIntradayForecast() {
  intradaySeq++;
  lastIntraday = null;
  const btn = $("#intraday-btn");
  if (btn) {
    btn.disabled = false;
    btn.textContent = t("intraday_btn");
  }
  renderIntradayPanel();
  drawChart();
}

// ---------- 截图与交易笔记 ----------
const NOTE_STORE_KEY = "tradingNotes";

async function loadNoteStore() {
  try {
    const data = await api.storage.local.get(NOTE_STORE_KEY);
    noteStore = data[NOTE_STORE_KEY] || emptyNotes();
  } catch {
    noteStore = emptyNotes();
  }
  renderNotes();
}

async function persistNoteStore() {
  try {
    await api.storage.local.set({ [NOTE_STORE_KEY]: noteStore });
  } catch {
    /* 本地存储不可用时静默失败 */
  }
}

function noteKey() {
  return currentKey || `${$("#exchange").value}:${$("#symbol").value.trim()}`;
}

function renderNotes() {
  const list = $("#note-list");
  if (!list) return;
  const key = noteKey();
  const items = notesFor(noteStore, key);
  list.innerHTML = "";
  if (!items.length) {
    const empty = document.createElement("div");
    empty.className = "empty";
    empty.textContent = t("note_empty");
    list.appendChild(empty);
    return;
  }
  const count = document.createElement("div");
  count.className = "note-count";
  count.textContent = t("note_count", { n: items.length });
  list.appendChild(count);
  for (const n of items) {
    const row = document.createElement("div");
    row.className = "note-item";
    const head = document.createElement("div");
    head.className = "note-head";
    const time = document.createElement("span");
    time.textContent = `${new Date(n.ts).toLocaleString()}${n.interval ? ` · ${n.interval}` : ""}`;
    const del = document.createElement("button");
    del.className = "mini";
    del.textContent = t("note_delete");
    del.addEventListener("click", async () => {
      noteStore = removeNote(noteStore, key, n.id);
      await persistNoteStore();
      renderNotes();
      setStatus(t("note_deleted"));
    });
    head.appendChild(time);
    head.appendChild(del);
    const text = document.createElement("div");
    text.className = "note-text";
    text.textContent = n.text;
    row.appendChild(head);
    row.appendChild(text);
    list.appendChild(row);
  }
}

async function saveNote(withShot = false) {
  const text = $("#note-text").value.trim();
  if (!text) {
    setStatus(t("note_need_text"), true);
    return;
  }
  const key = noteKey();
  noteStore = addNote(noteStore, { key, text, interval: $("#interval").value });
  await persistNoteStore();
  $("#note-text").value = "";
  renderNotes();
  setStatus(t("note_saved"));
  if (withShot) saveScreenshot();
}

async function saveScreenshot() {
  const canvas = $("#chart");
  if (!lastResult || !canvas || !canvas.width || !canvas.height) {
    setStatus(t("viewer_shot_need"), true);
    return;
  }
  const header = `${$("#exchange").value.toUpperCase()} ${$("#symbol").value.trim()} ${$("#interval").value} · ${new Date().toLocaleString()}`;
  const ok = await saveCanvas(canvas, {
    headerText: header,
    filename: shotFilename($("#symbol").value.trim(), $("#interval").value),
    api,
  });
  setStatus(ok ? t("viewer_shot_done") : t("viewer_shot_need"), !ok);
}

function renderFibList() {
  const el = $("#fib-list");
  el.innerHTML = "";
  const setups = lastResult.fibSetups || [];
  if (!setups.length) {
    el.appendChild(emptyDiv(t("fib_none")));
    return;
  }
  setups.forEach((s, idx) => {
    const card = document.createElement("div");
    card.className = `fib-card${selectedSetupIdx === idx ? " selected" : ""}`;
    const trendText = s.trend === "up" ? t("fib_up_wave") : t("fib_down_wave");
    const dirText = s.direction === "bullish" ? t("fib_bull_zone") : s.direction === "bearish" ? t("fib_bear_zone") : t("fib_watch_zone");
    const row = document.createElement("div");
    row.className = "row";
    row.innerHTML = `
      <span class="name">${trendText} · ${trAnalysis(s.zone)}</span>
      <span class="badge ${s.direction === "bullish" ? "bullish" : s.direction === "bearish" ? "bearish" : ""}">${dirText}</span>
      <span class="badge ${s.score >= 70 ? "high" : ""}">${s.score}</span>
    `;
    const levels = document.createElement("div");
    levels.className = "levels";
    levels.textContent = s.levels
      .slice(0, 7)
      .map((l) => `${l.ratio}=${fmtPrice(l.price)}`)
      .join("  ");
    const detail = document.createElement("div");
    detail.className = "levels";
    detail.textContent = t("fib_detail", {
      start: s.start + 1,
      end: s.end + 1,
      ret: s.retracement,
      span: fmtPrice(s.hi - s.lo),
    });
    card.appendChild(row);
    card.appendChild(levels);
    card.appendChild(detail);
    if (s.confluence.length) {
      const c = document.createElement("div");
      c.className = "confluence";
      c.textContent = "⚡ " + s.confluence.map((x) => trAnalysis(x)).join("；");
      card.appendChild(c);
    }
    card.addEventListener("click", () => {
      selectedSetupIdx = idx;
      renderFibList();
      drawChart();
    });
    el.appendChild(card);
  });
}

function renderLevels() {
  const el = $("#level-list");
  el.innerHTML = "";
  const mc = lastResult.marketContext;
  if (!mc) {
    el.appendChild(emptyDiv(t("status_data_insufficient")));
    return;
  }
  const supports = mc.keyLevels.supports.slice(0, 5);
  const resistances = mc.keyLevels.resistances.slice(0, 5);
  if (!supports.length && !resistances.length) el.appendChild(emptyDiv(t("status_none")));
  for (const l of resistances) {
    const chip = document.createElement("div");
    chip.className = "level-chip resist";
    chip.innerHTML = `<span>${t("resist_touch", { n: l.touches })}</span><span class="price">${fmtPrice(l.price)}</span>`;
    el.appendChild(chip);
  }
  for (const l of supports) {
    const chip = document.createElement("div");
    chip.className = "level-chip";
    chip.innerHTML = `<span>${t("support_touch", { n: l.touches })}</span><span class="price">${fmtPrice(l.price)}</span>`;
    el.appendChild(chip);
  }
}

function renderVolume() {
  const el = $("#vol-summary");
  el.innerHTML = "";
  const mc = lastResult.marketContext;
  if (!mc) {
    el.appendChild(emptyDiv(t("status_data_insufficient")));
    return;
  }
  const parts = [
    `VWAP：${mc.vwap != null ? fmtPrice(mc.vwap) : "-"}`,
    `OBV：${mc.obv != null ? fmtNum(mc.obv) : "-"}`,
    `POC：${mc.keyLevels.poc != null ? fmtPrice(mc.keyLevels.poc) : "-"}`,
    trAnalysis(mc.volumeDivergence ? mc.volumeDivergence.message : "近期没有量价背离"),
  ];
  const div = document.createElement("div");
  div.className = "levels";
  div.textContent = parts.join(" ｜ ");
  el.appendChild(div);
}

function renderStrategies() {
  const el = $("#strategy-list");
  el.innerHTML = "";
  const note = document.createElement("div");
  note.className = "plan-warn";
  note.textContent = t("strategy_note_warn");
  el.appendChild(note);
  const recs = recommendStrategies(lastResult.candles, lastResult, 5);
  if (!recs.length) {
    el.appendChild(emptyDiv(t("status_no_strategy")));
    return;
  }
  recs.forEach((r, idx) => {
    const card = document.createElement("div");
    card.className = `strategy-card${idx === 0 ? " top" : ""}`;
    const row = document.createElement("div");
    row.className = "row";
    row.innerHTML = `
      <span class="name">${strategyName(r.strategy)}</span>
      ${idx === 0 ? `<span class="badge high">${t("strategy_top")}</span>` : ""}
      <span class="badge">${categoryName(r.strategy.category)}</span>
      <span class="author">${strategyAuthor(r.strategy)}</span>
    `;
    const scoreColor = r.score >= 70 ? "#0ecb81" : r.score >= 50 ? "#f0b90b" : "#7b8499";
    const scoreLine = document.createElement("div");
    scoreLine.className = "score-line";
    scoreLine.innerHTML = `
      <div class="bar"><i style="width:${Math.min(100, r.score)}%;background:${scoreColor}"></i></div>
      <span class="score" style="color:${scoreColor}">${r.score}</span>
    `;
    const signal = document.createElement("div");
    signal.className = "signal";
    signal.textContent = t("strategy_signal", { s: trAnalysis(r.signal) });
    const reasons = document.createElement("div");
    reasons.className = "reasons";
    reasons.textContent = r.reasons.slice(0, 3).join("；");
    const summary = document.createElement("div");
    summary.className = "summary";
    summary.textContent = strategyField(r.strategy, "summary");
    card.appendChild(row);
    card.appendChild(scoreLine);
    card.appendChild(signal);
    card.appendChild(reasons);
    card.appendChild(summary);

    const plan = localizePlan(buildStrategyPlan(r.strategy, lastResult.candles, lastResult), r.strategy);
    if (plan) {
      const planEl = document.createElement("div");
      planEl.className = "execution-plan";
      const status = document.createElement("div");
      status.className = `plan-status ${plan.ready ? "ready" : "wait"}`;
      status.textContent = plan.action;
      planEl.appendChild(status);

      const row = (k, v) => {
        const line = document.createElement("div");
        line.className = "plan-row";
        const key = document.createElement("span");
        key.className = "k";
        key.textContent = k;
        const val = document.createElement("span");
        val.textContent = v;
        line.append(key, val);
        return line;
      };

      if (plan.direction !== "wait") {
        planEl.appendChild(row(t("plan_row_direction"), plan.direction === "long" ? t("dir_long_only") : t("dir_short_only")));
        planEl.appendChild(row(t("plan_row_trigger"), plan.trigger.text));
        planEl.appendChild(row(t("plan_row_entry"), `${plan.entry.type} ${fmtPrice(plan.entry.price)}`));
        if (plan.stopLoss) planEl.appendChild(row(t("plan_row_stop"), plan.stopLoss.text));
        if (plan.takeProfit) planEl.appendChild(row(t("plan_row_target"), plan.takeProfit.text));
        if (plan.addOn) planEl.appendChild(row(t("plan_row_add"), plan.addOn.text));
        planEl.appendChild(row(t("plan_row_exit"), plan.exit));
      }

      const stepsDiv = document.createElement("div");
      stepsDiv.className = "plan-steps";
      plan.steps.forEach((step, i) => {
        const line = document.createElement("div");
        line.className = "step";
        line.textContent = `${i + 1}. ${step}`;
        stepsDiv.appendChild(line);
      });
      planEl.appendChild(stepsDiv);

      for (const w of plan.warnings) {
        const warn = document.createElement("div");
        warn.className = "plan-warn";
        warn.textContent = `⚠️ ${w}`;
        planEl.appendChild(warn);
      }

      const rules = document.createElement("div");
      rules.className = "rules";
      rules.textContent = `${t("rules_label")}：${strategyField(r.strategy, "rules")}`;
      planEl.appendChild(rules);
      card.appendChild(planEl);
    }
    const openBtn = document.createElement("button");
    openBtn.className = "primary";
    openBtn.textContent = t("btn_view_demo");
    openBtn.style.marginTop = "8px";
    openBtn.style.width = "100%";
    openBtn.addEventListener("click", (e) => {
      e.stopPropagation();
      openPlanModal(r, plan);
    });
    card.appendChild(openBtn);
    card.style.cursor = "pointer";
    card.addEventListener("click", (e) => {
      if (e.target.tagName === "INPUT" || e.target.tagName === "BUTTON") return;
      openPlanModal(r, plan);
    });
    el.appendChild(card);
  });
}

/** 打开策略规则演示弹窗 */
function openPlanModal(r, plan) {
  if (!plan) return;
  const modal = $("#plan-modal");
  $("#plan-modal-title").textContent = `${strategyName(r.strategy)} · ${t("plan_title_suffix")}`;
  const content = $("#plan-modal-content");
  content.innerHTML = "";

  const disclaimer = document.createElement("div");
  disclaimer.className = "plan-warn";
  disclaimer.textContent = t("plan_disclaimer");
  content.appendChild(disclaimer);

  const addRow = (k, v) => {
    const line = document.createElement("div");
    line.className = "plan-row";
    const key = document.createElement("span");
    key.className = "k";
    key.textContent = k;
    const val = document.createElement("span");
    val.textContent = v;
    line.append(key, val);
    content.appendChild(line);
  };

  const sum = document.createElement("div");
  sum.className = "plan-summary";
  sum.textContent = plan.action;
  content.appendChild(sum);

  if (plan.direction === "wait") {
    for (const s of plan.steps.slice(0, 2)) addRow(t("plan_row_explain"), s);
  } else {
    addRow(t("plan_row_direction"), plan.direction === "long" ? t("dir_long_only") : t("dir_short_only"));
    addRow(t("plan_row_trigger"), plan.trigger.text);
    addRow(t("plan_row_entry"), `${plan.entry.type} ${fmtPrice(plan.entry.price)}`);

    if (plan.stopLoss) addRow(t("plan_row_stop"), plan.stopLoss.text);
    if (plan.takeProfit) addRow(t("plan_row_target"), plan.takeProfit.text);
    if (plan.closePlan) addRow(t("plan_row_close"), plan.closePlan);
    addRow(t("plan_row_exit"), plan.exit);
  }

  const stepsDiv = document.createElement("div");
  stepsDiv.className = "plan-steps";
  plan.steps.forEach((step, i) => {
    const line = document.createElement("div");
    line.className = "step";
    line.textContent = `${i + 1}. ${step}`;
    stepsDiv.appendChild(line);
  });
  content.appendChild(stepsDiv);

  for (const w of plan.warnings) {
    const warn = document.createElement("div");
    warn.className = "plan-warn";
    warn.textContent = `⚠️ ${w}`;
    content.appendChild(warn);
  }

  const rules = document.createElement("div");
  rules.className = "rules";
  rules.textContent = `${t("rules_label")}：${strategyField(r.strategy, "rules")}`;
  content.appendChild(rules);

  modal.style.display = "flex";
}

$("#plan-modal-close").addEventListener("click", () => {
  $("#plan-modal").style.display = "none";
});
$("#plan-modal").addEventListener("click", (e) => {
  if (e.target === $("#plan-modal")) $("#plan-modal").style.display = "none";
});

function emptyDiv(text) {
  const d = document.createElement("div");
  d.className = "empty";
  d.textContent = text;
  return d;
}

// ============ 画布绘制（币安/OKX 风格） ============
const COLORS = {
  bg: "#0b0e14",
  grid: "rgba(42,51,66,0.5)",
  text: "#7b8499",
  axis: "#d1d4dc",
  up: "#0ecb81",
  down: "#f6465d",
  crosshair: "rgba(209,212,220,0.4)",
  ma7: "#f5c542",
  ma25: "#4f8cff",
  ma99: "#c15fec",
};
const PRICE_AXIS_W = 66;
const TIME_AXIS_H = 24;
const VOL_RATIO = 0.18;

function maAt(candles, idx, period) {
  if (idx < period - 1) return null;
  let sum = 0;
  for (let i = idx - period + 1; i <= idx; i++) sum += candles[i].close;
  return sum / period;
}

function fmtAxisPrice(v, span) {
  if (v == null || !Number.isFinite(v)) return "-";
  const digits = span >= 1000 ? 2 : span >= 100 ? 2 : span >= 1 ? 3 : span >= 0.01 ? 5 : 7;
  return v.toLocaleString("zh-CN", { maximumFractionDigits: digits });
}

function fmtTime(ts, interval) {
  if (!ts) return "";
  const d = new Date(ts);
  const mm = String(d.getMonth() + 1).padStart(2, "0");
  const dd = String(d.getDate()).padStart(2, "0");
  const hh = String(d.getHours()).padStart(2, "0");
  const mi = String(d.getMinutes()).padStart(2, "0");
  if (interval === "1d" || interval === "1w" || interval === "1M") return `${mm}-${dd}`;
  return `${mm}-${dd} ${hh}:${mi}`;
}

function drawChart() {
  const canvas = $("#chart");
  const wrap = canvas.parentElement;
  if (!lastResult || wrap.clientWidth === 0) return;
  const dpr = window.devicePixelRatio || 1;
  const w = wrap.clientWidth;
  const h = wrap.clientHeight;
  canvas.style.width = `${w}px`;
  canvas.style.height = `${h}px`;
  canvas.width = Math.round(w * dpr);
  canvas.height = Math.round(h * dpr);
  const ctx = canvas.getContext("2d");
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ctx.clearRect(0, 0, w, h);

  const candles = lastResult.candles;
  const n = candles.length;
  const interval = $("#interval").value;
  const [vi0, vi1] = clampRange(viewRange || defaultViewRange(n), n);
  const visible = vi1 - vi0 + 1;
  const plotW = w - 8 - PRICE_AXIS_W;
  const volH = Math.max(42, (h - TIME_AXIS_H) * VOL_RATIO);
  const priceTop = 8;
  const priceBottom = h - TIME_AXIS_H - volH - 14;
  const priceH = priceBottom - priceTop;
  const volTop = priceBottom + 6;
  const x = (i) => 8 + (i - vi0 + 0.5) * (plotW / visible);

  const showFib = $("#fib-toggle").checked;
  const showMa7 = $("#ma7").checked;
  const showMa25 = $("#ma25").checked;
  const showMa99 = $("#ma99").checked;
  const setups = lastResult.fibSetups || [];
  const selected = selectedSetupIdx != null ? setups[selectedSetupIdx] : null;

  // 价格范围：可见K线 + 均线 + 选中斐波那契
  let minP = Infinity;
  let maxP = -Infinity;
  let maxV = 0;
  for (let i = vi0; i <= vi1; i++) {
    const c = candles[i];
    if (c.low < minP) minP = c.low;
    if (c.high > maxP) maxP = c.high;
    if ((c.volume || 0) > maxV) maxV = c.volume || 0;
    if (showMa7) {
      const m = maAt(candles, i, 7);
      if (m != null) {
        if (m < minP) minP = m;
        if (m > maxP) maxP = m;
      }
    }
    if (showMa25) {
      const m = maAt(candles, i, 25);
      if (m != null) {
        if (m < minP) minP = m;
        if (m > maxP) maxP = m;
      }
    }
    if (showMa99) {
      const m = maAt(candles, i, 99);
      if (m != null) {
        if (m < minP) minP = m;
        if (m > maxP) maxP = m;
      }
    }
  }
  if (selected) {
    minP = Math.min(minP, selected.lo);
    maxP = Math.max(maxP, selected.hi);
  }
  if (lastIntraday) {
    const extraPrices = [
      lastIntraday.price,
      lastIntraday.targets && lastIntraday.targets.high && lastIntraday.targets.high.price,
      lastIntraday.targets && lastIntraday.targets.low && lastIntraday.targets.low.price,
      ...(lastIntraday.scenarios || []).map((s) => s.price),
    ];
    for (const p of extraPrices) {
      const nv = Number(p);
      if (Number.isFinite(nv)) {
        minP = Math.min(minP, nv);
        maxP = Math.max(maxP, nv);
      }
    }
  }
  const padP = (maxP - minP) * 0.05 || 1;
  minP -= padP;
  maxP += padP;
  const y = (p) => priceBottom - ((p - minP) / (maxP - minP)) * priceH;
  const bw = Math.max(1, Math.min((plotW / visible) * 0.7, 26));
  const priceSpan = maxP - minP;

  // 背景
  ctx.fillStyle = COLORS.bg;
  ctx.fillRect(0, 0, w, h);
  ctx.font = "11px system-ui, sans-serif";

  // 网格：横向价格线 + 纵向时间线
  ctx.strokeStyle = COLORS.grid;
  ctx.lineWidth = 1;
  const gridRows = 6;
  for (let g = 0; g <= gridRows; g++) {
    const gy = priceTop + (priceH / gridRows) * g;
    ctx.beginPath();
    ctx.moveTo(8, gy);
    ctx.lineTo(w - PRICE_AXIS_W, gy);
    ctx.stroke();
  }
  const timeStep = Math.max(1, Math.ceil(visible / 6));
  for (let i = vi0; i <= vi1; i += timeStep) {
    const gx = x(i);
    ctx.beginPath();
    ctx.moveTo(gx, priceTop);
    ctx.lineTo(gx, priceBottom);
    ctx.stroke();
  }

  // 价格轴（右侧）
  ctx.textBaseline = "middle";
  for (let g = 0; g <= gridRows; g++) {
    const gy = priceTop + (priceH / gridRows) * g;
    const price = maxP - (maxP - minP) * (g / gridRows);
    ctx.fillStyle = COLORS.text;
    ctx.textAlign = "left";
    ctx.fillText(fmtAxisPrice(price, priceSpan), w - PRICE_AXIS_W + 6, gy);
  }
  // 时间轴（底部）
  ctx.textBaseline = "alphabetic";
  ctx.textAlign = "center";
  ctx.font = "10px system-ui, sans-serif";
  const timeLabelW = interval === "1d" || interval === "1w" || interval === "1M" ? 44 : 78;
  let lastTimeX = -Infinity;
  for (let i = vi0; i <= vi1; i += timeStep) {
    const tx = x(i);
    if (tx - lastTimeX < timeLabelW + 8) continue; // 空间不足则跳过，避免挤在一起
    lastTimeX = tx;
    ctx.fillStyle = COLORS.text;
    ctx.fillText(fmtTime(candles[i].timestamp, interval), tx, h - 8);
  }

  // 斐波那契回撤区色带（画在K线下层）
  if (showFib && selected) {
    const golden = selected.levels.find((l) => l.ratio === 0.382);
    const deep = selected.levels.find((l) => l.ratio === 0.618);
    if (golden && deep) {
      const top = y(Math.max(golden.price, deep.price));
      const bot = y(Math.min(golden.price, deep.price));
      ctx.fillStyle = "rgba(14,203,129,0.06)";
      ctx.fillRect(8, top, plotW, bot - top);
    }
  }

  // K线
  ctx.lineWidth = 1;
  for (let i = vi0; i <= vi1; i++) {
    const c = candles[i];
    const up = c.close >= c.open;
    const color = up ? COLORS.up : COLORS.down;
    ctx.strokeStyle = color;
    ctx.fillStyle = color;
    const cx = x(i);
    ctx.beginPath();
    ctx.moveTo(cx, y(c.high));
    ctx.lineTo(cx, y(c.low));
    ctx.stroke();
    const top = y(Math.max(c.open, c.close));
    const bot = y(Math.min(c.open, c.close));
    ctx.fillRect(cx - bw / 2, top, bw, Math.max(1, bot - top));
  }

  // 均线
  const drawMA = (period, color, show) => {
    if (!show) return;
    ctx.strokeStyle = color;
    ctx.lineWidth = 1.2;
    ctx.beginPath();
    let started = false;
    for (let i = vi0; i <= vi1; i++) {
      const m = maAt(candles, i, period);
      if (m == null) continue;
      const px = x(i);
      const py = y(m);
      if (!started) {
        ctx.moveTo(px, py);
        started = true;
      } else {
        ctx.lineTo(px, py);
      }
    }
    ctx.stroke();
  };
  drawMA(99, COLORS.ma99, showMa99);
  drawMA(25, COLORS.ma25, showMa25);
  drawMA(7, COLORS.ma7, showMa7);

  // 成交量
  if (maxV > 0) {
    ctx.strokeStyle = COLORS.grid;
    ctx.beginPath();
    ctx.moveTo(8, volTop - 3);
    ctx.lineTo(w - PRICE_AXIS_W, volTop - 3);
    ctx.stroke();
    for (let i = vi0; i <= vi1; i++) {
      const c = candles[i];
      const v = c.volume || 0;
      const vh = (v / maxV) * (volH - 6);
      const up = c.close >= c.open;
      ctx.fillStyle = up ? "rgba(14,203,129,0.35)" : "rgba(246,70,93,0.35)";
      ctx.fillRect(x(i) - bw / 2, volTop + (volH - 6 - vh), bw, vh);
    }
  }

  // 斐波那契水平线 + 推动浪
  if (showFib && selected) {
    const ratioColors = {
      0.236: "rgba(79,140,255,0.8)",
      0.382: "rgba(14,203,129,0.9)",
      0.5: "rgba(240,185,11,0.95)",
      0.618: "rgba(246,70,93,0.9)",
      0.786: "rgba(193,95,236,0.9)",
    };
    ctx.font = "10px system-ui, sans-serif";
    let lastFibY = -Infinity;
    for (const l of selected.levels.slice(0, 7)) {
      const ly = y(l.price);
      if (ly < priceTop || ly > priceBottom) continue;
      const color = ratioColors[l.ratio] || "rgba(123,132,153,0.7)";
      ctx.strokeStyle = color;
      ctx.lineWidth = 1;
      ctx.setLineDash(l.ratio >= 1 ? [3, 3] : []);
      ctx.beginPath();
      ctx.moveTo(8, ly);
      ctx.lineTo(w - PRICE_AXIS_W, ly);
      ctx.stroke();
      ctx.setLineDash([]);
      // 比例标签：底色药丸 + 防重叠（太近不标文字）
      if (Math.abs(ly - lastFibY) >= 16) {
        lastFibY = ly;
        const label = l.ratio.toFixed(3);
        const tw = ctx.measureText(label).width + 10;
        ctx.fillStyle = "rgba(11,14,20,0.85)";
        ctx.fillRect(w - PRICE_AXIS_W - tw - 6, ly - 9, tw, 16);
        ctx.fillStyle = color;
        ctx.textAlign = "left";
        ctx.fillText(label, w - PRICE_AXIS_W - tw + 1, ly + 1);
      }
    }
    const sx = x(selected.start);
    const ex = x(selected.end);
    const sy = y(selected.trend === "up" ? selected.lo : selected.hi);
    const ey = y(selected.trend === "up" ? selected.hi : selected.lo);
    ctx.strokeStyle = "rgba(79,140,255,0.75)";
    ctx.lineWidth = 1.2;
    ctx.setLineDash([4, 3]);
    ctx.beginPath();
    ctx.moveTo(sx, sy);
    ctx.lineTo(ex, ey);
    ctx.stroke();
    ctx.setLineDash([]);
    ctx.fillStyle = "rgba(79,140,255,0.9)";
    ctx.beginPath();
    ctx.arc(sx, sy, 3, 0, Math.PI * 2);
    ctx.fill();
    ctx.beginPath();
    ctx.arc(ex, ey, 3, 0, Math.PI * 2);
    ctx.fill();
  }

  // 支撑/阻力（细虚线 + 左侧标签）
  const mc = lastResult.marketContext;
  if (mc) {
    ctx.font = "10px system-ui, sans-serif";
    let lastLevelY = -Infinity;
    const drawLevel = (price, color, label) => {
      if (price == null) return;
      const ly = y(price);
      if (ly < priceTop || ly > priceBottom) return;
      ctx.strokeStyle = color;
      ctx.lineWidth = 1;
      ctx.setLineDash([3, 3]);
      ctx.beginPath();
      ctx.moveTo(8, ly);
      ctx.lineTo(w - PRICE_AXIS_W, ly);
      ctx.stroke();
      ctx.setLineDash([]);
      if (Math.abs(ly - lastLevelY) >= 16) {
        lastLevelY = ly;
        const tw = ctx.measureText(label).width + 12;
        ctx.fillStyle = "rgba(11,14,20,0.85)";
        ctx.fillRect(6, ly - 9, tw, 16);
        ctx.fillStyle = color;
        ctx.textAlign = "left";
        ctx.fillText(label, 12, ly + 1);
      }
    };
    for (const s of mc.keyLevels.supports.slice(0, 3)) drawLevel(s.price, "rgba(14,203,129,0.85)", t("support_label"));
    for (const r of mc.keyLevels.resistances.slice(0, 3)) drawLevel(r.price, "rgba(246,70,93,0.85)", t("resistance_label"));
  }

  // 分钟预测叠加：高位/低位目标虚线 + 场景路径点
  if (lastIntraday) {
    ctx.font = "10px system-ui, sans-serif";
    ctx.textBaseline = "middle";
    ctx.textAlign = "left";
    let lastTargetY = -Infinity;
    const drawTarget = (price, color, label, windowObj) => {
      if (price == null) return;
      const ly = y(price);
      if (ly < priceTop || ly > priceBottom) return;
      ctx.strokeStyle = color;
      ctx.lineWidth = 1.2;
      ctx.setLineDash([5, 4]);
      ctx.beginPath();
      ctx.moveTo(8, ly);
      ctx.lineTo(w - PRICE_AXIS_W, ly);
      ctx.stroke();
      ctx.setLineDash([]);
      if (Math.abs(ly - lastTargetY) < 16) return;
      lastTargetY = ly;
      const windowText = fmtIntradayWindow(windowObj);
      const lines = windowText
        ? [`${label} ${fmtAxisPrice(price, priceSpan)}`, windowText]
        : [`${label} ${fmtAxisPrice(price, priceSpan)}`];
      const boxH = lines.length * 14 + 6;
      let boxY = ly - boxH / 2;
      boxY = Math.max(priceTop, Math.min(priceBottom - boxH, boxY));
      const textW = Math.max(...lines.map((s) => ctx.measureText(s).width));
      const tw = Math.min(textW + 12, Math.max(60, plotW - 12));
      ctx.fillStyle = "rgba(11,14,20,0.88)";
      ctx.fillRect(6, boxY, tw, boxH);
      ctx.fillStyle = color;
      lines.forEach((s, i) => ctx.fillText(s, 12, boxY + 10 + i * 14));
    };
    drawTarget(
      lastIntraday.targets && lastIntraday.targets.high && lastIntraday.targets.high.price,
      "#e74c3c",
      t("intraday_target_high"),
      lastIntraday.targets && lastIntraday.targets.high && lastIntraday.targets.high.window,
    );
    drawTarget(
      lastIntraday.targets && lastIntraday.targets.low && lastIntraday.targets.low.price,
      "#2ecc71",
      t("intraday_target_low"),
      lastIntraday.targets && lastIntraday.targets.low && lastIntraday.targets.low.window,
    );

    const scenarios = lastIntraday.scenarios || [];
    if (scenarios.length) {
      const lastCandle = candles[n - 1];
      const t0 = lastCandle && lastCandle.timestamp ? new Date(lastCandle.timestamp).getTime() : Date.now();
      const stepMs = 5 * 60 * 1000;
      const pts = [];
      scenarios.forEach((s, idx) => {
        const p = Number(s.price);
        if (!Number.isFinite(p)) return;
        let sx;
        if (s.time) {
          const st = new Date(s.time).getTime();
          sx = Number.isFinite(st) ? x(n - 1 + (st - t0) / stepMs) : x(n - 1 + idx + 1);
        } else {
          sx = x(n - 1 + idx + 1);
        }
        sx = Math.max(8, Math.min(w - PRICE_AXIS_W, sx));
        pts.push({ x: sx, y: y(p), label: s.label || "" });
      });
      if (pts.length) {
        ctx.strokeStyle = "rgba(79,140,255,0.9)";
        ctx.lineWidth = 1.4;
        ctx.setLineDash([5, 4]);
        ctx.beginPath();
        pts.forEach((p, i) => (i === 0 ? ctx.moveTo(p.x, p.y) : ctx.lineTo(p.x, p.y)));
        ctx.stroke();
        ctx.setLineDash([]);
        ctx.fillStyle = "rgba(79,140,255,0.95)";
        for (const p of pts) {
          ctx.beginPath();
          ctx.arc(p.x, p.y, 3, 0, Math.PI * 2);
          ctx.fill();
        }
      }
    }
  }

  // 最新收盘价线 + 右侧标签
  if (vi1 === n - 1) {
    const last = candles[n - 1];
    const ly = y(last.close);
    const up = last.close >= last.open;
    ctx.strokeStyle = up ? COLORS.up : COLORS.down;
    ctx.lineWidth = 1;
    ctx.setLineDash([4, 3]);
    ctx.beginPath();
    ctx.moveTo(8, ly);
    ctx.lineTo(w - PRICE_AXIS_W, ly);
    ctx.stroke();
    ctx.setLineDash([]);
    const label = fmtAxisPrice(last.close, priceSpan);
    ctx.font = "11px system-ui, sans-serif";
    const tw = ctx.measureText(label).width + 10;
    ctx.fillStyle = up ? COLORS.up : COLORS.down;
    ctx.fillRect(w - PRICE_AXIS_W, ly - 9, tw, 18);
    ctx.fillStyle = COLORS.bg;
    ctx.textAlign = "left";
    ctx.textBaseline = "middle";
    ctx.fillText(label, w - PRICE_AXIS_W + 5, ly);
  }

  // 均线图例
  const legend = [];
  if (showMa7) {
    const m = maAt(candles, vi1, 7);
    if (m != null) legend.push(["MA7", m, COLORS.ma7]);
  }
  if (showMa25) {
    const m = maAt(candles, vi1, 25);
    if (m != null) legend.push(["MA25", m, COLORS.ma25]);
  }
  if (showMa99) {
    const m = maAt(candles, vi1, 99);
    if (m != null) legend.push(["MA99", m, COLORS.ma99]);
  }
  ctx.textBaseline = "middle";
  ctx.textAlign = "left";
  let lx = 14;
  for (const [name, val, color] of legend) {
    ctx.fillStyle = color;
    const txt = `${name} ${fmtAxisPrice(val, priceSpan)}`;
    ctx.fillText(txt, lx, 14);
    lx += ctx.measureText(txt).width + 16;
  }

  // 十字光标 + OHLC 提示
  if (hoverIdx != null && hoverIdx >= vi0 && hoverIdx <= vi1 && !panState) {
    const c = candles[hoverIdx];
    const cx = x(hoverIdx);
    ctx.strokeStyle = COLORS.crosshair;
    ctx.lineWidth = 1;
    ctx.setLineDash([4, 3]);
    ctx.beginPath();
    ctx.moveTo(cx, priceTop);
    ctx.lineTo(cx, priceBottom + volH);
    ctx.stroke();
    if (hoverY != null && hoverY >= priceTop && hoverY <= priceBottom) {
      ctx.beginPath();
      ctx.moveTo(8, hoverY);
      ctx.lineTo(w - PRICE_AXIS_W, hoverY);
      ctx.stroke();
      const pv = maxP - ((hoverY - priceTop) / priceH) * (maxP - minP);
      ctx.fillStyle = COLORS.axis;
      ctx.fillRect(w - PRICE_AXIS_W, hoverY - 9, PRICE_AXIS_W, 18);
      ctx.fillStyle = COLORS.bg;
      ctx.textAlign = "left";
      ctx.fillText(fmtAxisPrice(pv, priceSpan), w - PRICE_AXIS_W + 5, hoverY);
    }
    ctx.setLineDash([]);

    // OHLC 提示框
    const up = c.close >= c.open;
    const change = c.open > 0 ? ((c.close - c.open) / c.open) * 100 : 0;
    const lines = [
      fmtTime(c.timestamp, interval),
      t("ohlc1", { o: fmtAxisPrice(c.open, priceSpan), h: fmtAxisPrice(c.high, priceSpan) }),
      t("ohlc2", { l: fmtAxisPrice(c.low, priceSpan), c: fmtAxisPrice(c.close, priceSpan) }),
      t("ohlc3", { v: fmtNum(c.volume), ch: `${change >= 0 ? "+" : ""}${change.toFixed(2)}` }),
    ];
    const boxW = 216;
    const boxH = lines.length * 16 + 12;
    const bx = cx + 16 > w - PRICE_AXIS_W - boxW ? cx - boxW - 16 : cx + 16;
    // 提示框默认在左上方，若与左上角均线图例重叠则下移一行
    const by = bx < 80 ? 34 : 10;
    ctx.fillStyle = "rgba(17,24,39,0.95)";
    ctx.strokeStyle = "rgba(42,51,66,0.9)";
    ctx.fillRect(bx, by, boxW, boxH);
    ctx.strokeRect(bx, by, boxW, boxH);
    ctx.font = "11px system-ui, sans-serif";
    ctx.textAlign = "left";
    ctx.textBaseline = "middle";
    ctx.fillStyle = COLORS.axis;
    lines.forEach((line, idx) => ctx.fillText(line, bx + 8, by + 16 + idx * 16));
    ctx.fillStyle = up ? COLORS.up : COLORS.down;
    ctx.fillText(`● ${fmtAxisPrice(c.close, priceSpan)}`, bx + boxW - 92, by + 16);
  }
}

// 图表交互
function zoomAt(factor, anchorIdx) {
  const n = lastResult.count;
  const cur = viewRange || defaultViewRange(n);
  const visible = cur[1] - cur[0] + 1;
  const newVisible = Math.max(10, Math.min(n, Math.round(visible / factor)));
  const frac = n > 1 ? (anchorIdx - cur[0]) / visible : 0.5;
  let s = Math.round(anchorIdx - frac * newVisible);
  s = Math.max(0, Math.min(n - newVisible, s));
  viewRange = [s, s + newVisible - 1];
  drawChart();
}

function resetView() {
  viewRange = null;
  hoverIdx = null;
  hoverY = null;
  drawChart();
}

const canvas = $("#chart");
canvas.addEventListener(
  "wheel",
  (e) => {
    e.preventDefault();
    if (!lastResult) return;
    const rect = canvas.getBoundingClientRect();
    const rel = (e.clientX - rect.left) / Math.max(1, rect.width);
    const n = lastResult.count;
    const vr = viewRange || defaultViewRange(n);
    const idx = Math.round(vr[0] + rel * (vr[1] - vr[0] + 1));
    zoomAt(e.deltaY > 0 ? 1 / 1.25 : 1.25, Math.max(vr[0], Math.min(vr[1], idx)));
  },
  { passive: false },
);
canvas.addEventListener("mousedown", (e) => {
  if (e.button !== 0) return; // 只响应左键，右键/中键不进入拖拽
  if (!lastResult) return;
  panMoved = false;
  panState = { x: e.clientX, vr: viewRange || defaultViewRange(lastResult.count) };
  canvas.style.cursor = "grabbing";
});
canvas.addEventListener("mousemove", (e) => {
  const rect = canvas.getBoundingClientRect();
  if (panState) {
    if (Math.abs(e.clientX - panState.x) > 2) panMoved = true;
    const n = lastResult.count;
    const vr = panState.vr;
    const visible = vr[1] - vr[0] + 1;
    const plotW = Math.max(1, rect.width - 8 - PRICE_AXIS_W);
    const dx = Math.round((e.clientX - panState.x) * (visible / plotW));
    let s = Math.max(0, Math.min(n - visible, vr[0] - dx));
    viewRange = [s, s + visible - 1];
    hoverIdx = null;
    hoverY = null;
    drawChart();
    return;
  }
  if (!lastResult) return;
  const vr = viewRange || defaultViewRange(lastResult.count);
  const plotW = Math.max(1, rect.width - 8 - PRICE_AXIS_W);
  const rel = (e.offsetX - 8) / (plotW / (vr[1] - vr[0] + 1));
  const idx = Math.max(vr[0], Math.min(vr[1], Math.round(vr[0] + rel)));
  if (idx !== hoverIdx || e.offsetY !== hoverY) {
    hoverIdx = idx;
    hoverY = e.offsetY;
    drawChart();
  }
});
canvas.addEventListener("mouseup", () => {
  panState = null;
  canvas.style.cursor = "";
});
canvas.addEventListener("mouseleave", () => {
  panState = null;
  canvas.style.cursor = "";
  if (hoverIdx != null || hoverY != null) {
    hoverIdx = null;
    hoverY = null;
    drawChart();
  }
});
canvas.addEventListener("dblclick", resetView);

// 事件
$("#analyze-btn").addEventListener("click", runAnalysis);
$("#symbol").addEventListener("keydown", (e) => {
  if (e.key === "Enter") runAnalysis();
});
$("#detect-btn").addEventListener("click", async () => {
  const ctx = (await getActiveTabContext()) || (await detectSymbol());
  if (!ctx) {
    setStatus(t("status_no_page"), true);
    return;
  }
  explicitContext = false; // 用户手动点“读取当前页面”，允许跟随当前标签页
  applyContext(ctx);
  runAnalysis();
});
$("#shot-btn").addEventListener("click", saveScreenshot);
$("#intraday-btn").addEventListener("click", runIntradayForecast);
$("#note-save").addEventListener("click", () => saveNote(false));
$("#note-save-shot").addEventListener("click", () => saveNote(true));
$("#note-text").addEventListener("keydown", (e) => {
  if ((e.ctrlKey || e.metaKey) && e.key === "Enter") saveNote(false);
});
/** 自动跟随查看器所在窗口当前激活的股票/交易所页面（不跨窗口抢页面） */
function followLatestPage() {
  if (!lastResult) return; // 初始化未完成时由 init 负责首载
  if (explicitContext) return; // 用户明确从侧边栏/最近页面打开时，不自动切换到其它标签页
  getActiveTabContext().then((ctx) => {
    if (!ctx) return;
    const exchange = ["okx", "bybit", "stock", "futures"].includes(ctx.exchange) ? ctx.exchange : "binance";
    const symbol = normalizeSymbol(exchange, ctx.raw);
    if (!symbol) return;
    const key = `${exchange}:${symbol}`;
    if (!key || key === currentKey) return;
    applyContext(ctx);
    runAnalysis();
  });
}

// 期货/股票没有 4h（新浪期货分钟线不支持），选 4h 时自动切到日线
$("#exchange").addEventListener("change", () => {
  cancelIntradayForecast();
  const no4h = ["stock", "futures"].includes($("#exchange").value);
  const fourH = [...$("#interval").options].find((o) => o.value === "4h");
  if (fourH) fourH.disabled = no4h;
  if (no4h && $("#interval").value === "4h") $("#interval").value = "1d";
});
$("#symbol").addEventListener("change", () => {
  cancelIntradayForecast();
});

// 记录查看器所在窗口，自动跟随只作用于本窗口
api.windows.getCurrent().then((w) => {
  viewerWindowId = w && w.id;
});

// 查看器切回前台 / 标签页切换时自动跟随
document.addEventListener("visibilitychange", () => {
  if (document.visibilityState === "visible") followLatestPage();
});
api.tabs.onActivated.addListener(() => {
  setTimeout(followLatestPage, 200);
});

// 国际化：自动按浏览器/系统语言匹配，也可手动切换
/** 兜底直译：确保查看器静态控件始终按当前语言显示（不依赖 SELECTORS） */
function applyStaticL10n() {
  const set = (sel, key) => {
    const el = $(sel);
    if (el) el.textContent = t(key);
  };
  const optMap = {
    "#exchange": { binance: "ex_binance", okx: "ex_okx", bybit: "ex_bybit", stock: "ex_stock", futures: "ex_futures" },
    "#interval": { "15m": "iv_15m", "30m": "iv_30m", "1h": "iv_1h", "4h": "iv_4h", "1d": "iv_1d", "1w": "iv_1w", "1M": "iv_1M" },
  };
  for (const [sel, map] of Object.entries(optMap)) {
    for (const [value, key] of Object.entries(map)) {
      const o = document.querySelector(`${sel} option[value="${value}"]`);
      if (o) o.textContent = t(key);
    }
  }
  set("#analyze-btn", "btn_analyze");
  set("#detect-btn", "btn_detect");
  set("#shot-btn", "viewer_shot_btn");
  set("#note-title", "note_title");
  set("#note-save", "note_save");
  set("#note-save-shot", "note_save_shot");
  const noteText = $("#note-text");
  if (noteText) noteText.placeholder = t("note_placeholder");
  set("#sr-title", "viewer_sr_title");
  set("#vol-title", "viewer_vol_title");
  set("#fib-list-title", "fib_title");
  set("#strategy-title", "strategy_title");
  set(".toolbar-label", "viewer_indicators_label");
  set("#fib-toggle-text", "label_fib");
  set("#intraday-title", "intraday_title");
  set("#intraday-btn", "intraday_btn");
  set("#viewer-chart-hint", "chart_hint_viewer");
  set(".strategy-note", "strategy_note");
  set(".viewer-disclaimer", "viewer_disclaimer");
  const closeBtn = $("#plan-modal-close");
  if (closeBtn) closeBtn.title = t("plan_modal_close");
}

const viewerLangSelect = $("#viewer-lang");
initI18n((lang) => {
  if (viewerLangSelect) viewerLangSelect.value = lang;
  document.title = t("viewer_doc_title");
  applyStaticL10n();
  if (lastResult) renderStrategies();
  renderNotes();
  renderIntradayPanel();
});
if (viewerLangSelect) {
  viewerLangSelect.addEventListener("change", (e) => {
    setLang(e.target.value, () => {
      document.title = t("viewer_doc_title");
      applyStaticL10n();
      if (lastResult) renderStrategies();
      renderNotes();
      renderIntradayPanel();
    });
  });
}
// 新建标签页会自动激活，但此时页面可能还在加载（URL 尚未就绪）；
// URL 更新后再检测一次，确保新打开的股票页也能被跟随
api.tabs.onUpdated.addListener((tabId, info) => {
  if (info.url) setTimeout(followLatestPage, 300);
});
["ma7", "ma25", "ma99", "fib-toggle"].forEach((id) => {
  const input = $("#" + id);
  input.addEventListener("change", () => {
    const label = input.closest("label");
    if (label) label.classList.toggle("active", input.checked);
    drawChart();
  });
});

// 初始化：优先侧边栏参数，其次最近访问页面
loadNoteStore();
detectSymbol().then((ctx) => {
  if (ctx) {
    applyContext(ctx);
    runAnalysis();
  } else {
    setStatus(t("status_no_symbol"));
  }
});

window.addEventListener("resize", () => drawChart());
